import React, { useState, useMemo } from 'react';

// Navigation & Layout Components
import { Navbar } from './components/Navbar';
import { HomePage } from './components/homepage/HomePage';
import { Breadcrumbs } from './components/Breadcrumbs';
import { ErrorPage } from './components/ErrorPage';
import { LandingPage } from './components/LandingPage';
import { StudentDashboard } from './components/StudentDashboard';
import { OpportunitySearch } from './components/OpportunitySearch';
import { SkillMap } from './components/SkillMap';
import { CareerCompass } from './components/CareerCompass';
import { CompanyDirectory } from './components/CompanyDirectory';
import { CollaborationHub } from './components/CollaborationHub';
import { ApplicationTracker } from './components/ApplicationTracker';
import { UniversityDashboard } from './components/UniversityDashboard';
import { RecruiterDashboard } from './components/RecruiterDashboard';
import { IndustryPulseView } from './components/IndustryPulseView';
import { HelpCenter } from './components/HelpCenter';
import { AdminPanel } from './components/AdminPanel';
import { VerifiedSkillsView } from './components/verifiedSkills/VerifiedSkillsView';
import { HOME_VIEW, VIEWS, getRoleDashboardView } from './constants/routes';

// Global Dialogs & Modals
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { AuthModal } from './components/AuthModal';
import { VerificationCenter } from './components/VerificationCenter';

// Data Imports
import { COMPANIES_DATA } from './data/companies';
import { OPPORTUNITIES_DATA } from './data/opportunities';
import { CANONICAL_SKILLS, INITIAL_STUDENT_SKILLS, CanonicalSkill } from './data/skills';
import { CAREER_PATHS_DATA } from './data/careers';
import { INSTITUTIONS_DATA } from './data/institutions';
import { INITIAL_USER_VERIFIED_SKILLS } from './data/verifiedSkillsCatalogue';
import { UserVerifiedSkill } from './types/verifiedSkills';

// Types
import { 
  UserRole, 
  StudentProfile, 
  Opportunity, 
  Company, 
  CareerPath, 
  UserSkill, 
  ApplicationRecord, 
  ApplicationStatus,
  SkillEvidence,
  Institution
} from './types';

// Matching Utility
import { calculateOpportunityMatch } from './utils/matching';

// Default Student Profile (Aarav Sharma - Manipal University Jaipur)
const INITIAL_STUDENT_PROFILE: StudentProfile = {
  userId: 'usr-student-1',
  fullName: 'Aarav Sharma',
  universityEmail: 'student@jaipur.manipal.edu',
  degreeLevel: 'BTech',
  major: 'Computer Science and Engineering',
  institutionId: 'inst-muj',
  institutionName: 'Manipal University Jaipur (MUJ)',
  graduationYear: 2027,
  cgpa: 8.82,
  placementReadinessScore: 78,
  profileCompletionPercentage: 85,
  city: 'Jaipur',
  country: 'India',
  headline: 'Aspiring Systems & AI Engineer | B.Tech CSE @ MUJ',
  bio: 'Passionate about low-latency systems, distributed computing, and machine learning infrastructure. Actively building production-ready projects.',
  targetCareerId: 'career-swe',
  preferredIndustries: ['Technology', 'Finance'],
  workPreference: 'Hybrid',
  verification: {
    status: 'Verified',
    provider: 'University Domain SSO & Digilocker',
    providerRef: 'MUJ-VERIF-2026-98214',
    verifiedAt: '2026-01-15',
    documentType: 'Student ID Card'
  },
  privacySettings: {
    recruiterSearchable: true,
    allowDirectRecruiterContact: true,
    shareAcademicTranscriptVerification: true
  }
};

// Initial applications
const INITIAL_APPLICATIONS: ApplicationRecord[] = [
  {
    id: 'app-1',
    opportunityId: 'opp-google-swe-summer',
    opportunityTitle: 'Software Engineering Intern (Summer 2026)',
    companyName: 'Google',
    companyLogoBg: 'bg-blue-600',
    appliedDate: '2026-03-01',
    status: 'Interview',
    lastStatusUpdate: '2026-03-07',
    nextDeadline: 'Technical Round 2: March 18, 2026',
    notes: 'Cleared initial coding screening (100% on Graph Algorithms problem). Preparing system design fundamentals.'
  },
  {
    id: 'app-2',
    opportunityId: 'opp-jpmc-quant-analyst',
    opportunityTitle: 'Quantitative Technology Analyst (Placement)',
    companyName: 'JPMorgan Chase',
    companyLogoBg: 'bg-slate-800',
    appliedDate: '2026-02-25',
    status: 'Assessment',
    lastStatusUpdate: '2026-03-02',
    nextDeadline: 'Pymetrics & HackerRank: Complete by March 15',
    notes: 'Reviewing portfolio optimization algorithms and modern C++ multithreading concepts.'
  },
  {
    id: 'app-3',
    opportunityId: 'opp-nvidia-ai-perf',
    opportunityTitle: 'AI Systems Performance Engineering Intern',
    companyName: 'NVIDIA',
    companyLogoBg: 'bg-emerald-600',
    appliedDate: '2026-03-04',
    status: 'Applied',
    lastStatusUpdate: '2026-03-04',
    notes: 'Direct application through Manipal University Jaipur campus recruitment portal with mentor endorsement.'
  }
];

export default function App() {
  const [currentRole, setCurrentRole] = useState<UserRole>('student');
  const [currentView, setCurrentView] = useState<string>(HOME_VIEW);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(true);
  const [studentProfile, setStudentProfile] = useState<StudentProfile>(INITIAL_STUDENT_PROFILE);
  const [studentSkills, setStudentSkills] = useState<UserSkill[]>(INITIAL_STUDENT_SKILLS);
  const [applications, setApplications] = useState<ApplicationRecord[]>(INITIAL_APPLICATIONS);
  const [savedOpportunityIds, setSavedOpportunityIds] = useState<string[]>(['opp-google-swe-summer', 'opp-nvidia-ai-perf']);
  const [appliedOpportunityIds, setAppliedOpportunityIds] = useState<string[]>(['opp-google-swe-summer', 'opp-jpmc-quant-analyst', 'opp-nvidia-ai-perf']);

  const [opportunities, setOpportunities] = useState<Opportunity[]>(OPPORTUNITIES_DATA);
  const [companies, setCompanies] = useState<Company[]>(COMPANIES_DATA);
  const [canonicalSkills] = useState<CanonicalSkill[]>(CANONICAL_SKILLS);
  const [careers] = useState<CareerPath[]>(CAREER_PATHS_DATA);
  const [institutions] = useState<Institution[]>(INSTITUTIONS_DATA);

  const [targetCareer, setTargetCareer] = useState<CareerPath>(
    CAREER_PATHS_DATA.find(c => c.id === studentProfile.targetCareerId) || CAREER_PATHS_DATA[0]
  );

  // Verified Skills Flagship State
  const [userVerifiedSkills, setUserVerifiedSkills] = useState<UserVerifiedSkill[]>(INITIAL_USER_VERIFIED_SKILLS);

  const handleAddUserVerifiedSkill = (skill: UserVerifiedSkill) => {
    setUserVerifiedSkills(prev => [skill, ...prev]);
    showToast(`Skill "${skill.skillName}" added to your profile as ○ Self-Declared.`);
  };

  const handleUpdateUserVerifiedSkill = (updated: UserVerifiedSkill) => {
    setUserVerifiedSkills(prev => prev.map(s => s.id === updated.id ? updated : s));
    showToast(`Status for "${updated.skillName}" updated to ${updated.status}.`);
  };

  // Modals
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authTargetRole, setAuthTargetRole] = useState<UserRole | undefined>(undefined);
  const [authTargetView, setAuthTargetView] = useState<string | undefined>(undefined);
  const [isVerificationOpen, setIsVerificationOpen] = useState(false);
  const [selectedOpportunity, setSelectedOpportunity] = useState<Opportunity | null>(null);
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null);

  // Toast Notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  // Toggle Save / Bookmark
  const handleToggleSave = (oppId: string) => {
    setSavedOpportunityIds(prev => {
      const exists = prev.includes(oppId);
      const updated = exists ? prev.filter(id => id !== oppId) : [...prev, oppId];
      showToast(exists ? 'Removed from saved opportunities.' : 'Saved to your active career pipeline.');
      return updated;
    });
  };

  // Direct Apply to Opportunity
  const handleApplyOpportunity = (opp: Opportunity, notes?: string) => {
    if (appliedOpportunityIds.includes(opp.id)) {
      showToast('You have already applied to this opportunity.');
      return;
    }

    const newApp: ApplicationRecord = {
      id: `app-${Date.now()}`,
      opportunityId: opp.id,
      opportunityTitle: opp.title,
      companyName: opp.companyName,
      companyLogoBg: opp.companyLogoBg,
      appliedDate: new Date().toISOString().split('T')[0],
      status: 'Applied',
      lastStatusUpdate: new Date().toISOString().split('T')[0],
      notes: notes || `Applied with verified institutional credentials from ${studentProfile.institutionName}.`
    };

    setApplications(prev => [newApp, ...prev]);
    setAppliedOpportunityIds(prev => [...prev, opp.id]);
    showToast(`Application successfully sent to ${opp.companyName} campus recruitment cell!`);
  };

  // Update Application Pipeline Status
  const handleUpdateApplicationStatus = (appId: string, newStatus: ApplicationStatus, notes?: string) => {
    setApplications(prev => prev.map(a => {
      if (a.id === appId) {
        return {
          ...a,
          status: newStatus,
          lastStatusUpdate: new Date().toISOString().split('T')[0],
          notes: notes !== undefined ? notes : a.notes
        };
      }
      return a;
    }));
    showToast(`Application stage updated to "${newStatus}".`);
  };

  // Add evidence to a skill
  const handleAddEvidence = (skillId: string, evidence: SkillEvidence) => {
    setStudentSkills(prev => prev.map(s => {
      if (s.id === skillId || s.skillId === skillId) {
        return {
          ...s,
          evidence: [...s.evidence, evidence],
          proficiencyScore: Math.min(100, s.proficiencyScore + 10),
          verified: evidence.verified || s.verified
        };
      }
      return s;
    }));
    showToast('Verified evidence successfully logged to your skill profile.');
  };

  // Add a brand new skill to profile
  const handleAddNewSkill = (newSkill: UserSkill) => {
    setStudentSkills(prev => [newSkill, ...prev]);
    showToast(`Skill "${newSkill.name}" added to your verified skill portfolio.`);
  };

  // Add new opportunity from recruiter dashboard
  const handleAddNewOpportunity = (newOpp: Opportunity) => {
    setOpportunities(prev => [newOpp, ...prev]);
    showToast(`New campus drive "${newOpp.title}" successfully published!`);
  };

  // Recruiter visibility toggle
  const handleUpdateVisibility = (recruiterSearchable: boolean) => {
    setStudentProfile(prev => ({
      ...prev,
      privacySettings: {
        recruiterSearchable,
        allowDirectRecruiterContact: prev.privacySettings?.allowDirectRecruiterContact ?? true,
        shareAcademicTranscriptVerification: prev.privacySettings?.shareAcademicTranscriptVerification ?? true
      }
    }));
  };

  // Active Opportunity Match Calculation for Selected Modal
  const selectedOppMatch = useMemo(() => {
    if (!selectedOpportunity) return null;
    return calculateOpportunityMatch(selectedOpportunity, studentProfile, studentSkills);
  }, [studentProfile, studentSkills, selectedOpportunity]);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 bg-slate-900 text-white text-xs font-bold px-4 py-3 rounded-2xl shadow-xl border border-slate-700 flex items-center gap-2 animate-in fade-in slide-in-from-top-4 duration-200">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>{toastMessage}</span>
          <button onClick={() => setToastMessage(null)} className="text-slate-400 hover:text-white ml-2">✕</button>
        </div>
      )}

      {/* Global Application Navbar & Breadcrumbs Navigation (active for app/dashboard views) */}
      {currentView !== HOME_VIEW && (
        <>
          <Navbar
            currentRole={currentRole}
            setCurrentRole={setCurrentRole}
            currentView={currentView}
            setCurrentView={setCurrentView}
            openSearch={() => setIsSearchOpen(true)}
            openAuth={() => setIsAuthOpen(true)}
            openVerification={() => setIsVerificationOpen(true)}
          />
          <div className="bg-white border-b border-slate-200/80 px-4 sm:px-6 lg:px-8 py-2.5">
            <div className="max-w-7xl mx-auto">
              <Breadcrumbs
                currentView={currentView}
                onNavigate={setCurrentView}
                userRole={currentRole}
              />
            </div>
          </div>
        </>
      )}

      {/* Main Viewport Routing */}
      <main className="flex-1">
        {currentView === HOME_VIEW && (
          <HomePage
            currentView={currentView}
            onNavigate={setCurrentView}
            isAuthenticated={isAuthenticated}
            currentUser={{
              fullName: studentProfile.fullName,
              institution: studentProfile.institutionName,
              role: currentRole
            }}
            onOpenLogin={() => {
              setAuthTargetRole(undefined);
              setAuthTargetView(undefined);
              setIsAuthOpen(true);
            }}
            onOpenRegister={() => {
              setAuthTargetRole(undefined);
              setAuthTargetView(undefined);
              setIsAuthOpen(true);
            }}
            onLogout={() => {
              setIsAuthenticated(false);
              showToast('Logged out of session. Public view active.');
            }}
            companies={companies}
            onAccessSkills={() => setCurrentView(VIEWS.SKILLMAP)}
            onAccessCareers={() => setCurrentView(VIEWS.CAREERCOMPASS)}
            onAccessOpportunities={() => setCurrentView(VIEWS.OPPORTUNITIES)}
            onAccessUniversities={() => {
              if (isAuthenticated && currentRole === 'university_admin') {
                setCurrentView(VIEWS.UNIVERSITY_DASHBOARD);
              } else if (isAuthenticated) {
                setCurrentRole('university_admin');
                setCurrentView(VIEWS.UNIVERSITY_DASHBOARD);
                showToast('Switched to University Institutional Command Center.');
              } else {
                setAuthTargetRole('university_admin');
                setAuthTargetView(VIEWS.UNIVERSITY_DASHBOARD);
                setIsAuthOpen(true);
              }
            }}
            onAccessCompanies={() => {
              if (isAuthenticated && currentRole === 'recruiter') {
                setCurrentView(VIEWS.RECRUITER_DASHBOARD);
              } else if (isAuthenticated) {
                setCurrentRole('recruiter');
                setCurrentView(VIEWS.RECRUITER_DASHBOARD);
                showToast('Switched to Recruiter & Corporate Talent Portal.');
              } else {
                setAuthTargetRole('recruiter');
                setAuthTargetView(VIEWS.RECRUITER_DASHBOARD);
                setIsAuthOpen(true);
              }
            }}
          />
        )}

        {currentView === 'dashboard' && (
          <StudentDashboard
            profile={studentProfile}
            skills={studentSkills}
            opportunities={opportunities}
            targetCareer={targetCareer}
            applications={applications}
            onSelectOpportunity={(opp) => setSelectedOpportunity(opp)}
            onNavigate={setCurrentView}
            onOpenVerification={() => setIsVerificationOpen(true)}
          />
        )}

        {currentView === 'verified_skills' && (
          <VerifiedSkillsView
            profile={studentProfile}
            userVerifiedSkills={userVerifiedSkills}
            onAddUserSkill={handleAddUserVerifiedSkill}
            onUpdateUserSkill={handleUpdateUserVerifiedSkill}
            onNavigateToView={setCurrentView}
          />
        )}

        {currentView === 'skillmap' && (
          <SkillMap
            skills={studentSkills}
            onAddEvidence={handleAddEvidence}
            onAddNewSkill={handleAddNewSkill}
          />
        )}

        {currentView === 'careercompass' && (
          <CareerCompass
            skills={studentSkills}
            currentTargetCareerId={targetCareer.id}
            onSetTargetCareer={(career) => {
              setTargetCareer(career);
              setStudentProfile(prev => ({ ...prev, targetCareerId: career.id }));
              showToast(`Target career set to "${career.title}".`);
            }}
            onNavigateToOpportunities={() => setCurrentView('opportunities')}
          />
        )}

        {currentView === 'opportunities' && (
          <OpportunitySearch
            opportunities={opportunities}
            profile={studentProfile}
            skills={studentSkills}
            appliedOpportunityIds={appliedOpportunityIds}
            savedOpportunityIds={savedOpportunityIds}
            onApply={handleApplyOpportunity}
            onToggleSave={handleToggleSave}
            selectedOpportunityForModal={selectedOpportunity}
            onCloseModal={() => setSelectedOpportunity(null)}
          />
        )}

        {currentView === 'companies' && (
          <CompanyDirectory
            companies={companies}
            opportunities={opportunities}
            onSelectOpportunity={(opp) => setSelectedOpportunity(opp)}
            initialSelectedCompany={selectedCompany}
          />
        )}

        {currentView === 'collaborations' && (
          <CollaborationHub />
        )}

        {currentView === 'applications' && (
          <ApplicationTracker
            applications={applications}
            onUpdateStatus={handleUpdateApplicationStatus}
            onNavigateToOpportunities={() => setCurrentView('opportunities')}
          />
        )}

        {currentView === 'university_dashboard' && (
          <UniversityDashboard />
        )}

        {currentView === 'recruiter_dashboard' && (
          <RecruiterDashboard
            existingOpportunities={opportunities}
            onAddNewOpportunity={handleAddNewOpportunity}
          />
        )}

        {currentView === 'industrypulse' && (
          <IndustryPulseView />
        )}

        {currentView === 'help' && (
          <HelpCenter />
        )}

        {currentView === 'admin_panel' && (
          <AdminPanel />
        )}

        {![
          HOME_VIEW,
          'dashboard',
          'verified_skills',
          'skillmap',
          'careercompass',
          'opportunities',
          'companies',
          'collaborations',
          'applications',
          'university_dashboard',
          'recruiter_dashboard',
          'industrypulse',
          'help',
          'admin_panel'
        ].includes(currentView) && (
          <ErrorPage
            errorCode={404}
            onGoHome={() => setCurrentView(HOME_VIEW)}
            onGoBack={() => setCurrentView('dashboard')}
          />
        )}
      </main>

      {/* GLOBAL SEARCH MODAL */}
      <GlobalSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        opportunities={opportunities}
        companies={companies}
        skills={canonicalSkills}
        careers={careers}
        institutions={institutions}
        onSelectEntity={(type, entity) => {
          if (type === 'opportunity') {
            setSelectedOpportunity(entity);
          } else if (type === 'company') {
            setSelectedCompany(entity);
            setCurrentView('companies');
          } else if (type === 'career') {
            setTargetCareer(entity);
            setCurrentView('careercompass');
          } else if (type === 'skill') {
            setCurrentView('skillmap');
          } else if (type === 'institution') {
            setCurrentView('university_dashboard');
          }
          setIsSearchOpen(false);
        }}
      />

      {/* AUTH & REGISTRATION MODAL */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => {
          setIsAuthOpen(false);
          setAuthTargetRole(undefined);
          setAuthTargetView(undefined);
        }}
        targetRole={authTargetRole}
        targetView={authTargetView}
        onLoginSuccess={(user, role, targetView) => {
          setIsAuthenticated(true);
          const activeRole = role || currentRole;
          setCurrentRole(activeRole);
          setStudentProfile(prev => ({
            ...prev,
            fullName: user.fullName || prev.fullName,
            universityEmail: user.email || prev.universityEmail,
            institutionName: user.institution || prev.institutionName
          }));
          showToast(`Authenticated as ${user.fullName} (${user.institution})`);
          if (targetView) {
            setCurrentView(targetView);
          } else if (currentView === HOME_VIEW) {
            setCurrentView(getRoleDashboardView(activeRole));
          }
          setAuthTargetRole(undefined);
          setAuthTargetView(undefined);
        }}
      />

      {/* VERIFICATION & PRIVACY CENTER MODAL */}
      <VerificationCenter
        isOpen={isVerificationOpen}
        onClose={() => setIsVerificationOpen(false)}
        profile={studentProfile}
        onUpdateVisibility={handleUpdateVisibility}
      />

      {/* OPPORTUNITY DETAIL MODAL WITH TRANSPARENT 5-PILLAR BREAKDOWN */}
      {selectedOpportunity && selectedOppMatch && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="p-6 border-b border-slate-200 flex items-start justify-between gap-4">
              <div className="flex items-start gap-3">
                <div className={`w-12 h-12 rounded-2xl ${selectedOpportunity.companyLogoBg} text-white font-black text-sm flex items-center justify-center shrink-0 shadow-2xs`}>
                  {selectedOpportunity.companyName.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
                      {selectedOpportunity.companyName}
                    </span>
                    <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded font-bold">
                      Verified Drive
                    </span>
                  </div>
                  <h2 className="text-lg font-bold text-slate-900 mt-0.5">
                    {selectedOpportunity.title}
                  </h2>
                  <div className="text-xs text-slate-500 flex flex-wrap gap-2 mt-1">
                    <span>{selectedOpportunity.location} ({selectedOpportunity.workMode})</span>
                    <span>•</span>
                    <span className="font-semibold text-emerald-700">{selectedOpportunity.stipendOrSalary}</span>
                    <span>•</span>
                    <span>Deadline: {selectedOpportunity.deadline}</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setSelectedOpportunity(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-md"
              >
                ✕
              </button>
            </div>

            {/* Content with 5-Pillar Score Rationale */}
            <div className="p-6 space-y-6 max-h-[65vh] overflow-y-auto text-xs sm:text-sm">
              {/* Overall Match Score Banner */}
              <div className="p-4 rounded-2xl bg-indigo-50/60 border border-indigo-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-2xl font-black text-indigo-600 font-mono">
                      {selectedOppMatch.overallScore}%
                    </span>
                    <span className="text-xs font-bold text-indigo-900">
                      Overall Candidate Fit Score
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">
                    {selectedOppMatch.matchReasons[0] || 'Strong alignment across core competency requirements and education prerequisites.'}
                  </p>
                </div>
                <button
                  onClick={() => handleToggleSave(selectedOpportunity.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition border shrink-0 ${
                    savedOpportunityIds.includes(selectedOpportunity.id)
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {savedOpportunityIds.includes(selectedOpportunity.id) ? 'Saved' : 'Save Opportunity'}
                </button>
              </div>

              {/* 5-Pillar Breakdown Bars */}
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                  Transparent 5-Pillar Match Breakdown
                </h3>
                <div className="space-y-2.5">
                  {[
                    { label: 'Skills Alignment (Weight 40%)', score: selectedOppMatch.skillsScore },
                    { label: 'Degree & Academic Level (Weight 20%)', score: selectedOppMatch.educationScore },
                    { label: 'Verified Project Evidence (Weight 20%)', score: selectedOppMatch.experienceScore },
                    { label: 'Work Mode & Location (Weight 10%)', score: selectedOppMatch.locationScore },
                    { label: 'Eligibility & Deadlines (Weight 10%)', score: selectedOppMatch.eligibilityScore }
                  ].map((p, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between text-xs font-medium text-slate-700">
                        <span>{p.label}</span>
                        <span className="font-mono font-bold text-slate-900">{p.score}%</span>
                      </div>
                      <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                        <div className="bg-indigo-600 h-full rounded-full" style={{ width: `${p.score}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Matched vs Missing Skills */}
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="p-3.5 rounded-2xl bg-emerald-50/50 border border-emerald-200">
                  <span className="text-[11px] font-bold text-emerald-900 block mb-2">
                    Verified Competencies Matched ({selectedOppMatch.matchedSkills.length})
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {selectedOppMatch.matchedSkills.map((s, idx) => (
                      <span key={idx} className="text-[10px] font-bold bg-white text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded">
                        ✓ {s}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-amber-50/50 border border-amber-200">
                  <span className="text-[11px] font-bold text-amber-900 block mb-2">
                    Skills to Bridge ({selectedOppMatch.missingSkills.length})
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {selectedOppMatch.missingSkills.map((s, idx) => (
                      <span key={idx} className="text-[10px] font-bold bg-white text-amber-800 border border-amber-200 px-2 py-0.5 rounded">
                        + {s}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Description & Responsibilities */}
              <div className="space-y-3 pt-2">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Role Description & Scope
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {selectedOpportunity.description}
                </p>

                <div className="pt-2">
                  <h4 className="text-xs font-bold text-slate-800 mb-1">Key Responsibilities</h4>
                  <ul className="list-disc list-inside text-xs text-slate-600 space-y-1">
                    {selectedOpportunity.responsibilities.map((r, idx) => (
                      <li key={idx}>{r}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <span className="text-xs text-slate-400">
                Source: {selectedOpportunity.source}
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setSelectedOpportunity(null)}
                  className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-200 rounded-xl transition"
                >
                  Close
                </button>

                {appliedOpportunityIds.includes(selectedOpportunity.id) ? (
                  <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-4 py-2 rounded-xl">
                    Application Submitted
                  </span>
                ) : (
                  <button
                    onClick={() => {
                      handleApplyOpportunity(selectedOpportunity);
                      setSelectedOpportunity(null);
                    }}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-5 py-2 rounded-xl transition shadow-xs"
                  >
                    Submit Verified Application
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* COMPANY DETAIL MODAL */}
      {selectedCompany && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-6 border-b border-slate-200 flex items-start justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-2xl ${selectedCompany.logoBg} text-white font-black text-sm flex items-center justify-center shrink-0 shadow-2xs`}>
                  {selectedCompany.logoText}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-bold text-slate-900">{selectedCompany.name}</h2>
                    <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded font-bold">
                      Enterprise Partner
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">{selectedCompany.industry} · {selectedCompany.headquarters}</p>
                </div>
              </div>
              <button onClick={() => setSelectedCompany(null)} className="p-1 text-slate-400 hover:text-slate-700 rounded-md">
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4 max-h-[60vh] overflow-y-auto text-xs text-slate-600 leading-relaxed">
              <p>{selectedCompany.description}</p>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <div><strong>Company Size:</strong> {selectedCompany.companySize}</div>
                <div><strong>Website:</strong> <a href={selectedCompany.website} target="_blank" rel="noreferrer" className="text-indigo-600 hover:underline">{selectedCompany.website}</a></div>
                <div><strong>Active Drives:</strong> {selectedCompany.activeOpportunitiesCount} openings</div>
              </div>

              <div>
                <h4 className="font-bold text-slate-800 mb-1.5">Industry Domains & Focus</h4>
                <div className="flex flex-wrap gap-1">
                  {selectedCompany.tags.map((t, idx) => (
                    <span key={idx} className="text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded">
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-between items-center">
              <button
                onClick={() => {
                  setSelectedCompany(null);
                  setCurrentView('opportunities');
                }}
                className="text-xs font-bold text-indigo-600 hover:underline"
              >
                View open campus drives for {selectedCompany.name} →
              </button>
              <button
                onClick={() => setSelectedCompany(null)}
                className="px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-200 rounded-xl transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
