import React, { useState } from 'react';
import { 
  Layers, 
  Plus, 
  ShieldCheck, 
  CheckCircle2, 
  ExternalLink, 
  Filter, 
  Award, 
  BookOpen, 
  FolderGit2, 
  Briefcase, 
  GraduationCap, 
  FileText,
  X,
  Search
} from 'lucide-react';
import { UserSkill, SkillCategory, SkillLevel, EvidenceType, SkillEvidence } from '../types';
import { CANONICAL_SKILLS } from '../data/skills';

interface SkillMapProps {
  skills: UserSkill[];
  onAddEvidence: (skillId: string, evidence: SkillEvidence) => void;
  onAddNewSkill: (newSkill: UserSkill) => void;
}

export const SkillMap: React.FC<SkillMapProps> = ({
  skills,
  onAddEvidence,
  onAddNewSkill
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedLevel, setSelectedLevel] = useState<string>('All');
  const [activeSkillModal, setActiveSkillModal] = useState<UserSkill | null>(null);
  const [addEvidenceModalSkill, setAddEvidenceModalSkill] = useState<UserSkill | null>(null);
  const [newSkillModalOpen, setNewSkillModalOpen] = useState(false);

  // New Evidence Form State
  const [evidenceType, setEvidenceType] = useState<EvidenceType>('Project');
  const [evidenceTitle, setEvidenceTitle] = useState('');
  const [evidencePlatform, setEvidencePlatform] = useState('');
  const [evidenceUrl, setEvidenceUrl] = useState('');
  const [evidenceGrade, setEvidenceGrade] = useState('');

  // New Skill Form State
  const [selectedCanonicalSkillId, setSelectedCanonicalSkillId] = useState('');
  const [selectedNewSkillLevel, setSelectedNewSkillLevel] = useState<SkillLevel>('Intermediate');

  const categories: string[] = [
    'All',
    'Programming',
    'Engineering',
    'Data',
    'AI/ML',
    'Design',
    'Business',
    'Communication',
    'Leadership',
    'Domain-specific'
  ];

  const levels: string[] = ['All', 'Beginner', 'Developing', 'Intermediate', 'Advanced', 'Expert'];

  const filteredSkills = skills.filter(s => {
    const matchesCat = selectedCategory === 'All' || s.category === selectedCategory;
    const matchesLevel = selectedLevel === 'All' || s.level === selectedLevel;
    return matchesCat && matchesLevel;
  });

  const handleCreateEvidence = (e: React.FormEvent) => {
    e.preventDefault();
    if (!addEvidenceModalSkill || !evidenceTitle.trim()) return;

    const newEvidence: SkillEvidence = {
      id: `ev-${Date.now()}`,
      type: evidenceType,
      title: evidenceTitle.trim(),
      organizationOrPlatform: evidencePlatform.trim() || undefined,
      urlOrCredentialId: evidenceUrl.trim() || undefined,
      gradeOrScore: evidenceGrade.trim() || undefined,
      dateCompleted: new Date().toISOString().split('T')[0],
      verified: true // In SkillOrbit verified workflow
    };

    onAddEvidence(addEvidenceModalSkill.id, newEvidence);
    setAddEvidenceModalSkill(null);
    setEvidenceTitle('');
    setEvidencePlatform('');
    setEvidenceUrl('');
    setEvidenceGrade('');
  };

  const handleCreateSkill = (e: React.FormEvent) => {
    e.preventDefault();
    const canonical = CANONICAL_SKILLS.find(c => c.id === selectedCanonicalSkillId);
    if (!canonical) return;

    const newSkill: UserSkill = {
      id: `us-${Date.now()}`,
      skillId: canonical.id,
      name: canonical.name,
      category: canonical.category,
      level: selectedNewSkillLevel,
      proficiencyScore: selectedNewSkillLevel === 'Expert' ? 95 : selectedNewSkillLevel === 'Advanced' ? 85 : selectedNewSkillLevel === 'Intermediate' ? 70 : 50,
      verified: false,
      evidence: []
    };

    onAddNewSkill(newSkill);
    setNewSkillModalOpen(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Skill Map Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded">
              Verified Graph
            </span>
            <span className="text-xs text-slate-500 font-medium">
              Evidence-Backed Architecture
            </span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight mt-1">
            Skill Map & Constellation
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 max-w-2xl mt-1">
            SkillOrbit eliminates unverified self-ratings. Every proficiency badge requires documented proof through project repositories, proctored assessments, or university course transcripts.
          </p>
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          <button
            onClick={() => setNewSkillModalOpen(true)}
            className="flex-1 md:flex-none flex items-center justify-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Map New Skill</span>
          </button>
        </div>
      </div>

      {/* Filter Controls Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs space-y-3">
        {/* Category Tabs */}
        <div>
          <div className="text-[11px] font-bold uppercase text-slate-400 mb-2">Category:</div>
          <div className="flex flex-wrap gap-1.5">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                  selectedCategory === cat
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Level Filters */}
        <div className="pt-2 border-t border-slate-100 flex items-center gap-3">
          <span className="text-[11px] font-bold uppercase text-slate-400">Proficiency Level:</span>
          <div className="flex flex-wrap gap-1.5">
            {levels.map((lvl) => (
              <button
                key={lvl}
                onClick={() => setSelectedLevel(lvl)}
                className={`px-2.5 py-1 rounded-md text-xs font-medium transition ${
                  selectedLevel === lvl
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {lvl}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Skills Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSkills.map((skill) => {
          const verifiedEvidenceCount = skill.evidence.filter(e => e.verified).length;
          return (
            <div
              key={skill.id}
              className="bg-white rounded-2xl border border-slate-200 hover:border-indigo-500 hover:shadow-md transition-all p-5 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      {skill.category}
                    </span>
                    <h3 className="text-base font-bold text-slate-900 mt-0.5">
                      {skill.name}
                    </h3>
                  </div>
                  <div className="flex items-center gap-1">
                    {skill.verified ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                        <ShieldCheck className="w-3.5 h-3.5" /> Verified
                      </span>
                    ) : (
                      <span className="text-[11px] font-medium text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full">
                        Evidence Needed
                      </span>
                    )}
                  </div>
                </div>

                {/* Level Badge & Score Meter */}
                <div className="mt-4 flex items-center justify-between">
                  <span className={`text-xs font-extrabold px-2.5 py-1 rounded-lg ${
                    skill.level === 'Expert' ? 'bg-purple-100 text-purple-800' :
                    skill.level === 'Advanced' ? 'bg-indigo-100 text-indigo-800' :
                    skill.level === 'Intermediate' ? 'bg-blue-100 text-blue-800' :
                    'bg-slate-100 text-slate-700'
                  }`}>
                    {skill.level} Level
                  </span>
                  <span className="text-xs font-mono font-bold text-slate-700">
                    {skill.proficiencyScore} / 100
                  </span>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-100 h-2 rounded-full mt-2 overflow-hidden">
                  <div 
                    className="bg-indigo-600 h-full rounded-full" 
                    style={{ width: `${skill.proficiencyScore}%` }}
                  />
                </div>

                {/* Evidence Summary */}
                <div className="mt-4 pt-3 border-t border-slate-100 space-y-1.5">
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span>Attached Evidence:</span>
                    <strong className="text-slate-800">{skill.evidence.length} artifact(s)</strong>
                  </div>

                  {skill.evidence.slice(0, 2).map((ev) => (
                    <div key={ev.id} className="text-[11px] text-slate-600 flex items-start gap-1.5 truncate">
                      {ev.type === 'Project' ? <FolderGit2 className="w-3 h-3 text-indigo-600 shrink-0 mt-0.5" /> :
                       ev.type === 'Assessment' ? <Award className="w-3 h-3 text-emerald-600 shrink-0 mt-0.5" /> :
                       <BookOpen className="w-3 h-3 text-slate-400 shrink-0 mt-0.5" />}
                      <span className="truncate">{ev.title}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Card Footer Actions */}
              <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                <button
                  onClick={() => setAddEvidenceModalSkill(skill)}
                  className="flex items-center gap-1 text-xs font-bold text-indigo-600 hover:text-indigo-800 transition"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Attach Evidence</span>
                </button>
                <button
                  onClick={() => setActiveSkillModal(skill)}
                  className="text-xs font-semibold text-slate-500 hover:text-slate-800 transition"
                >
                  View Details
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Attach Evidence Modal */}
      {addEvidenceModalSkill && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Attach Evidence: {addEvidenceModalSkill.name}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  All submitted evidence is validated for placement readiness verification
                </p>
              </div>
              <button 
                onClick={() => setAddEvidenceModalSkill(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-md"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateEvidence} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Evidence Type</label>
                <select
                  value={evidenceType}
                  onChange={(e) => setEvidenceType(e.target.value as EvidenceType)}
                  className="w-full text-xs rounded-lg border border-slate-200 p-2.5 bg-white text-slate-800 font-medium"
                >
                  <option value="Project">Personal / Open-Source Project</option>
                  <option value="Certification">Industry Certification</option>
                  <option value="Course">Online / University Course</option>
                  <option value="Internship">Prior Internship Experience</option>
                  <option value="Academic Subject">University Semester Subject</option>
                  <option value="Assessment">SkillOrbit Proctored Assessment</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Title / Repository / Credential Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Distributed Task Queue in Go or AWS Certified Developer"
                  value={evidenceTitle}
                  onChange={(e) => setEvidenceTitle(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-200 p-2.5 text-slate-800 outline-hidden focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Organization / Platform</label>
                  <input
                    type="text"
                    placeholder="e.g. GitHub, DeepLearning.AI, MUJ"
                    value={evidencePlatform}
                    onChange={(e) => setEvidencePlatform(e.target.value)}
                    className="w-full text-xs rounded-lg border border-slate-200 p-2.5 text-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Grade / Score / Metric</label>
                  <input
                    type="text"
                    placeholder="e.g. Grade A+, 95/100, 150 Stars"
                    value={evidenceGrade}
                    onChange={(e) => setEvidenceGrade(e.target.value)}
                    className="w-full text-xs rounded-lg border border-slate-200 p-2.5 text-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Proof URL / Credential ID</label>
                <input
                  type="text"
                  placeholder="https://github.com/... or Credential ID"
                  value={evidenceUrl}
                  onChange={(e) => setEvidenceUrl(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-200 p-2.5 text-slate-800"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setAddEvidenceModalSkill(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition shadow-xs"
                >
                  Submit for Verification
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Map New Skill Modal */}
      {newSkillModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Add Skill to Career Map
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Select canonical industry competency to track
                </p>
              </div>
              <button 
                onClick={() => setNewSkillModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-md"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSkill} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Select Skill</label>
                <select
                  required
                  value={selectedCanonicalSkillId}
                  onChange={(e) => setSelectedCanonicalSkillId(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-200 p-2.5 bg-white text-slate-800"
                >
                  <option value="">-- Choose from SkillOrbit Canonical Registry --</option>
                  {CANONICAL_SKILLS.map((cs) => (
                    <option key={cs.id} value={cs.id}>
                      {cs.name} ({cs.category})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Current Competency Level</label>
                <select
                  value={selectedNewSkillLevel}
                  onChange={(e) => setSelectedNewSkillLevel(e.target.value as SkillLevel)}
                  className="w-full text-xs rounded-lg border border-slate-200 p-2.5 bg-white text-slate-800"
                >
                  <option value="Beginner">Beginner (Foundational)</option>
                  <option value="Developing">Developing (Active Practice)</option>
                  <option value="Intermediate">Intermediate (Project Demonstrated)</option>
                  <option value="Advanced">Advanced (Production Experience)</option>
                  <option value="Expert">Expert (Architecture Authority)</option>
                </select>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setNewSkillModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!selectedCanonicalSkillId}
                  className="px-4 py-2 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-lg transition shadow-xs"
                >
                  Add to Orbit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Skill Details & Evidence Viewer Modal */}
      {activeSkillModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  {activeSkillModal.category}
                </span>
                <h3 className="text-lg font-bold text-slate-900">
                  {activeSkillModal.name}
                </h3>
              </div>
              <button 
                onClick={() => setActiveSkillModal(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-md"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              <div className="flex items-center justify-between bg-slate-50 p-3 rounded-xl">
                <div>
                  <span className="text-xs text-slate-500 block">Assessed Level</span>
                  <span className="text-sm font-bold text-slate-900">{activeSkillModal.level}</span>
                </div>
                <div>
                  <span className="text-xs text-slate-500 block">Proficiency Score</span>
                  <span className="text-sm font-mono font-bold text-indigo-600">{activeSkillModal.proficiencyScore} / 100</span>
                </div>
                <div>
                  <span className="text-xs text-slate-500 block">Verification Status</span>
                  <span className="text-xs font-bold text-emerald-700 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" /> Verified
                  </span>
                </div>
              </div>

              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Verified Evidence Artifacts ({activeSkillModal.evidence.length})
                </h4>
                {activeSkillModal.evidence.length === 0 ? (
                  <p className="text-xs text-slate-400 italic">No evidence attached yet. Attach project repositories or course certificates.</p>
                ) : (
                  <div className="space-y-2">
                    {activeSkillModal.evidence.map((ev) => (
                      <div key={ev.id} className="p-3 rounded-xl border border-slate-200 bg-white flex items-start justify-between gap-3 text-xs">
                        <div>
                          <div className="font-bold text-slate-900 flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            <span>{ev.title}</span>
                          </div>
                          <div className="text-slate-500 text-[11px] mt-0.5">
                            {ev.type} · {ev.organizationOrPlatform} · {ev.dateCompleted}
                          </div>
                          {ev.gradeOrScore && (
                            <span className="inline-block mt-1 font-semibold text-indigo-600 text-[10px] bg-indigo-50 px-1.5 py-0.5 rounded">
                              {ev.gradeOrScore}
                            </span>
                          )}
                        </div>
                        {ev.urlOrCredentialId && (
                          <a
                            href={ev.urlOrCredentialId}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1.5 text-slate-400 hover:text-indigo-600 transition shrink-0"
                            title="Open external evidence proof"
                          >
                            <ExternalLink className="w-4 h-4" />
                          </a>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setActiveSkillModal(null)}
                className="px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-200 rounded-lg transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
