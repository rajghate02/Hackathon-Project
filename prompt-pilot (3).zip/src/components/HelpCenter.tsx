import React, { useState, useMemo } from 'react';
import { 
  HelpCircle, 
  Search, 
  BookOpen, 
  Send, 
  ShieldCheck, 
  FileText, 
  ArrowRight, 
  CheckCircle2, 
  X,
  MessageSquare,
  AlertCircle
} from 'lucide-react';
import { HelpArticle, SupportTicket } from '../types';
import { HELP_ARTICLES_DATA } from '../data/helpArticles';

export const HelpCenter: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [readingArticle, setReadingArticle] = useState<HelpArticle | null>(null);

  // Ticket Form
  const [category, setCategory] = useState('Verification');
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<'Low' | 'Medium' | 'High'>('Medium');
  const [submittedTicket, setSubmittedTicket] = useState<SupportTicket | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const categories = [
    'All',
    'Getting Started',
    'Account',
    'Login',
    'Verification',
    'Profile',
    'Skills',
    'Careers',
    'Internships',
    'Applications',
    'Universities',
    'Companies',
    'Privacy',
    'Security',
    'Frequently Asked Questions'
  ];

  const filteredArticles = useMemo(() => {
    return HELP_ARTICLES_DATA.filter(art => {
      const matchesCat = selectedCategory === 'All' || art.category === selectedCategory;
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch = !q || 
        art.title.toLowerCase().includes(q) ||
        art.summary.toLowerCase().includes(q) ||
        art.tags.some(t => t.toLowerCase().includes(q));
      return matchesCat && matchesSearch;
    });
  }, [searchQuery, selectedCategory]);

  const handleSubmitTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() || !description.trim()) return;

    setSubmitting(true);
    try {
      const res = await fetch('/api/support/ticket', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: 'usr-student-1',
          userEmail: 'student@jaipur.manipal.edu',
          userName: 'Aarav Sharma',
          category,
          subject: subject.trim(),
          description: description.trim(),
          priority
        })
      });
      const data = await res.json();
      if (data.success) {
        setSubmittedTicket(data.ticket);
        setSubject('');
        setDescription('');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded">
              Knowledge Base
            </span>
            <span className="text-xs text-slate-500 font-medium">
              Enterprise Help & Compliance Docs
            </span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight mt-1">
            SkillOrbit Help Center & Support
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 max-w-2xl mt-1">
            Everything you need to know about institutional verification, skill map evidence submission, recruiter discovery, and data governance.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-semibold text-slate-600 bg-slate-50 px-3.5 py-2 rounded-xl border border-slate-200">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>Priority response for accredited university students</span>
        </div>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search help articles (e.g. 'verification', 'evidence', 'match breakdown', 'privacy')..."
          className="w-full text-xs sm:text-sm pl-11 pr-4 py-3 rounded-2xl border border-slate-200 outline-hidden focus:border-indigo-600 bg-white font-medium text-slate-800 placeholder:text-slate-400 shadow-xs"
        />
      </div>

      {/* Category Pills */}
      <div className="flex flex-wrap gap-1.5 overflow-x-auto text-xs">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 rounded-xl font-semibold transition shrink-0 ${
              selectedCategory === cat
                ? 'bg-indigo-600 text-white shadow-2xs'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Articles Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredArticles.map((art) => (
          <div
            key={art.id}
            onClick={() => setReadingArticle(art)}
            className="bg-white rounded-2xl border border-slate-200 hover:border-indigo-500 hover:shadow-md transition-all p-5 cursor-pointer flex flex-col justify-between group"
          >
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                {art.category}
              </span>
              <h3 className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition mt-2">
                {art.title}
              </h3>
              <p className="text-xs text-slate-600 mt-1.5 line-clamp-2 leading-relaxed">
                {art.summary}
              </p>
              <div className="flex flex-wrap gap-1 mt-3">
                {art.tags.map((t, idx) => (
                  <span key={idx} className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">
                    #{t}
                  </span>
                ))}
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-indigo-600 font-semibold">
              <span>Read article</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition" />
            </div>
          </div>
        ))}
      </div>

      {/* Support Ticket Section */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              Submit an Enterprise Support Request
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Dedicated assistance for institutional verification, skill credential appeals, and company inquiries
            </p>
          </div>
          <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200 self-start sm:self-auto">
            SLA: &lt; 24h Resolution
          </span>
        </div>

        {submittedTicket && (
          <div className="mt-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs space-y-1">
            <div className="font-bold flex items-center gap-1.5 text-emerald-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Ticket {submittedTicket.ticketNumber} Logged Successfully!</span>
            </div>
            <p>Our academic compliance team has been notified. You can track status: <strong className="font-semibold">{submittedTicket.status}</strong>.</p>
          </div>
        )}

        <form onSubmit={handleSubmitTicket} className="mt-6 space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full text-xs rounded-lg border border-slate-200 p-2.5 bg-white text-slate-800 font-medium"
              >
                <option value="Verification">Institutional Domain & Identity Verification</option>
                <option value="Skills">Skill Evidence Review & Badging</option>
                <option value="Applications">Internship & Drive Applications</option>
                <option value="Security">Privacy, Recruiter Visibility & Security</option>
                <option value="General">Other Inquiries</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Priority</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as any)}
                className="w-full text-xs rounded-lg border border-slate-200 p-2.5 bg-white text-slate-800 font-medium"
              >
                <option value="Low">Low (General guidance)</option>
                <option value="Medium">Medium (Standard request)</option>
                <option value="High">High (Upcoming placement drive deadline)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Subject</label>
            <input
              type="text"
              required
              placeholder="e.g. Need priority domain verification for upcoming Google SWE drive"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full text-xs rounded-lg border border-slate-200 p-2.5 text-slate-800 outline-hidden focus:border-indigo-600"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Detailed Description</label>
            <textarea
              rows={4}
              required
              placeholder="Provide all relevant details (e.g. Student ID, university department, error codes)..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full text-xs rounded-lg border border-slate-200 p-2.5 text-slate-800 outline-hidden focus:border-indigo-600"
            />
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              disabled={submitting}
              className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-5 py-2.5 rounded-xl transition shadow-xs flex items-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{submitting ? 'Submitting...' : 'Dispatch Ticket'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* Reading Article Modal */}
      {readingArticle && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-6 border-b border-slate-200 flex items-start justify-between gap-4">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                  {readingArticle.category}
                </span>
                <h2 className="text-lg font-bold text-slate-900 mt-1">
                  {readingArticle.title}
                </h2>
              </div>
              <button
                onClick={() => setReadingArticle(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-md"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 max-h-[65vh] overflow-y-auto text-xs sm:text-sm text-slate-700 leading-relaxed">
              <p className="font-semibold text-slate-900 bg-slate-50 p-3 rounded-xl border border-slate-200">
                {readingArticle.summary}
              </p>

              {readingArticle.content.map((paragraph, idx) => (
                <p key={idx}>{paragraph}</p>
              ))}

              <div className="pt-4 border-t border-slate-100 flex flex-wrap gap-1">
                {readingArticle.tags.map((t, idx) => (
                  <span key={idx} className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded">
                    #{t}
                  </span>
                ))}
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setReadingArticle(null)}
                className="px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-200 rounded-lg transition"
              >
                Done Reading
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
