import React, { useState } from 'react';
import { 
  Building2, 
  Users, 
  Plus, 
  Search, 
  Filter, 
  Briefcase, 
  ShieldCheck, 
  GraduationCap, 
  CheckCircle2, 
  Send, 
  X, 
  Clock,
  ArrowRight
} from 'lucide-react';
import { Opportunity, OpportunityType, WorkMode, StudentProfile } from '../types';

interface RecruiterDashboardProps {
  onAddNewOpportunity: (newOpp: Opportunity) => void;
  existingOpportunities: Opportunity[];
}

export const RecruiterDashboard: React.FC<RecruiterDashboardProps> = ({
  onAddNewOpportunity,
  existingOpportunities
}) => {
  const [postModalOpen, setPostModalOpen] = useState(false);
  const [candidateFilterSkill, setCandidateFilterSkill] = useState('All');
  const [candidateMinCgpa, setCandidateMinCgpa] = useState<number>(7.5);
  const [selectedUniversityFilter, setSelectedUniversityFilter] = useState('All');

  // Post form state
  const [title, setTitle] = useState('');
  const [type, setType] = useState<OpportunityType>('Internship');
  const [workMode, setWorkMode] = useState<WorkMode>('Hybrid');
  const [location, setLocation] = useState('Bengaluru / Hyderabad');
  const [stipend, setStipend] = useState('₹1,10,000/mo');
  const [deadline, setDeadline] = useState('2026-05-30');
  const [skillsReq, setSkillsReq] = useState('C++, Python, Distributed Systems');
  const [description, setDescription] = useState('');
  const [expandedCandidateId, setExpandedCandidateId] = useState<string | null>('cand-1');

  const mockCandidates = [
    {
      id: 'cand-1',
      name: 'Aarav Sharma',
      university: 'Manipal University Jaipur',
      degree: 'BTech CSE',
      cgpa: 8.82,
      placementReadiness: 78,
      verifiedSkills: ['Python', 'C++', 'Java', 'Data Structures & Algorithms', 'PostgreSQL'],
      verified: true,
      skillsAudit: [
        { skill: 'Python', status: 'Professionally-Verified', performance: 'Advanced (847/1000)' },
        { skill: 'C++', status: 'Professionally-Verified', performance: 'Intermediate (790/1000)' },
        { skill: 'Data Structures & Algorithms', status: 'Professionally-Verified', performance: 'Advanced (912/1000)' },
        { skill: 'Java', status: 'Self-Declared', performance: 'Not Assessed' },
        { skill: 'PostgreSQL', status: 'Self-Declared', performance: 'Not Assessed' },
      ]
    },
    {
      id: 'cand-2',
      name: 'Pooja Iyer',
      university: 'Manipal Academy of Higher Education (MAHE)',
      degree: 'BTech Data Science',
      cgpa: 9.15,
      placementReadiness: 84,
      verifiedSkills: ['Python', 'Machine Learning', 'TensorFlow', 'SQL'],
      verified: true,
      skillsAudit: [
        { skill: 'Python', status: 'Professionally-Verified', performance: 'Advanced (910/1000)' },
        { skill: 'Machine Learning', status: 'Professionally-Verified', performance: 'Advanced (880/1000)' },
        { skill: 'TensorFlow', status: 'Self-Declared', performance: 'Not Assessed' },
        { skill: 'SQL', status: 'Professionally-Verified', performance: 'Intermediate (760/1000)' },
      ]
    },
    {
      id: 'cand-3',
      name: 'Rohan Mehra',
      university: 'Indian Institute of Technology Bombay',
      degree: 'BTech Electrical Engineering',
      cgpa: 8.94,
      placementReadiness: 86,
      verifiedSkills: ['C++', 'Low-Latency Systems', 'Algorithms'],
      verified: true,
      skillsAudit: [
        { skill: 'C++', status: 'Professionally-Verified', performance: 'Expert (940/1000)' },
        { skill: 'Algorithms', status: 'Professionally-Verified', performance: 'Advanced (895/1000)' },
        { skill: 'Low-Latency Systems', status: 'Self-Declared', performance: 'Not Assessed' },
      ]
    },
    {
      id: 'cand-4',
      name: 'Sneha Kulkarni',
      university: 'Delhi Technological University (DTU)',
      degree: 'MTech Software Engineering',
      cgpa: 8.45,
      placementReadiness: 82,
      verifiedSkills: ['Distributed Systems', 'Kubernetes', 'Go'],
      verified: true,
      skillsAudit: [
        { skill: 'Distributed Systems', status: 'Professionally-Verified', performance: 'Advanced (870/1000)' },
        { skill: 'Go', status: 'Professionally-Verified', performance: 'Intermediate (780/1000)' },
        { skill: 'Kubernetes', status: 'Self-Declared', performance: 'Not Assessed' },
      ]
    }
  ];

  const filteredCandidates = mockCandidates.filter(c => {
    const matchesCgpa = c.cgpa >= candidateMinCgpa;
    const matchesUni = selectedUniversityFilter === 'All' || c.university === selectedUniversityFilter;
    const matchesSkill = candidateFilterSkill === 'All' || c.verifiedSkills.some(s => s.toLowerCase().includes(candidateFilterSkill.toLowerCase()));
    return matchesCgpa && matchesUni && matchesSkill;
  });

  const handleCreatePosting = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) return;

    const newOpp: Opportunity = {
      id: `opp-${Date.now()}`,
      title: title.trim(),
      companyId: 'comp-nvidia',
      companyName: 'NVIDIA Corporation',
      companyLogoBg: 'bg-emerald-600',
      industry: 'Technology',
      type,
      workMode,
      location: location.trim(),
      stipendOrSalary: stipend.trim(),
      eligibility: 'Minimum 7.5 CGPA; no active academic backlogs',
      deadline: deadline.trim(),
      source: 'Direct Campus Recruiter Feed',
      sourceType: 'Verified Partner',
      applicationUrl: 'https://skillorbit.app/apply',
      dateDiscovered: new Date().toISOString().split('T')[0],
      lastUpdated: new Date().toISOString().split('T')[0],
      isDemoData: false,
      description: description.trim(),
      responsibilities: [
        'Design and deploy production-grade software features',
        'Participate in high-scale code reviews and distributed systems debugging'
      ],
      qualifications: [
        'Strong computer science fundamentals and algorithmic problem solving',
        'Hands-on project experience with modern languages and version control'
      ],
      requiredSkills: skillsReq.split(',').map(s => s.trim()),
      preferredSkills: ['Git', 'Docker', 'Linux'],
      degreeRequirements: ['BTech', 'MTech']
    };

    onAddNewOpportunity(newOpp);
    setPostModalOpen(false);
    setTitle('');
    setDescription('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-start gap-4">
          <div className="w-16 h-16 rounded-2xl bg-emerald-600 text-white font-black text-xl flex items-center justify-center shrink-0 shadow-sm">
            NVD
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                Recruiter Portal · NVIDIA University Talent
              </h1>
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                Enterprise Talent Partner
              </span>
            </div>
            <p className="text-sm text-slate-600 font-medium mt-1">
              Lead Recruiter: Sonia Kapoor · Talent Acquisition (India & Global University Programs)
            </p>
            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500 mt-2">
              <span>Verified Campus Registry: <strong>Active</strong></span>
              <span>•</span>
              <span>Direct Applications Received: <strong>142</strong></span>
              <span>•</span>
              <span>Active Campus Postings: <strong>{existingOpportunities.filter(o => o.companyName.includes('NVIDIA')).length || 2}</strong></span>
            </div>
          </div>
        </div>

        <button
          onClick={() => setPostModalOpen(true)}
          className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition shadow-xs flex items-center gap-1.5"
        >
          <Plus className="w-4 h-4" />
          <span>Publish New Campus Drive</span>
        </button>
      </div>

      {/* Candidate Talent Pool Filter Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Users className="w-4 h-4 text-indigo-600" />
            <span>Search Verified University Talent Pool</span>
          </h3>
          <span className="text-xs text-slate-500">{filteredCandidates.length} candidate profiles matching criteria</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div>
            <label className="block text-[11px] font-bold text-slate-500 mb-1">Target Skill</label>
            <select
              value={candidateFilterSkill}
              onChange={(e) => setCandidateFilterSkill(e.target.value)}
              className="w-full rounded-lg border border-slate-200 p-2 text-slate-800 bg-white font-medium"
            >
              <option value="All">All Verified Skills</option>
              <option value="Python">Python</option>
              <option value="C++">C++</option>
              <option value="Distributed Systems">Distributed Systems</option>
              <option value="Kubernetes">Kubernetes</option>
              <option value="Machine Learning">Machine Learning</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-500 mb-1">Partner University</label>
            <select
              value={selectedUniversityFilter}
              onChange={(e) => setSelectedUniversityFilter(e.target.value)}
              className="w-full rounded-lg border border-slate-200 p-2 text-slate-800 bg-white font-medium"
            >
              <option value="All">All Partner Institutions</option>
              <option value="Manipal University Jaipur">Manipal University Jaipur</option>
              <option value="Manipal Academy of Higher Education (MAHE)">Manipal Academy of Higher Education (MAHE)</option>
              <option value="Indian Institute of Technology Bombay">Indian Institute of Technology Bombay</option>
              <option value="Delhi Technological University (DTU)">Delhi Technological University (DTU)</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-500 mb-1">Min Academic CGPA ({candidateMinCgpa})</label>
            <input
              type="range"
              min="7.0"
              max="9.5"
              step="0.1"
              value={candidateMinCgpa}
              onChange={(e) => setCandidateMinCgpa(parseFloat(e.target.value))}
              className="w-full mt-2 accent-indigo-600"
            />
          </div>
        </div>
      </div>

      {/* Candidate Cards Grid */}
      <div className="grid md:grid-cols-2 gap-6">
        {filteredCandidates.map((cand) => (
          <div
            key={cand.id}
            className="bg-white rounded-2xl border border-slate-200 hover:border-indigo-500 hover:shadow-md transition-all p-5 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-1.5">
                    <h4 className="text-sm font-bold text-slate-900">{cand.name}</h4>
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">{cand.degree} · <strong className="text-slate-700">{cand.university}</strong></p>
                </div>
                <div className="text-right">
                  <span className="text-xs font-extrabold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    {cand.placementReadiness}% Ready
                  </span>
                  <div className="text-[10px] text-slate-400 font-mono mt-0.5">CGPA: {cand.cgpa}</div>
                </div>
              </div>

              {/* Verified Skills & Self-Declared Breakdown Table */}
              <div className="mt-4 pt-3 border-t border-slate-100">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-emerald-600" />
                    Verified Skills vs. Self-Declared Audit
                  </span>
                  <button
                    type="button"
                    onClick={() => setExpandedCandidateId(expandedCandidateId === cand.id ? null : cand.id)}
                    className="text-[10px] font-bold text-indigo-600 hover:text-indigo-800"
                  >
                    {expandedCandidateId === cand.id ? 'Collapse Table ▲' : 'View Breakdown ▼'}
                  </button>
                </div>

                {expandedCandidateId === cand.id ? (
                  <div className="space-y-2 mt-2 animate-in fade-in duration-150">
                    <div className="overflow-x-auto rounded-xl border border-slate-200">
                      <table className="w-full text-left text-xs border-collapse">
                        <thead>
                          <tr className="bg-slate-50 border-b border-slate-200 text-[10px] font-bold uppercase tracking-wider text-slate-500">
                            <th className="p-2">Skill</th>
                            <th className="p-2">Status</th>
                            <th className="p-2">Performance</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-[11px]">
                          {cand.skillsAudit.map((audit, idx) => (
                            <tr key={idx} className={audit.status === 'Professionally-Verified' ? 'bg-emerald-50/20' : 'bg-white'}>
                              <td className="p-2 font-semibold text-slate-900">{audit.skill}</td>
                              <td className="p-2">
                                {audit.status === 'Professionally-Verified' ? (
                                  <span className="inline-flex items-center gap-1 font-bold text-emerald-800 text-[10px]">
                                    <ShieldCheck className="w-3 h-3 text-emerald-600" />
                                    🛡️ Professionally Verified
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center gap-1 text-slate-500 text-[10px]">
                                    <span className="w-2 h-2 rounded-full border border-slate-400" />
                                    ○ Self-Declared
                                  </span>
                                )}
                              </td>
                              <td className="p-2 font-mono text-[11px] text-slate-700">
                                {audit.performance}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    {/* Explanatory Note Required by Prompt */}
                    <div className="p-2 rounded-lg bg-slate-50 border border-slate-200 text-[10px] text-slate-600 space-y-0.5 leading-relaxed">
                      <div>
                        <strong className="text-emerald-800">🛡️ Professionally Verified:</strong> This skill has been independently assessed through the platform's standardized verification process.
                      </div>
                      <div>
                        <strong className="text-slate-700">○ Self-Declared:</strong> This skill has been added by the candidate but has not yet been independently verified.
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-wrap gap-1">
                    {cand.skillsAudit.map((audit, idx) => (
                      <span
                        key={idx}
                        className={`text-[10px] font-medium px-2 py-0.5 rounded flex items-center gap-1 ${
                          audit.status === 'Professionally-Verified'
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {audit.status === 'Professionally-Verified' ? '🛡️' : '○'} {audit.skill}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between">
              <span className="text-[11px] text-slate-400">Institutional SSO Authenticated</span>
              <button
                onClick={() => alert(`Interview invitation dispatch simulated for ${cand.name} (${cand.university})!`)}
                className="bg-slate-900 hover:bg-indigo-600 text-white text-xs font-bold px-3 py-1.5 rounded-lg transition"
              >
                Send Interview Invitation
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Publish New Drive Modal */}
      {postModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Publish New Opportunity / Campus Drive
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Post to accredited university placement portals
                </p>
              </div>
              <button 
                onClick={() => setPostModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-md"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePosting} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Role Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. AI Performance Software Engineering Intern"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-200 p-2.5 text-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Opportunity Type</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as OpportunityType)}
                    className="w-full text-xs rounded-lg border border-slate-200 p-2.5 bg-white text-slate-800"
                  >
                    <option value="Internship">Internship</option>
                    <option value="Full-time Job">Full-time Job</option>
                    <option value="Research Project">Research Project</option>
                    <option value="Hackathon">Hackathon</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Work Mode</label>
                  <select
                    value={workMode}
                    onChange={(e) => setWorkMode(e.target.value as WorkMode)}
                    className="w-full text-xs rounded-lg border border-slate-200 p-2.5 bg-white text-slate-800"
                  >
                    <option value="Remote">Remote</option>
                    <option value="Hybrid">Hybrid</option>
                    <option value="On-site">On-site</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Location</label>
                  <input
                    type="text"
                    required
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full text-xs rounded-lg border border-slate-200 p-2.5 text-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Stipend / CTC</label>
                  <input
                    type="text"
                    required
                    value={stipend}
                    onChange={(e) => setStipend(e.target.value)}
                    className="w-full text-xs rounded-lg border border-slate-200 p-2.5 text-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Required Skills (Comma separated)</label>
                <input
                  type="text"
                  required
                  value={skillsReq}
                  onChange={(e) => setSkillsReq(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-200 p-2.5 text-slate-800"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Role Description</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Outline core responsibilities, team mission, and impact..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-200 p-2.5 text-slate-800"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setPostModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition shadow-xs"
                >
                  Publish to Campus Network
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
