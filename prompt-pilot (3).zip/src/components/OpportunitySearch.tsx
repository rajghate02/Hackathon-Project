import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Briefcase, 
  Building2, 
  MapPin, 
  Clock, 
  Filter, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  X, 
  ExternalLink, 
  Bookmark, 
  BookmarkCheck, 
  Calendar, 
  ShieldCheck, 
  Send,
  ArrowRight,
  DollarSign
} from 'lucide-react';
import { Opportunity, StudentProfile, UserSkill, OpportunityType, WorkMode, ApplicationRecord } from '../types';
import { calculateOpportunityMatch } from '../utils/matching';

interface OpportunitySearchProps {
  opportunities: Opportunity[];
  profile: StudentProfile;
  skills: UserSkill[];
  appliedOpportunityIds: string[];
  savedOpportunityIds: string[];
  onApply: (opp: Opportunity, notes?: string) => void;
  onToggleSave: (oppId: string) => void;
  selectedOpportunityForModal?: Opportunity | null;
  onCloseModal?: () => void;
}

export const OpportunitySearch: React.FC<OpportunitySearchProps> = ({
  opportunities,
  profile,
  skills,
  appliedOpportunityIds,
  savedOpportunityIds,
  onApply,
  onToggleSave,
  selectedOpportunityForModal,
  onCloseModal
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('All');
  const [selectedWorkMode, setSelectedWorkMode] = useState<string>('All');
  const [selectedIndustry, setSelectedIndustry] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'match' | 'deadline' | 'recent'>('match');
  const [activeModalOpp, setActiveModalOpp] = useState<Opportunity | null>(selectedOpportunityForModal || null);
  const [applicationSuccessMsg, setApplicationSuccessMsg] = useState<string | null>(null);

  // Sync if selectedOpportunityForModal changes from parent
  React.useEffect(() => {
    if (selectedOpportunityForModal) {
      setActiveModalOpp(selectedOpportunityForModal);
    }
  }, [selectedOpportunityForModal]);

  // Scored & Filtered Opportunities
  const filteredAndScored = useMemo(() => {
    let result = opportunities.map(opp => ({
      opp,
      match: calculateOpportunityMatch(opp, profile, skills)
    }));

    // Filter by type
    if (selectedType !== 'All') {
      result = result.filter(item => item.opp.type === selectedType);
    }

    // Filter by work mode
    if (selectedWorkMode !== 'All') {
      result = result.filter(item => item.opp.workMode === selectedWorkMode);
    }

    // Filter by industry
    if (selectedIndustry !== 'All') {
      result = result.filter(item => item.opp.industry === selectedIndustry);
    }

    // Text search
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(item => 
        item.opp.title.toLowerCase().includes(q) ||
        item.opp.companyName.toLowerCase().includes(q) ||
        item.opp.requiredSkills.some(s => s.toLowerCase().includes(q)) ||
        item.opp.location.toLowerCase().includes(q)
      );
    }

    // Sorting
    if (sortBy === 'match') {
      result.sort((a, b) => b.match.overallScore - a.match.overallScore);
    } else if (sortBy === 'deadline') {
      result.sort((a, b) => new Date(a.opp.deadline).getTime() - new Date(b.opp.deadline).getTime());
    } else if (sortBy === 'recent') {
      result.sort((a, b) => new Date(b.opp.postedDate).getTime() - new Date(a.opp.postedDate).getTime());
    }

    return result;
  }, [opportunities, profile, skills, selectedType, selectedWorkMode, selectedIndustry, searchQuery, sortBy]);

  const handleApplyClick = (opp: Opportunity) => {
    onApply(opp);
    setApplicationSuccessMsg(`Application submitted for ${opp.title} at ${opp.companyName}!`);
    setTimeout(() => {
      setApplicationSuccessMsg(null);
    }, 4000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded">
              Verified Marketplace
            </span>
            <span className="text-xs text-slate-500 font-medium">
              Enterprise & University Verified Drives
            </span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight mt-1">
            Opportunities & Internships
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 max-w-2xl mt-1">
            Every listing shows transparent match criteria, missing skills, and direct application routes for students.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-semibold text-slate-600 bg-slate-50 px-3 py-2 rounded-xl border border-slate-200">
          <Clock className="w-4 h-4 text-indigo-600" />
          <span>Feeds synchronized with live campus placement cells</span>
        </div>
      </div>

      {/* Success Notification Alert */}
      {applicationSuccessMsg && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{applicationSuccessMsg}</span>
          </div>
          <button onClick={() => setApplicationSuccessMsg(null)} className="text-emerald-600 hover:text-emerald-900">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Search & Filter Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        {/* Main Search Input */}
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by role title, company (e.g. Google, JPMorgan), required skill (e.g. Python, SQL), or city..."
            className="w-full text-xs sm:text-sm pl-10 pr-4 py-3 rounded-xl border border-slate-200 outline-hidden focus:border-indigo-600 font-medium text-slate-800 placeholder:text-slate-400"
          />
        </div>

        {/* Filter Controls */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 border-t border-slate-100 text-xs">
          <div>
            <label className="block text-[11px] font-bold text-slate-500 mb-1">Opportunity Type</label>
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="w-full rounded-lg border border-slate-200 p-2 text-slate-800 bg-white font-medium"
            >
              <option value="All">All Types</option>
              <option value="Internship">Internship</option>
              <option value="Full-time Job">Full-time Job</option>
              <option value="Research Project">Research Project</option>
              <option value="Hackathon">Hackathon</option>
              <option value="Fellowship">Fellowship</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-500 mb-1">Industry Sector</label>
            <select
              value={selectedIndustry}
              onChange={(e) => setSelectedIndustry(e.target.value)}
              className="w-full rounded-lg border border-slate-200 p-2 text-slate-800 bg-white font-medium"
            >
              <option value="All">All Sectors</option>
              <option value="Technology">Technology</option>
              <option value="Finance">Finance</option>
              <option value="Consulting">Consulting</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-500 mb-1">Work Mode</label>
            <select
              value={selectedWorkMode}
              onChange={(e) => setSelectedWorkMode(e.target.value)}
              className="w-full rounded-lg border border-slate-200 p-2 text-slate-800 bg-white font-medium"
            >
              <option value="All">All Modes</option>
              <option value="Remote">Remote</option>
              <option value="Hybrid">Hybrid</option>
              <option value="On-site">On-site</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-500 mb-1">Sort By</label>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full rounded-lg border border-slate-200 p-2 text-slate-800 bg-white font-medium"
            >
              <option value="match">Highest Match Score</option>
              <option value="deadline">Approaching Deadline</option>
              <option value="recent">Recently Posted</option>
            </select>
          </div>
        </div>
      </div>

      {/* Opportunities Count */}
      <div className="flex items-center justify-between px-1 text-xs text-slate-500">
        <span>Showing <strong>{filteredAndScored.length}</strong> verified opportunities</span>
        <span>Ranked using multi-pillar matching algorithm</span>
      </div>

      {/* Opportunities Cards Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredAndScored.map(({ opp, match }) => {
          const isApplied = appliedOpportunityIds.includes(opp.id);
          const isSaved = savedOpportunityIds.includes(opp.id);

          return (
            <div
              key={opp.id}
              className="bg-white rounded-2xl border border-slate-200 hover:border-indigo-500 hover:shadow-md transition-all p-5 flex flex-col justify-between group"
            >
              <div>
                {/* Header: Company Logo, Title, Bookmark */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-11 h-11 rounded-xl ${opp.companyLogoBg} text-white font-black text-sm flex items-center justify-center shrink-0 shadow-xs`}>
                      {opp.companyName.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition line-clamp-1">
                        {opp.title}
                      </h3>
                      <p className="text-xs text-slate-500 font-medium mt-0.5">
                        {opp.companyName} · {opp.workMode}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => onToggleSave(opp.id)}
                    className="p-1.5 text-slate-400 hover:text-indigo-600 transition rounded-lg hover:bg-slate-100"
                    title={isSaved ? "Saved in tracker" : "Save opportunity"}
                  >
                    {isSaved ? <BookmarkCheck className="w-4 h-4 text-indigo-600" /> : <Bookmark className="w-4 h-4" />}
                  </button>
                </div>

                {/* Badges: Match, Type, Freshness */}
                <div className="mt-4 flex flex-wrap items-center gap-2">
                  <span className="text-xs font-extrabold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                    {match.overallScore}% Match
                  </span>
                  <span className="text-[11px] font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-full">
                    {opp.type}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {opp.freshnessTag}
                  </span>
                </div>

                {/* Location & Compensation */}
                <div className="mt-3 text-xs text-slate-600 space-y-1">
                  <div className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{opp.location}</span>
                  </div>
                  <div className="flex items-center gap-1.5 font-semibold text-slate-900">
                    <DollarSign className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>{opp.stipendOrSalary}</span>
                  </div>
                </div>

                {/* Transparent Match Reason */}
                <div className="mt-3 p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-[11px] text-slate-600 space-y-1">
                  <div className="font-semibold text-slate-800 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    <span>Why it matches you:</span>
                  </div>
                  <p className="line-clamp-2">{match.matchReasons[0]}</p>
                </div>

                {/* Required Skills Tags */}
                <div className="mt-3 flex flex-wrap gap-1">
                  {opp.requiredSkills.slice(0, 4).map((skill, idx) => {
                    const isMatched = match.matchedSkills.includes(skill);
                    return (
                      <span
                        key={idx}
                        className={`text-[10px] font-medium px-2 py-0.5 rounded ${
                          isMatched 
                            ? 'bg-indigo-50 text-indigo-700 font-semibold' 
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {skill}
                      </span>
                    );
                  })}
                </div>
              </div>

              {/* Card Footer: Deadline & Action */}
              <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] text-slate-400 font-medium">
                  Due: {opp.deadline}
                </span>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setActiveModalOpp(opp)}
                    className="text-xs font-semibold text-slate-600 hover:text-slate-900 px-2.5 py-1.5 rounded-lg transition"
                  >
                    Details
                  </button>
                  {isApplied ? (
                    <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
                      Applied
                    </span>
                  ) : (
                    <button
                      onClick={() => handleApplyClick(opp)}
                      className="bg-slate-900 hover:bg-indigo-600 text-white text-xs font-bold px-3 py-1.5 rounded-lg transition shadow-xs"
                    >
                      Apply
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Opportunity Detail Modal */}
      {activeModalOpp && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="p-6 border-b border-slate-200 flex items-start justify-between gap-4">
              <div className="flex items-start gap-3">
                <div className={`w-12 h-12 rounded-xl ${activeModalOpp.companyLogoBg} text-white font-black text-base flex items-center justify-center shrink-0 shadow-xs`}>
                  {activeModalOpp.companyName.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      {activeModalOpp.companyName}
                    </span>
                    <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                      {activeModalOpp.verifiedListing ? 'Verified Listing' : 'Demo Listing'}
                    </span>
                  </div>
                  <h2 className="text-lg font-bold text-slate-900 mt-0.5">
                    {activeModalOpp.title}
                  </h2>
                  <p className="text-xs text-slate-500 font-medium">
                    {activeModalOpp.location} · {activeModalOpp.workMode} · {activeModalOpp.type}
                  </p>
                </div>
              </div>

              <button
                onClick={() => {
                  setActiveModalOpp(null);
                  if (onCloseModal) onCloseModal();
                }}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-md"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
              {/* Transparent Match Breakdown Box */}
              {(() => {
                const match = calculateOpportunityMatch(activeModalOpp, profile, skills);
                return (
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-indigo-600" />
                        <span className="text-xs font-bold text-slate-800">
                          Transparent Match Breakdown
                        </span>
                      </div>
                      <span className="text-xs font-extrabold text-emerald-700 bg-emerald-100/80 px-2.5 py-0.5 rounded-full">
                        {match.overallScore}% Overall Match
                      </span>
                    </div>

                    <div className="grid grid-cols-4 gap-2 text-center text-xs">
                      <div className="p-2 rounded-lg bg-white border border-slate-100">
                        <span className="text-[10px] text-slate-400 block font-medium">Skills</span>
                        <strong className="text-slate-800">{match.skillsScore}%</strong>
                      </div>
                      <div className="p-2 rounded-lg bg-white border border-slate-100">
                        <span className="text-[10px] text-slate-400 block font-medium">Education</span>
                        <strong className="text-slate-800">{match.educationScore}%</strong>
                      </div>
                      <div className="p-2 rounded-lg bg-white border border-slate-100">
                        <span className="text-[10px] text-slate-400 block font-medium">Experience</span>
                        <strong className="text-slate-800">{match.experienceScore}%</strong>
                      </div>
                      <div className="p-2 rounded-lg bg-white border border-slate-100">
                        <span className="text-[10px] text-slate-400 block font-medium">Location</span>
                        <strong className="text-slate-800">{match.locationScore}%</strong>
                      </div>
                    </div>

                    {/* Matched vs Missing */}
                    <div className="text-xs space-y-1 pt-1">
                      <div className="text-slate-700">
                        <strong className="text-emerald-700">Why it matches:</strong> {match.matchReasons.join(' ')}
                      </div>
                      {match.missingSkills.length > 0 && (
                        <div className="text-slate-700">
                          <strong className="text-amber-700">Missing skills to bridge:</strong> {match.missingSkills.join(', ')}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })()}

              {/* Description */}
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Role Overview
                </h3>
                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                  {activeModalOpp.description}
                </p>
              </div>

              {/* Responsibilities */}
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Key Responsibilities
                </h3>
                <ul className="space-y-1.5 text-xs text-slate-700">
                  {activeModalOpp.responsibilities.map((r, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 mt-1.5 shrink-0" />
                      <span>{r}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Requirements & Qualifications */}
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Qualifications & Degree Requirements
                </h3>
                <ul className="space-y-1.5 text-xs text-slate-700">
                  {activeModalOpp.qualifications.map((q, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-slate-400 mt-1.5 shrink-0" />
                      <span>{q}</span>
                    </li>
                  ))}
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-400 mt-1.5 shrink-0" />
                    <span>Eligible Degrees: {activeModalOpp.degreeRequirements.join(', ')}</span>
                  </li>
                </ul>
              </div>

              {/* Metadata row */}
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex flex-wrap items-center justify-between text-xs text-slate-600 gap-3">
                <div>
                  <span className="text-slate-400 block">Stipend / Salary:</span>
                  <strong className="text-emerald-700">{activeModalOpp.stipendOrSalary}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block">Application Deadline:</span>
                  <strong className="text-slate-900">{activeModalOpp.deadline}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block">Source & Verification:</span>
                  <span>{activeModalOpp.sourceName}</span>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <button
                onClick={() => {
                  onToggleSave(activeModalOpp.id);
                }}
                className="text-xs font-bold text-slate-700 hover:text-slate-900 flex items-center gap-1.5"
              >
                {savedOpportunityIds.includes(activeModalOpp.id) ? (
                  <>
                    <BookmarkCheck className="w-4 h-4 text-indigo-600" />
                    <span>Saved in Tracker</span>
                  </>
                ) : (
                  <>
                    <Bookmark className="w-4 h-4" />
                    <span>Save for Later</span>
                  </>
                )}
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setActiveModalOpp(null);
                    if (onCloseModal) onCloseModal();
                  }}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-200 rounded-lg transition"
                >
                  Close
                </button>
                {appliedOpportunityIds.includes(activeModalOpp.id) ? (
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-4 py-2 rounded-lg">
                    Application Submitted
                  </span>
                ) : (
                  <button
                    onClick={() => {
                      handleApplyClick(activeModalOpp);
                      setActiveModalOpp(null);
                      if (onCloseModal) onCloseModal();
                    }}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-5 py-2 rounded-lg transition shadow-xs flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Submit Application</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
