import React, { useState, useMemo } from 'react';
import { 
  Building2, 
  Search, 
  MapPin, 
  Users, 
  Briefcase, 
  ShieldCheck, 
  ExternalLink, 
  Filter, 
  ArrowRight,
  X,
  Globe
} from 'lucide-react';
import { Company, Opportunity } from '../types';

interface CompanyDirectoryProps {
  companies: Company[];
  opportunities: Opportunity[];
  onSelectOpportunity: (opp: Opportunity) => void;
  initialSelectedCompany?: Company | null;
}

export const CompanyDirectory: React.FC<CompanyDirectoryProps> = ({
  companies,
  opportunities,
  onSelectOpportunity,
  initialSelectedCompany
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedIndustry, setSelectedIndustry] = useState<'All' | 'Technology' | 'Finance' | 'Consulting'>('All');
  const [activeCompanyModal, setActiveCompanyModal] = useState<Company | null>(initialSelectedCompany || null);

  // Sync if initialSelectedCompany changes
  React.useEffect(() => {
    if (initialSelectedCompany) {
      setActiveCompanyModal(initialSelectedCompany);
    }
  }, [initialSelectedCompany]);

  const filteredCompanies = useMemo(() => {
    return companies.filter(c => {
      const matchesIndustry = selectedIndustry === 'All' || c.industry === selectedIndustry;
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch = !q || 
        c.name.toLowerCase().includes(q) ||
        c.headquarters.toLowerCase().includes(q) ||
        c.tags.some(t => t.toLowerCase().includes(q));
      return matchesIndustry && matchesSearch;
    });
  }, [companies, selectedIndustry, searchQuery]);

  // Active opportunities for selected company
  const companyOpps = useMemo(() => {
    if (!activeCompanyModal) return [];
    return opportunities.filter(o => 
      o.companyName.toLowerCase().includes(activeCompanyModal.name.toLowerCase()) ||
      activeCompanyModal.name.toLowerCase().includes(o.companyName.toLowerCase())
    );
  }, [activeCompanyModal, opportunities]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded">
              Enterprise Ecosystem
            </span>
            <span className="text-xs text-slate-500 font-medium">
              100+ Leading Employers
            </span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight mt-1">
            Company Directory & Talent Partners
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 max-w-2xl mt-1">
            Browse verified enterprise recruiters across Technology, Financial Markets, and Strategic Management Consulting actively engaging with university placement drives.
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-semibold text-slate-600 bg-slate-50 px-4 py-2.5 rounded-xl border border-slate-200">
          <div>
            <strong className="text-slate-900 block text-sm">{companies.length}</strong>
            <span className="text-[11px] text-slate-400">Total Partners</span>
          </div>
          <span className="w-px h-6 bg-slate-200" />
          <div>
            <strong className="text-indigo-600 block text-sm">{opportunities.length}</strong>
            <span className="text-[11px] text-slate-400">Active Postings</span>
          </div>
        </div>
      </div>

      {/* Search & Industry Filters Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search 100+ companies by name, domain (e.g. AI, Cloud, Trading), or city..."
            className="w-full text-xs sm:text-sm pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 outline-hidden focus:border-indigo-600 font-medium text-slate-800 placeholder:text-slate-400"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto text-xs font-semibold">
          {(['All', 'Technology', 'Finance', 'Consulting'] as const).map((industry) => (
            <button
              key={industry}
              onClick={() => setSelectedIndustry(industry)}
              className={`px-3 py-2 rounded-xl transition shrink-0 ${
                selectedIndustry === industry
                  ? 'bg-indigo-600 text-white shadow-2xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {industry} {industry === 'All' ? `(${companies.length})` : ''}
            </button>
          ))}
        </div>
      </div>

      {/* Companies Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredCompanies.map((company) => {
          return (
            <div
              key={company.id}
              onClick={() => setActiveCompanyModal(company)}
              className="bg-white rounded-2xl border border-slate-200 hover:border-indigo-500 hover:shadow-md transition-all p-4 cursor-pointer flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div className={`w-10 h-10 rounded-xl ${company.logoBg} text-white font-black text-xs flex items-center justify-center shrink-0 shadow-xs group-hover:scale-105 transition-transform`}>
                    {company.logoText}
                  </div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 bg-slate-50 px-2 py-0.5 rounded border border-slate-100">
                    {company.industry}
                  </span>
                </div>

                <div className="mt-3">
                  <h3 className="text-xs font-bold text-slate-900 group-hover:text-indigo-600 transition truncate">
                    {company.name}
                  </h3>
                  <p className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5 truncate">
                    <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                    <span>{company.headquarters}</span>
                  </p>
                </div>

                <p className="text-[11px] text-slate-600 mt-2 line-clamp-2 leading-relaxed">
                  {company.description}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-1 mt-3">
                  {company.tags.slice(0, 2).map((t, idx) => (
                    <span key={idx} className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">
                      {t}
                    </span>
                  ))}
                </div>
              </div>

              {/* Footer */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px]">
                <span className="font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                  {company.activeOpportunitiesCount} active roles
                </span>
                <span className="text-indigo-600 font-semibold group-hover:translate-x-0.5 transition flex items-center gap-0.5">
                  Inspect <ArrowRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Company Detail Modal with Active Opportunities */}
      {activeCompanyModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="p-6 border-b border-slate-200 flex items-start justify-between gap-4">
              <div className="flex items-start gap-3">
                <div className={`w-14 h-14 rounded-2xl ${activeCompanyModal.logoBg} text-white font-black text-lg flex items-center justify-center shrink-0 shadow-xs`}>
                  {activeCompanyModal.logoText}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-bold text-slate-900">
                      {activeCompanyModal.name}
                    </h2>
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded-full">
                      <ShieldCheck className="w-3 h-3" /> Verified Partner
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 font-medium mt-0.5">
                    {activeCompanyModal.industry} Sector · Headquarters: {activeCompanyModal.headquarters}
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Size: {activeCompanyModal.size}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setActiveCompanyModal(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-md"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                  About the Enterprise
                </h3>
                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                  {activeCompanyModal.description}
                </p>
              </div>

              {/* Tags */}
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Specialization Domains
                </h3>
                <div className="flex flex-wrap gap-1.5">
                  {activeCompanyModal.tags.map((t, idx) => (
                    <span key={idx} className="text-xs font-semibold bg-slate-100 text-slate-700 px-2.5 py-1 rounded-lg">
                      {t}
                    </span>
                  ))}
                </div>
              </div>

              {/* Active Opportunities from this company */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Active Verified Openings ({companyOpps.length})
                  </h3>
                  <a
                    href={activeCompanyModal.careersUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
                  >
                    <span>External Careers Portal</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>

                {companyOpps.length === 0 ? (
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-center text-xs text-slate-500">
                    No active campus drives open today. Check back during upcoming placement windows.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {companyOpps.map((opp) => (
                      <div
                        key={opp.id}
                        className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-white hover:border-indigo-400 transition flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-slate-900">{opp.title}</span>
                            <span className="text-[10px] font-semibold bg-indigo-50 text-indigo-700 px-1.5 py-0.5 rounded">
                              {opp.type}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500 mt-0.5">
                            {opp.location} · {opp.workMode} · {opp.stipendOrSalary}
                          </p>
                          <div className="flex flex-wrap gap-1 mt-1.5">
                            {opp.requiredSkills.slice(0, 3).map((s, idx) => (
                              <span key={idx} className="text-[10px] bg-white border border-slate-200 text-slate-600 px-1.5 py-0.5 rounded">
                                {s}
                              </span>
                            ))}
                          </div>
                        </div>

                        <button
                          onClick={() => {
                            setActiveCompanyModal(null);
                            onSelectOpportunity(opp);
                          }}
                          className="shrink-0 bg-slate-900 hover:bg-indigo-600 text-white text-xs font-bold px-3 py-1.5 rounded-lg transition"
                        >
                          View & Apply
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setActiveCompanyModal(null)}
                className="px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-200 rounded-lg transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
