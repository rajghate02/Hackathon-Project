import React, { useState } from 'react';
import { 
  Handshake, 
  Building2, 
  GraduationCap, 
  Users, 
  Award, 
  ArrowRight, 
  CheckCircle2, 
  Clock, 
  Calendar, 
  X,
  Send,
  FileCode2,
  DollarSign
} from 'lucide-react';
import { UniversityIndustryProject } from '../types';
import { COLLABORATION_PROJECTS } from '../data/collaborations';

export const CollaborationHub: React.FC = () => {
  const [projects, setProjects] = useState<UniversityIndustryProject[]>(COLLABORATION_PROJECTS);
  const [selectedProject, setSelectedProject] = useState<UniversityIndustryProject | null>(null);
  const [applyModalProject, setApplyModalProject] = useState<UniversityIndustryProject | null>(null);
  const [teamName, setTeamName] = useState('');
  const [teamMembers, setTeamMembers] = useState('Aarav Sharma (Lead), 2 Co-Students');
  const [proposalPitch, setProposalPitch] = useState('');
  const [appliedProjectIds, setAppliedProjectIds] = useState<string[]>([]);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const handleApplySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!applyModalProject) return;

    setAppliedProjectIds(prev => [...prev, applyModalProject.id]);
    setSuccessMessage(`Team "${teamName}" registered for "${applyModalProject.title}" sponsored by ${applyModalProject.companyName}!`);
    setApplyModalProject(null);
    setTeamName('');
    setProposalPitch('');

    setTimeout(() => {
      setSuccessMessage(null);
    }, 5000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded">
              Academic-Industry Bridge
            </span>
            <span className="text-xs text-slate-500 font-medium">
              Real-World Capstone Sponsorship
            </span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight mt-1">
            University–Industry Collaboration Hub
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 max-w-2xl mt-1">
            Co-sponsored engineering capstones, research problems, and production challenges mentored directly by Principal Architects and Senior Researchers at Fortune 500 enterprises.
          </p>
        </div>

        <div className="flex items-center gap-3 text-xs font-semibold text-slate-600 bg-slate-50 px-4 py-2.5 rounded-xl border border-slate-200">
          <GraduationCap className="w-4 h-4 text-indigo-600" />
          <span>Earn academic credits & direct pre-placement offers (PPOs)</span>
        </div>
      </div>

      {/* Success Notification Alert */}
      {successMessage && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{successMessage}</span>
          </div>
          <button onClick={() => setSuccessMessage(null)} className="text-emerald-600 hover:text-emerald-900">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Projects Grid */}
      <div className="grid md:grid-cols-2 gap-6">
        {projects.map((proj) => {
          const isApplied = appliedProjectIds.includes(proj.id);

          return (
            <div
              key={proj.id}
              className="bg-white rounded-2xl border border-slate-200 hover:border-indigo-500 hover:shadow-md transition-all p-6 flex flex-col justify-between"
            >
              <div>
                {/* Header: Sponsoring Company & Partner University */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-xl bg-slate-900 text-white font-bold text-xs flex items-center justify-center shrink-0">
                      {proj.companyName.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <span className="text-xs font-bold text-slate-900">{proj.companyName}</span>
                      <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                        <GraduationCap className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                        <span>{proj.universityName}</span>
                      </div>
                    </div>
                  </div>

                  <span className="text-xs font-extrabold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2.5 py-0.5 rounded-full">
                    {proj.type}
                  </span>
                </div>

                {/* Title & Description */}
                <h3 className="text-base font-bold text-slate-900 mt-4 line-clamp-1">
                  {proj.title}
                </h3>
                <p className="text-xs text-slate-600 mt-1.5 line-clamp-3 leading-relaxed">
                  {proj.description}
                </p>

                {/* Mentor Credentials */}
                <div className="mt-4 p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-full bg-indigo-100 text-indigo-700 font-bold text-xs flex items-center justify-center shrink-0">
                    {proj.mentorName.charAt(0)}
                  </div>
                  <div className="text-xs">
                    <span className="font-bold text-slate-800 block">{proj.mentorName}</span>
                    <span className="text-[11px] text-slate-500">{proj.mentorTitle}</span>
                  </div>
                </div>

                {/* Key Skills */}
                <div className="mt-4 flex flex-wrap gap-1">
                  {proj.requiredSkills.map((s, idx) => (
                    <span key={idx} className="text-[10px] bg-slate-100 text-slate-700 font-medium px-2 py-0.5 rounded">
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              {/* Footer */}
              <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-emerald-700 block">{proj.stipend || 'Academic Credit & Stipend'}</span>
                  <span className="text-[10px] text-slate-400">Duration: {proj.durationWeeks} Weeks · {proj.openSlots} slots remaining</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setSelectedProject(proj)}
                    className="text-xs font-semibold text-slate-600 hover:text-slate-900 px-2.5 py-1.5 rounded-lg transition"
                  >
                    Details
                  </button>

                  {isApplied ? (
                    <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
                      Team Registered
                    </span>
                  ) : (
                    <button
                      onClick={() => setApplyModalProject(proj)}
                      className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg transition shadow-xs flex items-center gap-1"
                    >
                      <Users className="w-3.5 h-3.5" />
                      <span>Apply Team</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Apply Team Modal */}
      {applyModalProject && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Register Student Team
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  {applyModalProject.title} ({applyModalProject.companyName})
                </p>
              </div>
              <button 
                onClick={() => setApplyModalProject(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-md"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleApplySubmit} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Team Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Orbit Systems Lab or AlgoTeam Alpha"
                  value={teamName}
                  onChange={(e) => setTeamName(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-200 p-2.5 text-slate-800 outline-hidden focus:border-indigo-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Team Members & Roll Numbers</label>
                <input
                  type="text"
                  required
                  value={teamMembers}
                  onChange={(e) => setTeamMembers(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-200 p-2.5 text-slate-800"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Brief Technical Approach Pitch</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Summarize your architecture strategy and why your team is qualified..."
                  value={proposalPitch}
                  onChange={(e) => setProposalPitch(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-200 p-2.5 text-slate-800"
                />
              </div>

              <div className="p-3 bg-slate-50 rounded-xl text-[11px] text-slate-600">
                Submitting this proposal routes your project to the Department Placement Dean and the industry sponsor mentor for formal semester credit authorization.
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setApplyModalProject(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition shadow-xs flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Submit Proposal</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Project Details Modal */}
      {selectedProject && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden">
            <div className="p-6 border-b border-slate-200 flex items-start justify-between">
              <div>
                <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                  {selectedProject.companyName} × {selectedProject.universityName}
                </span>
                <h2 className="text-lg font-bold text-slate-900 mt-1">
                  {selectedProject.title}
                </h2>
              </div>
              <button 
                onClick={() => setSelectedProject(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-md"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 max-h-[65vh] overflow-y-auto text-xs">
              <div>
                <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px] mb-1">
                  Challenge Problem Statement
                </h4>
                <p className="text-slate-600 leading-relaxed">{selectedProject.description}</p>
              </div>

              <div>
                <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px] mb-1">
                  Expected Deliverables
                </h4>
                <ul className="list-disc list-inside text-slate-600 space-y-1">
                  {selectedProject.deliverables.map((d, idx) => (
                    <li key={idx}>{d}</li>
                  ))}
                </ul>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1 text-slate-700">
                <div><strong>Industry Mentor:</strong> {selectedProject.mentorName} ({selectedProject.mentorTitle})</div>
                <div><strong>Stipend / Research Grant:</strong> {selectedProject.stipend || 'Semester Grant'}</div>
                <div><strong>Duration:</strong> {selectedProject.durationWeeks} Weeks</div>
                <div><strong>Open Slots:</strong> {selectedProject.openSlots} students</div>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setSelectedProject(null)}
                className="px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-200 rounded-lg transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
