import React, { useState } from 'react';
import { 
  Compass, 
  Layers, 
  Briefcase, 
  Building2, 
  Sparkles, 
  Search, 
  Bell, 
  ShieldCheck, 
  User as UserIcon, 
  ChevronDown, 
  HelpCircle, 
  TrendingUp, 
  Handshake, 
  Menu, 
  X, 
  GraduationCap,
  CheckCircle2,
  AlertCircle,
  Home
} from 'lucide-react';
import { UserRole } from '../types';
import { Logo } from './homepage/Logo';
import { HOME_VIEW } from '../constants/routes';

interface NavbarProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  openSearch: () => void;
  openAuth: (mode?: 'login' | 'register') => void;
  openVerification: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  setCurrentView,
  currentRole,
  setCurrentRole,
  openSearch,
  openAuth,
  openVerification
}) => {
  const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);

  const rolesConfig: { role: UserRole; title: string; subtitle: string; badge: string }[] = [
    { 
      role: 'student', 
      title: 'Student Persona', 
      subtitle: 'Aarav Sharma · Manipal University Jaipur',
      badge: 'BTech CSE (78% Ready)'
    },
    { 
      role: 'university_admin', 
      title: 'University Admin', 
      subtitle: 'Dr. V. K. Saxena · Dean of Academics (MUJ)',
      badge: 'Institutional View'
    },
    { 
      role: 'recruiter', 
      title: 'Corporate Recruiter', 
      subtitle: 'Sonia Kapoor · Tech Talent Lead (NVIDIA)',
      badge: 'Employer View'
    },
    { 
      role: 'platform_admin', 
      title: 'Platform Admin', 
      subtitle: 'SkillOrbit Compliance & Infrastructure',
      badge: 'Global Admin'
    }
  ];

  const currentRoleInfo = rolesConfig.find(r => r.role === currentRole) || rolesConfig[0];

  const navItems = [
    { id: HOME_VIEW, label: 'Home', icon: Home },
    { id: 'dashboard', label: 'Command Center', icon: Compass },
    { id: 'verified_skills', label: '🛡️ Verified Skills', icon: ShieldCheck, isFlagship: true },
    { id: 'skillmap', label: 'Skill Map', icon: Layers },
    { id: 'careercompass', label: 'Career Compass', icon: Sparkles },
    { id: 'opportunities', label: 'Opportunities', icon: Briefcase },
    { id: 'companies', label: 'Companies', icon: Building2 },
    { id: 'collaborations', label: 'Collaborations', icon: Handshake },
    { id: 'industrypulse', label: 'Industry Pulse', icon: TrendingUp },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      {/* Top enterprise banner for persona indicator */}
      <div className="bg-slate-900 text-slate-300 text-xs py-1.5 px-4 sm:px-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-medium text-slate-200">SkillOrbit Enterprise Engine</span>
          <span className="text-slate-500">|</span>
          <span className="hidden md:inline text-slate-400">Connected: Manipal University Jaipur & Verified Industry Network</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <button
              onClick={() => setRoleDropdownOpen(!roleDropdownOpen)}
              className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-1 rounded text-xs transition border border-slate-700"
            >
              <span className="text-slate-400">Role:</span>
              <span className="font-semibold text-white">{currentRoleInfo.title}</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {roleDropdownOpen && (
              <div className="absolute right-0 mt-1.5 w-72 bg-white rounded-lg shadow-xl border border-slate-200 py-1 z-50 text-slate-800">
                <div className="px-3 py-2 border-b border-slate-100 bg-slate-50">
                  <p className="text-xs font-semibold text-slate-700">Switch Demonstration Role</p>
                  <p className="text-[11px] text-slate-500">Test authentic workflows across user types</p>
                </div>
                {rolesConfig.map((item) => (
                  <button
                    key={item.role}
                    onClick={() => {
                      setCurrentRole(item.role);
                      setRoleDropdownOpen(false);
                      if (item.role === 'university_admin') setCurrentView('university_dashboard');
                      else if (item.role === 'recruiter') setCurrentView('recruiter_dashboard');
                      else if (item.role === 'platform_admin') setCurrentView('admin_panel');
                      else setCurrentView('dashboard');
                    }}
                    className={`w-full text-left px-3 py-2.5 hover:bg-slate-50 flex items-start gap-2.5 transition border-l-2 ${
                      currentRole === item.role ? 'border-indigo-600 bg-indigo-50/50' : 'border-transparent'
                    }`}
                  >
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-900">{item.title}</span>
                        <span className="text-[10px] font-medium bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">
                          {item.badge}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">{item.subtitle}</p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo & Wordmark */}
          <div className="flex items-center gap-6">
            <button 
              onClick={() => setCurrentView(HOME_VIEW)}
              className="flex items-center gap-2.5 group text-left cursor-pointer focus:outline-hidden focus-visible:ring-2 focus-visible:ring-indigo-600 rounded-lg p-0.5"
              title="SkillOrbit — Return to Homepage"
            >
              <Logo size="md" />
            </button>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center gap-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentView === item.id;
                const isFlagship = (item as any).isFlagship;
                return (
                  <button
                    key={item.id}
                    onClick={() => setCurrentView(item.id)}
                    className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition cursor-pointer relative ${
                      isActive 
                        ? isFlagship 
                          ? 'text-emerald-950 bg-emerald-50 border border-emerald-300 font-black shadow-xs ring-1 ring-emerald-200'
                          : 'text-indigo-700 bg-indigo-50/80 font-bold' 
                        : isFlagship
                          ? 'text-slate-900 hover:text-emerald-800 hover:bg-emerald-50/60 font-bold bg-slate-50/80 border border-slate-200'
                          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
                    }`}
                  >
                    <Icon className={`w-3.5 h-3.5 ${isActive ? (isFlagship ? 'text-emerald-600' : 'text-indigo-600') : (isFlagship ? 'text-emerald-600' : 'text-slate-400')}`} />
                    <span>{item.label}</span>
                    {isFlagship && (
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse ml-0.5" />
                    )}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Right Action Bar */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Global Search Trigger */}
            <button
              onClick={openSearch}
              className="flex items-center gap-2 bg-slate-100 hover:bg-slate-200/80 text-slate-500 hover:text-slate-800 px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-200 transition"
              title="Search across companies, opportunities, skills, institutions"
            >
              <Search className="w-3.5 h-3.5 text-slate-400" />
              <span className="hidden sm:inline">Search orbit...</span>
              <kbd className="hidden sm:inline-block bg-white text-slate-600 text-[10px] px-1.5 py-0.5 rounded border border-slate-200 font-mono">
                ⌘K
              </kbd>
            </button>

            {/* Notifications Trigger */}
            <div className="relative">
              <button 
                onClick={() => setNotificationsOpen(!notificationsOpen)}
                className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg relative transition"
                title="Notifications"
              >
                <Bell className="w-4 h-4" />
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-indigo-600 rounded-full" />
              </button>

              {notificationsOpen && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-xl border border-slate-200 p-3 z-50">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                    <span className="text-xs font-bold text-slate-800">Notifications & Alerts</span>
                    <span className="text-[10px] text-indigo-600 font-semibold cursor-pointer">Mark all read</span>
                  </div>
                  <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
                    <div className="py-2.5 text-xs">
                      <div className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <div>
                          <p className="font-semibold text-slate-800">Verified Match: Google SWE Intern</p>
                          <p className="text-slate-500 text-[11px] mt-0.5">Your profile matches 88% of requirements for Summer 2026.</p>
                          <span className="text-[10px] text-slate-400">2 hours ago</span>
                        </div>
                      </div>
                    </div>
                    <div className="py-2.5 text-xs">
                      <div className="flex items-start gap-2">
                        <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                        <div>
                          <p className="font-semibold text-slate-800">Application Deadline in 48h</p>
                          <p className="text-slate-500 text-[11px] mt-0.5">JPMorgan Quantitative Research deadline approaching.</p>
                          <span className="text-[10px] text-slate-400">5 hours ago</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Help Center shortcut */}
            <button
              onClick={() => setCurrentView('help')}
              className={`p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition ${
                currentView === 'help' ? 'text-indigo-600 bg-indigo-50' : ''
              }`}
              title="Help Center"
            >
              <HelpCircle className="w-4 h-4" />
            </button>

            {/* Profile / Verification Badge */}
            <button
              onClick={openVerification}
              className="hidden sm:flex items-center gap-2 pl-2 pr-3 py-1 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition text-left"
            >
              <div className="w-6 h-6 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs">
                A
              </div>
              <div className="text-[11px] leading-tight">
                <div className="font-semibold text-slate-800 flex items-center gap-1">
                  Aarav S.
                  <ShieldCheck className="w-3 h-3 text-emerald-600" />
                </div>
                <div className="text-slate-600">MUJ · Verified</div>
              </div>
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 py-3 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            const isFlagship = (item as any).isFlagship;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setCurrentView(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition ${
                  isActive 
                    ? 'bg-indigo-50 text-indigo-700 font-bold' 
                    : 'text-slate-700 hover:bg-slate-50'
                } ${isFlagship ? 'border border-emerald-300 bg-emerald-50/50 text-emerald-950 font-bold' : ''}`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className={`w-4 h-4 ${isFlagship ? 'text-emerald-600' : ''}`} />
                  <span>{item.label}</span>
                </div>
                {isFlagship && (
                  <span className="text-[9px] font-black uppercase tracking-wider bg-emerald-600 text-white px-2 py-0.5 rounded-full">
                    FLAGSHIP
                  </span>
                )}
              </button>
            );
          })}
          <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
            <button 
              onClick={() => { openVerification(); setMobileMenuOpen(false); }}
              className="text-xs font-semibold text-emerald-700 flex items-center gap-1"
            >
              <ShieldCheck className="w-4 h-4" />
              Identity Verification (Verified)
            </button>
            <button 
              onClick={() => { setCurrentView('help'); setMobileMenuOpen(false); }}
              className="text-xs font-semibold text-slate-600"
            >
              Help Center
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
