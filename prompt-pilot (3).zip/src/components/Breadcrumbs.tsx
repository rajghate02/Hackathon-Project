import React from 'react';
import { Home, ChevronRight } from 'lucide-react';
import { BreadcrumbItem, getViewBreadcrumbs, HOME_VIEW } from '../constants/routes';

interface BreadcrumbsProps {
  currentView: string;
  detailTitle?: string;
  customItems?: BreadcrumbItem[];
  onNavigate: (view: string) => void;
  className?: string;
}

export const Breadcrumbs: React.FC<BreadcrumbsProps> = ({
  currentView,
  detailTitle,
  customItems,
  onNavigate,
  className = ''
}) => {
  const items = customItems || getViewBreadcrumbs(currentView, detailTitle);

  // If we are at the home view, don't show breadcrumbs
  if (currentView === HOME_VIEW && (!customItems || customItems.length <= 1)) {
    return null;
  }

  return (
    <nav 
      aria-label="Breadcrumb navigation"
      className={`bg-white/80 backdrop-blur-xs border-b border-slate-200/80 px-4 sm:px-6 lg:px-8 py-2.5 text-xs text-slate-500 flex items-center justify-between ${className}`}
    >
      <ol className="flex items-center flex-wrap gap-1.5 list-none m-0 p-0">
        {items.map((item, index) => {
          const isFirst = index === 0;
          const isLast = index === items.length - 1 || item.isCurrent;

          return (
            <li key={`${item.label}-${index}`} className="inline-flex items-center gap-1.5">
              {!isFirst && (
                <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0 select-none" aria-hidden="true" />
              )}
              {isLast ? (
                <span 
                  className="font-semibold text-slate-900 truncate max-w-[200px] sm:max-w-xs md:max-w-md select-none"
                  aria-current="page"
                >
                  {item.label}
                </span>
              ) : (
                <button
                  type="button"
                  onClick={() => onNavigate(item.view || HOME_VIEW)}
                  className="inline-flex items-center gap-1 text-slate-500 hover:text-indigo-600 hover:underline transition-colors font-medium cursor-pointer"
                  title={isFirst ? 'Return to SkillOrbit Homepage' : `Navigate to ${item.label}`}
                >
                  {isFirst && <Home className="w-3.5 h-3.5 text-slate-400 group-hover:text-indigo-600" aria-hidden="true" />}
                  <span>{item.label}</span>
                </button>
              )}
            </li>
          );
        })}
      </ol>

      {/* Global return-to-home quick shortcut */}
      <button
        type="button"
        onClick={() => onNavigate(HOME_VIEW)}
        className="hidden md:inline-flex items-center gap-1 text-[11px] font-medium text-slate-400 hover:text-indigo-600 transition-colors cursor-pointer"
        title="Quick return to public homepage"
      >
        <span>Return to Homepage</span>
        <span className="text-slate-300">/</span>
      </button>
    </nav>
  );
};
