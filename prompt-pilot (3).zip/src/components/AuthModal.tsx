import React, { useState, useMemo } from 'react';
import { 
  X, 
  ShieldCheck, 
  Mail, 
  Lock, 
  User as UserIcon, 
  GraduationCap, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw,
  Eye,
  EyeOff
} from 'lucide-react';
import { INSTITUTIONS_DATA } from '../data/institutions';
import { UserRole } from '../types';

export interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'login' | 'register';
  targetRole?: UserRole;
  targetView?: string;
  onLoginSuccess: (user: any, role?: UserRole, targetView?: string) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialMode = 'login',
  targetRole = 'student',
  targetView,
  onLoginSuccess
}) => {
  const [mode, setMode] = useState<'login' | 'register' | 'forgot_password'>(initialMode);
  const [selectedRole, setSelectedRole] = useState<UserRole>(targetRole);

  // Sync role if targetRole prop changes
  React.useEffect(() => {
    if (targetRole) {
      setSelectedRole(targetRole);
      if (targetRole === 'university_admin') {
        setLoginEmail('dean.academics@jaipur.manipal.edu');
      } else if (targetRole === 'recruiter') {
        setLoginEmail('priya.nair@google.com');
      } else if (targetRole === 'platform_admin') {
        setLoginEmail('admin@skillorbit.internal');
      } else {
        setLoginEmail('student@jaipur.manipal.edu');
      }
    }
  }, [targetRole]);
  
  // Registration Multi-Step (1 to 5)
  const [regStep, setRegStep] = useState(1);
  const [regEmail, setRegEmail] = useState('');
  const [regFullName, setRegFullName] = useState('');
  const [regDegree, setRegDegree] = useState('BTech');
  const [regMajor, setRegMajor] = useState('Computer Science & Engineering');
  const [regGradYear, setRegGradYear] = useState(2027);
  const [regPassword, setRegPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [botVerified, setBotVerified] = useState(false);
  const [botVerifying, setBotVerifying] = useState(false);

  // Email Verification Simulation
  const [verificationPending, setVerificationPending] = useState(false);
  const [verificationCode, setVerificationCode] = useState('');

  // Login Form
  const [loginEmail, setLoginEmail] = useState(
    targetRole === 'university_admin' ? 'dean.academics@jaipur.manipal.edu' :
    targetRole === 'recruiter' ? 'priya.nair@google.com' :
    targetRole === 'platform_admin' ? 'admin@skillorbit.internal' :
    'student@jaipur.manipal.edu'
  );
  const [loginPassword, setLoginPassword] = useState('Password@2026');
  const [rememberMe, setRememberMe] = useState(true);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSent, setForgotSent] = useState(false);

  // Instant Domain Validation for Step 1
  const recognizedInstitution = useMemo(() => {
    if (!regEmail.includes('@')) return null;
    const domain = regEmail.split('@')[1]?.toLowerCase().trim();
    if (!domain) return null;

    return INSTITUTIONS_DATA.find(inst => 
      inst.officialEmailDomains.some(d => domain.endsWith(d) || d.endsWith(domain))
    );
  }, [regEmail]);

  // Password Strength Calculation
  const passwordStrength = useMemo(() => {
    if (!regPassword) return { score: 0, text: 'None', color: 'bg-slate-200' };
    let score = 0;
    if (regPassword.length >= 8) score += 1;
    if (/[A-Z]/.test(regPassword)) score += 1;
    if (/[0-9]/.test(regPassword)) score += 1;
    if (/[^A-Za-z0-9]/.test(regPassword)) score += 1;

    if (score <= 1) return { score, text: 'Weak', color: 'bg-rose-500' };
    if (score <= 3) return { score, text: 'Moderate', color: 'bg-amber-500' };
    return { score, text: 'Strong', color: 'bg-emerald-500' };
  }, [regPassword]);

  if (!isOpen) return null;

  const handleSimulateBotCheck = async () => {
    setBotVerifying(true);
    try {
      const res = await fetch('/api/verify-bot-token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: `mock_turnstile_${Date.now()}`, provider: 'Cloudflare Turnstile' })
      });
      const data = await res.json();
      if (data.success) {
        setBotVerified(true);
      }
    } catch (e) {
      setBotVerified(true);
    } finally {
      setBotVerifying(false);
    }
  };

  const handleFinalRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setVerificationPending(true);
  };

  const handleConfirmVerification = () => {
    onLoginSuccess({
      fullName: regFullName || (selectedRole === 'university_admin' ? 'Dr. Sandeep Sancheti' : selectedRole === 'recruiter' ? 'Priya Nair' : 'Aarav Sharma'),
      email: regEmail,
      institution: recognizedInstitution?.name || (selectedRole === 'university_admin' ? 'Manipal University Jaipur' : selectedRole === 'recruiter' ? 'Google Campus Hiring' : 'Manipal University Jaipur'),
      role: selectedRole
    }, selectedRole, targetView);
    setVerificationPending(false);
    onClose();
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let name = 'Aarav Sharma';
    let inst = 'Manipal University Jaipur';
    if (selectedRole === 'university_admin') {
      name = 'Dr. Sandeep Sancheti';
      inst = 'Manipal University Jaipur (Placement Cell)';
    } else if (selectedRole === 'recruiter') {
      name = 'Priya Nair';
      inst = 'Google Talent Acquisition';
    } else if (selectedRole === 'platform_admin') {
      name = 'System Administrator';
      inst = 'SkillOrbit Platform Operations';
    }

    onLoginSuccess({
      fullName: name,
      email: loginEmail,
      institution: inst,
      role: selectedRole
    }, selectedRole, targetView);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white font-black flex items-center justify-center text-sm shadow-2xs">
              SO
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                {mode === 'login' ? (
                  selectedRole === 'university_admin' ? 'University Institutional Sign In' :
                  selectedRole === 'recruiter' ? 'Corporate Recruiter Sign In' :
                  'Sign In to SkillOrbit'
                ) :
                 mode === 'register' ? 'Register University Profile' :
                 'Reset Account Password'}
              </h3>
              <p className="text-[11px] text-slate-500">
                {mode === 'login' ? (
                  selectedRole === 'university_admin' ? 'Access University Command Center & cohort analytics' :
                  selectedRole === 'recruiter' ? 'Access recruiter dashboard & campus talent pipelines' :
                  'Access your verified skill graph & opportunities'
                ) :
                 mode === 'register' ? `Step ${regStep} of 5: Registration` :
                 'Enter your registered email'}
              </p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-700 rounded-md">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Verification Pending Modal View */}
        {verificationPending ? (
          <div className="p-6 space-y-4 text-center">
            <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
              <Mail className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-slate-900">Verify Your Institutional Email</h4>
              <p className="text-xs text-slate-600 mt-1">
                A cryptographically signed verification link and 6-digit code has been dispatched to <strong>{regEmail}</strong>.
              </p>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-1">
              <div>Domain: <span className="font-mono font-bold text-indigo-700">{regEmail.split('@')[1]}</span></div>
              <div>Matched: <strong className="text-slate-800">{recognizedInstitution?.name || 'Partner University'}</strong></div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Enter 6-Digit Code (Demo: 849201)</label>
              <input
                type="text"
                maxLength={6}
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value)}
                placeholder="849201"
                className="w-full text-center tracking-widest text-lg font-mono font-bold rounded-xl border border-slate-200 p-2.5 text-slate-800"
              />
            </div>

            <button
              onClick={handleConfirmVerification}
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold py-2.5 rounded-xl transition shadow-xs"
            >
              Verify Email & Enter Dashboard
            </button>
          </div>
        ) : mode === 'login' ? (
          /* LOGIN FORM */
          <form onSubmit={handleLoginSubmit} className="p-6 space-y-4">
            {/* Persona Switcher Quick Selection */}
            <div className="space-y-1.5">
              <label className="block text-[11px] font-bold text-slate-500">
                Sign In Role:
              </label>
              <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100 rounded-xl">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedRole('student');
                    setLoginEmail('student@jaipur.manipal.edu');
                  }}
                  className={`px-2 py-1.5 text-[11px] font-bold rounded-lg transition text-center cursor-pointer ${
                    selectedRole === 'student'
                      ? 'bg-white text-indigo-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  🎓 Student
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedRole('university_admin');
                    setLoginEmail('dean.academics@jaipur.manipal.edu');
                  }}
                  className={`px-2 py-1.5 text-[11px] font-bold rounded-lg transition text-center cursor-pointer ${
                    selectedRole === 'university_admin'
                      ? 'bg-white text-indigo-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  🏛️ University
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedRole('recruiter');
                    setLoginEmail('priya.nair@google.com');
                  }}
                  className={`px-2 py-1.5 text-[11px] font-bold rounded-lg transition text-center cursor-pointer ${
                    selectedRole === 'recruiter'
                      ? 'bg-white text-indigo-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  💼 Company
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {selectedRole === 'university_admin' ? 'Institutional / Administrator Email' :
                 selectedRole === 'recruiter' ? 'Corporate Recruiter Email' :
                 'University / Student Email'}
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="email"
                  required
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  className="w-full text-xs pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 text-slate-800"
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-bold text-slate-700">Password</label>
                <button
                  type="button"
                  onClick={() => setMode('forgot_password')}
                  className="text-[11px] text-indigo-600 hover:underline font-semibold"
                >
                  Forgot password?
                </button>
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  className="w-full text-xs pl-9 pr-9 py-2.5 rounded-xl border border-slate-200 text-slate-800"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs">
              <label className="flex items-center gap-2 cursor-pointer text-slate-600">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="rounded text-indigo-600"
                />
                <span>Remember this workstation</span>
              </label>
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold py-2.5 rounded-xl transition shadow-xs cursor-pointer"
            >
              {selectedRole === 'university_admin' ? 'Sign In as University Administrator' :
               selectedRole === 'recruiter' ? 'Sign In as Corporate Recruiter' :
               selectedRole === 'platform_admin' ? 'Sign In as Platform Admin' :
               'Sign In to Command Center'}
            </button>

            <div className="pt-3 border-t border-slate-100 text-center text-xs text-slate-500">
              New to SkillOrbit?{' '}
              <button
                type="button"
                onClick={() => { setMode('register'); setRegStep(1); }}
                className="font-bold text-indigo-600 hover:underline"
              >
                Create an account
              </button>
            </div>
          </form>
        ) : mode === 'register' ? (
          /* MULTI-STEP REGISTRATION FORM */
          <div className="p-6 space-y-4">
            {/* Step 1: University Email */}
            {regStep === 1 && (
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Step 1: Institutional Email Address
                  </label>
                  <p className="text-[11px] text-slate-500 mb-2">
                    Enter your college or university issued email domain
                  </p>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      type="email"
                      required
                      placeholder="e.g. student@jaipur.manipal.edu or user@manipal.edu"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      className="w-full text-xs pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 text-slate-800"
                    />
                  </div>
                </div>

                {/* Instant Domain Validation Feedback */}
                {regEmail.includes('@') && (
                  <div>
                    {recognizedInstitution ? (
                      <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-start gap-2 animate-in fade-in">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <div>
                          <strong className="block font-bold">{recognizedInstitution.name}</strong>
                          <span className="text-[11px]">Domain verified: {recognizedInstitution.city}, {recognizedInstitution.country}</span>
                        </div>
                      </div>
                    ) : (
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-start gap-2">
                        <ShieldCheck className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                        <div>
                          <span className="font-semibold">Unrecognized domain?</span>
                          <span className="text-[11px] block mt-0.5">You can still proceed; your account will undergo standard academic verification.</span>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                <button
                  type="button"
                  disabled={!regEmail || !regEmail.includes('@')}
                  onClick={() => setRegStep(2)}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold py-2.5 rounded-xl transition shadow-xs flex items-center justify-center gap-1.5"
                >
                  <span>Continue to Personal Info</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Step 2: Personal Information */}
            {regStep === 2 && (
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Step 2: Full Legal Name
                  </label>
                  <p className="text-[11px] text-slate-500 mb-2">
                    Must match your official university student enrollment card
                  </p>
                  <div className="relative">
                    <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      required
                      placeholder="e.g. Aarav Sharma"
                      value={regFullName}
                      onChange={(e) => setRegFullName(e.target.value)}
                      className="w-full text-xs pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 text-slate-800"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setRegStep(1)}
                    className="w-1/3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold py-2.5 rounded-xl transition"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    disabled={!regFullName.trim()}
                    onClick={() => setRegStep(3)}
                    className="w-2/3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold py-2.5 rounded-xl transition shadow-xs flex items-center justify-center gap-1"
                  >
                    <span>Next: Education</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Education */}
            {regStep === 3 && (
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Step 3: Degree & Academic Cohort
                  </label>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">Enrolled Degree</label>
                  <select
                    value={regDegree}
                    onChange={(e) => setRegDegree(e.target.value)}
                    className="w-full text-xs rounded-xl border border-slate-200 p-2.5 text-slate-800 bg-white font-medium"
                  >
                    <option value="BTech">B.Tech (Bachelor of Technology)</option>
                    <option value="MTech">M.Tech (Master of Technology)</option>
                    <option value="MBA">MBA (Master of Business Administration)</option>
                    <option value="BSc">B.Sc / BS</option>
                    <option value="MSc">M.Sc / MS</option>
                    <option value="PhD">Ph.D.</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">Major Discipline</label>
                  <input
                    type="text"
                    value={regMajor}
                    onChange={(e) => setRegMajor(e.target.value)}
                    className="w-full text-xs rounded-xl border border-slate-200 p-2.5 text-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">Graduation Cohort Year</label>
                  <select
                    value={regGradYear}
                    onChange={(e) => setRegGradYear(parseInt(e.target.value))}
                    className="w-full text-xs rounded-xl border border-slate-200 p-2.5 text-slate-800 bg-white font-medium"
                  >
                    <option value={2026}>2026 (Final Year)</option>
                    <option value={2027}>2027 (Pre-Final Year)</option>
                    <option value={2028}>2028 (Sophomore)</option>
                    <option value={2029}>2029 (Freshman)</option>
                  </select>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setRegStep(2)}
                    className="w-1/3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold py-2.5 rounded-xl transition"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={() => setRegStep(4)}
                    className="w-2/3 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold py-2.5 rounded-xl transition shadow-xs flex items-center justify-center gap-1"
                  >
                    <span>Next: Security</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            {/* Step 4: Password with strength meter */}
            {regStep === 4 && (
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Step 4: Create Strong Password
                  </label>
                  <p className="text-[11px] text-slate-500 mb-2">
                    Minimum 8 characters with letters, numbers, and symbols
                  </p>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      className="w-full text-xs pl-9 pr-9 py-2.5 rounded-xl border border-slate-200 text-slate-800"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                    >
                      {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>

                  {/* Strength Meter Bar */}
                  <div className="mt-2 space-y-1">
                    <div className="flex justify-between text-[10px] font-bold text-slate-500">
                      <span>Password Strength:</span>
                      <span className={passwordStrength.score >= 3 ? 'text-emerald-600' : 'text-amber-600'}>
                        {passwordStrength.text}
                      </span>
                    </div>
                    <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                      <div 
                        className={`h-full transition-all duration-300 ${passwordStrength.color}`} 
                        style={{ width: `${(passwordStrength.score / 4) * 100}%` }}
                      />
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setRegStep(3)}
                    className="w-1/3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold py-2.5 rounded-xl transition"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    disabled={passwordStrength.score < 2}
                    onClick={() => setRegStep(5)}
                    className="w-2/3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold py-2.5 rounded-xl transition shadow-xs flex items-center justify-center gap-1"
                  >
                    <span>Next: Bot Verification</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            {/* Step 5: Bot Protection (Cloudflare Turnstile Widget) */}
            {regStep === 5 && (
              <form onSubmit={handleFinalRegister} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Step 5: Automated Bot Defense
                  </label>
                  <p className="text-[11px] text-slate-500 mb-2">
                    Verified through Cloudflare Turnstile token validation
                  </p>
                </div>

                {/* Cloudflare Turnstile simulation card */}
                <div className="p-4 rounded-xl border border-slate-300 bg-slate-50 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      id="bot-check"
                      checked={botVerified}
                      onChange={handleSimulateBotCheck}
                      disabled={botVerifying || botVerified}
                      className="w-5 h-5 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                    />
                    <label htmlFor="bot-check" className="text-xs font-bold text-slate-800 cursor-pointer">
                      {botVerifying ? 'Verifying browser challenge...' :
                       botVerified ? 'Verification Complete (Human)' :
                       'I am a verified human applicant'}
                    </label>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] font-mono text-slate-400 block">Cloudflare Turnstile</span>
                    <span className="text-[9px] text-slate-400">Privacy Pass</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setRegStep(4)}
                    className="w-1/3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold py-2.5 rounded-xl transition"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={!botVerified}
                    className="w-2/3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold py-2.5 rounded-xl transition shadow-xs"
                  >
                    Complete Registration
                  </button>
                </div>
              </form>
            )}

            <div className="pt-3 border-t border-slate-100 text-center text-xs text-slate-500">
              Already registered?{' '}
              <button
                type="button"
                onClick={() => setMode('login')}
                className="font-bold text-indigo-600 hover:underline"
              >
                Sign in
              </button>
            </div>
          </div>
        ) : (
          /* FORGOT PASSWORD FORM */
          <div className="p-6 space-y-4">
            {forgotSent ? (
              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs space-y-1">
                <p className="font-bold">Password Reset Instructions Sent</p>
                <p>If an account exists for {forgotEmail}, a secure password reset token has been dispatched.</p>
                <button
                  type="button"
                  onClick={() => { setMode('login'); setForgotSent(false); }}
                  className="mt-2 text-indigo-600 font-bold hover:underline"
                >
                  Return to Sign In
                </button>
              </div>
            ) : (
              <form onSubmit={(e) => { e.preventDefault(); setForgotSent(true); }} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Enter Your Email Address</label>
                  <input
                    type="email"
                    required
                    placeholder="student@jaipur.manipal.edu"
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    className="w-full text-xs rounded-xl border border-slate-200 p-2.5 text-slate-800"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold py-2.5 rounded-xl transition shadow-xs"
                >
                  Dispatch Reset Token
                </button>

                <div className="pt-2 text-center">
                  <button
                    type="button"
                    onClick={() => setMode('login')}
                    className="text-xs text-slate-500 hover:text-slate-800"
                  >
                    Back to Login
                  </button>
                </div>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
