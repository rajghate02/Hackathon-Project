import React from 'react';
import { 
  ShieldCheck, 
  CheckCircle2, 
  FileCode2, 
  Award, 
  GraduationCap, 
  ClipboardCheck, 
  ArrowRight,
  ExternalLink,
  Layers,
  Sparkles
} from 'lucide-react';

interface SkillIntelligenceProps {
  onExploreSkillMapping: () => void;
  onExploreVerifiedSkills: () => void;
}

export const SkillIntelligence: React.FC<SkillIntelligenceProps> = ({
  onExploreSkillMapping,
  onExploreVerifiedSkills
}) => {
  return (
    <section id="skill-intelligence" className="py-20 sm:py-28 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Evidence-Based Thesis */}
          <div className="lg:col-span-6 space-y-6 text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 border border-emerald-200 text-emerald-800">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Evidence-First Skill Architecture</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-950 tracking-tight leading-tight">
              Know what you bring to the table.
            </h2>

            <p className="text-sm sm:text-base text-slate-600 leading-relaxed font-normal">
              Traditional platforms rely on self-declared stars and unverifiable claims. SkillOrbit grounds your profile in verifiable artifacts: code repositories, proctored assessments, university course grades, and industrial capstone reviews.
            </p>

            {/* Core Principle Equation */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/90 flex items-center justify-between">
              <div className="text-xs font-mono font-bold text-slate-800">
                <span className="text-indigo-600">Skills</span> + <span className="text-emerald-600">Verified Evidence</span> = <span className="text-slate-950 font-black">Stronger Skill Profile</span>
              </div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-600 bg-white px-2 py-0.5 rounded border border-slate-200">
                Formula
              </span>
            </div>

            <div className="space-y-3 text-xs sm:text-sm text-slate-700 font-medium">
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Auditable proof links attached directly to every competency node.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Enterprise recruiters view assessment scores and GitHub diffs in 1 click.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Seamless institutional transcript synchronization via university SSO.</span>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                type="button"
                onClick={onExploreSkillMapping}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm px-6 py-3 rounded-xl transition shadow-xs flex items-center gap-2 cursor-pointer"
              >
                <span>Explore Skill Mapping</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={onExploreVerifiedSkills}
                className="bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-200 font-bold text-xs sm:text-sm px-5 py-3 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                <span>🛡️ Verified Skills Hub</span>
              </button>
            </div>
          </div>

          {/* Right Column: Sophisticated Skill Profile Visual (Python Example) */}
          <div className="lg:col-span-6">
            <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-7 shadow-xl border border-slate-800 space-y-6">
              
              {/* Header */}
              <div className="flex items-start justify-between border-b border-slate-800 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-indigo-600/90 text-white font-black flex items-center justify-center text-lg shadow-inner">
                    Py
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-lg font-bold text-white">Python</h3>
                      <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded-full flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3 text-emerald-400" /> Verified
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Level: <strong className="text-white">Intermediate</strong> · Proficiency: <strong className="text-indigo-400 font-mono">88 / 100</strong>
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[10px] font-mono text-slate-500">CANONICAL ID</span>
                  <div className="text-xs font-mono font-bold text-slate-300">SKILL-PY-01</div>
                </div>
              </div>

              {/* Verified Evidence Stack */}
              <div className="space-y-3">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
                  Verifiable Evidence Attachments (4 Verified)
                </span>

                {/* Evidence Item 1: Project */}
                <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/80 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0">
                      <FileCode2 className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white flex items-center gap-1.5">
                        Production GitHub Repository
                        <span className="text-[9px] bg-slate-700 text-slate-300 px-1.5 py-0.2 rounded font-mono">Project</span>
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Distributed Task Queue with Redis &amp; AsyncIO (142 commits)
                      </div>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800">
                    Audit Verified
                  </span>
                </div>

                {/* Evidence Item 2: Certification */}
                <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/80 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                      <Award className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white flex items-center gap-1.5">
                        Industry Certification
                        <span className="text-[9px] bg-slate-700 text-slate-300 px-1.5 py-0.2 rounded font-mono">Certification</span>
                      </div>
                      <div className="text-[11px] text-slate-400">
                        PCAP™ – Certified Associate in Python Programming (Credential #PY-8942)
                      </div>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800">
                    Cryptographic Match
                  </span>
                </div>

                {/* Evidence Item 3: Assessment */}
                <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/80 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
                      <ClipboardCheck className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white flex items-center gap-1.5">
                        Proctored Exam Assessment
                        <span className="text-[9px] bg-slate-700 text-slate-300 px-1.5 py-0.2 rounded font-mono">Assessment</span>
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Algorithms &amp; Data Structures in Python · 94th Percentile
                      </div>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800">
                    Score: 847/1000
                  </span>
                </div>

                {/* Evidence Item 4: Academic Subject */}
                <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/80 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center shrink-0">
                      <GraduationCap className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white flex items-center gap-1.5">
                        Academic Coursework Grade
                        <span className="text-[9px] bg-slate-700 text-slate-300 px-1.5 py-0.2 rounded font-mono">Academic Subject</span>
                      </div>
                      <div className="text-[11px] text-slate-400">
                        CS302: Advanced Object-Oriented Software Design · Grade: A (9.2 GPA)
                      </div>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800">
                    SSO Synced
                  </span>
                </div>
              </div>

              {/* Profile Impact Summary */}
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
                <span>Recruiter Confidence Rating: <strong className="text-emerald-400">High (98%)</strong></span>
                <span className="text-slate-500">Live Proofs Available to Auditing Recruiters</span>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
