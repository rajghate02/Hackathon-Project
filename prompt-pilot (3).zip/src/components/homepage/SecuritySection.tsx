import React from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Eye, 
  KeyRound, 
  FileCheck, 
  Sliders, 
  Database,
  UserCheck
} from 'lucide-react';

export const SecuritySection: React.FC = () => {
  const securityFeatures = [
    {
      icon: KeyRound,
      title: 'Institutional Single Sign-On (SSO)',
      desc: 'Cryptographic authentication backed by verified university domains, ensuring only verified students and faculty access institutional data.'
    },
    {
      icon: Sliders,
      title: 'Granular Privacy Controls',
      desc: 'Students maintain sovereign authority over their profile visibility. Toggle public recruiter discovery, transcript visibility, and direct contact with one click.'
    },
    {
      icon: UserCheck,
      title: 'Strict Role-Based Access Control (RBAC)',
      desc: 'Separate, enforced permission boundaries for Students, Deans, Placement Cell Directors, and Corporate Recruiters prevent unauthorized access.'
    },
    {
      icon: Lock,
      title: 'Encryption in Transit & At Rest',
      desc: 'All candidate transcripts, identity tokens, and assessment logs are encrypted using modern TLS protocols and industry-standard AES-256 storage.'
    },
    {
      icon: FileCheck,
      title: 'Auditable Activity Logging',
      desc: 'Comprehensive access logs capture every recruiter view and assessment submission, maintaining complete provenance for institutional compliance.'
    },
    {
      icon: Database,
      title: 'Principled Data Minimization',
      desc: 'We store only the verifiable evidence required for skill validation and placement matching. Personal government identifiers are never harvested or monetized.'
    }
  ];

  return (
    <section id="security-privacy" className="py-20 sm:py-28 bg-slate-50 border-y border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 border border-emerald-200 text-emerald-800">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Enterprise Privacy &amp; Data Governance</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-950 tracking-tight leading-tight">
            Your career data belongs to you.
          </h2>

          <p className="text-sm sm:text-base text-slate-600 leading-relaxed font-normal">
            Career intelligence requires uncompromising trust. SkillOrbit enforces rigorous institutional data sovereignty, privacy controls, and verifiable access protocols at every layer.
          </p>
        </div>

        {/* 6 Security Feature Cards Grid */}
        <div className="mt-14 max-w-5xl mx-auto grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {securityFeatures.map((feat) => {
            const Icon = feat.icon;
            return (
              <div 
                key={feat.title}
                className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-3 hover:border-indigo-300 hover:shadow-sm transition-all"
              >
                <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-100 text-indigo-700 flex items-center justify-center">
                  <Icon className="w-5 h-5" />
                </div>
                <h3 className="text-sm font-bold text-slate-900 leading-snug">
                  {feat.title}
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {feat.desc}
                </p>
              </div>
            );
          })}
        </div>

        {/* Assurance Box */}
        <div className="mt-10 max-w-5xl mx-auto bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-600">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <span>
              <strong>Zero Data Brokering:</strong> SkillOrbit does not sell student data, advertise to third-party ad networks, or share unverified contact details.
            </span>
          </div>

          <span className="text-[11px] font-mono text-slate-400 shrink-0">
            SOC 2 / ISO 27001 Aligned Controls
          </span>
        </div>

      </div>
    </section>
  );
};
