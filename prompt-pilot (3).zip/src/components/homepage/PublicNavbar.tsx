import React, { useState, useEffect } from 'react';
import { 
  ArrowRight, 
  Menu, 
  X, 
  ChevronDown, 
  User as UserIcon, 
  LogOut, 
  Settings, 
  Bell, 
  HelpCircle, 
  Compass, 
  ShieldCheck,
  Briefcase,
  Layers,
  Sparkles,
  Building2,
  GraduationCap
} from 'lucide-react';
import { Logo } from './Logo';
import { UserRole } from '../../types';
import { 
  HOME_VIEW, 
  VIEWS, 
  getRoleDashboardView, 
  getRoleDashboardName 
} from '../../constants/routes';

interface PublicNavbarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  isAuthenticated: boolean;
  currentUser?: {
    fullName: string;
    institution: string;
    role: UserRole;
  };
  onOpenLogin: () => void;
  onOpenRegister: () => void;
  onLogout: () => void;
  onOpenNotifications?: () => void;
  onAccessSkills?: () => void;
  onAccessCareers?: () => void;
  onAccessOpportunities?: () => void;
  onAccessUniversities?: () => void;
  onAccessCompanies?: () => void;
}

export const PublicNavbar: React.FC<PublicNavbarProps> = ({
  currentView,
  onNavigate,
  isAuthenticated,
  currentUser,
  onOpenLogin,
  onOpenRegister,
  onLogout,
  onOpenNotifications,
  onAccessSkills,
  onAccessCareers,
  onAccessOpportunities,
  onAccessUniversities,
  onAccessCompanies
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const [platformDropdownOpen, setPlatformDropdownOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    setMobileMenuOpen(false);
    setPlatformDropdownOpen(false);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const roleDashboardView = currentUser ? getRoleDashboardView(currentUser.role) : 'dashboard';
  const roleDashboardLabel = currentUser ? getRoleDashboardName(currentUser.role) : 'Dashboard';

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-200 motion-reduce:transition-none ${
        isScrolled 
          ? 'bg-white/95 backdrop-blur-md border-b border-slate-200/90 shadow-xs' 
          : 'bg-white/80 md:bg-transparent border-b border-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-18">
          {/* Brand Logo & Wordmark - strictly returns to Home */}
          <button
            type="button"
            onClick={() => {
              if (currentView !== HOME_VIEW) {
                onNavigate(HOME_VIEW);
              } else {
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }
            }}
            className="flex items-center gap-2 group cursor-pointer focus:outline-hidden focus-visible:ring-2 focus-visible:ring-indigo-600 rounded-lg"
            title="SkillOrbit — Return to Homepage"
          >
            <Logo size="md" />
          </button>

          {/* Center / Right Primary Navigation */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            {/* Platform Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setPlatformDropdownOpen(!platformDropdownOpen)}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 hover:text-slate-950 hover:bg-slate-100/80 transition cursor-pointer"
              >
                <span>Platform</span>
                <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${platformDropdownOpen ? 'rotate-180' : ''}`} />
              </button>

              {platformDropdownOpen && (
                <div 
                  className="absolute left-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-slate-200 p-2 z-50 animate-in fade-in zoom-in-95 duration-150"
                  onMouseLeave={() => setPlatformDropdownOpen(false)}
                >
                  <button
                    type="button"
                    onClick={() => {
                      setPlatformDropdownOpen(false);
                      scrollToSection('product-journey');
                    }}
                    className="w-full flex items-start gap-2.5 p-2.5 rounded-xl hover:bg-slate-50 text-left transition"
                  >
                    <Compass className="w-4 h-4 text-indigo-600 mt-0.5" />
                    <div>
                      <div className="text-xs font-bold text-slate-900">Career Trajectory Engine</div>
                      <div className="text-[11px] text-slate-500">6-stage progression from skills to placement</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setPlatformDropdownOpen(false);
                      onNavigate('verified_skills');
                    }}
                    className="w-full flex items-start gap-2.5 p-2.5 rounded-xl hover:bg-slate-50 text-left transition"
                  >
                    <ShieldCheck className="w-4 h-4 text-emerald-600 mt-0.5" />
                    <div>
                      <div className="text-xs font-bold text-slate-900 flex items-center gap-1">
                        Verified Skills <span className="text-[9px] bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded font-black">FLAGSHIP</span>
                      </div>
                      <div className="text-[11px] text-slate-500">Invigilated exams &amp; proctored scores</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setPlatformDropdownOpen(false);
                      onNavigate('careercompass');
                    }}
                    className="w-full flex items-start gap-2.5 p-2.5 rounded-xl hover:bg-slate-50 text-left transition"
                  >
                    <Sparkles className="w-4 h-4 text-indigo-600 mt-0.5" />
                    <div>
                      <div className="text-xs font-bold text-slate-900">Career Readiness Score</div>
                      <div className="text-[11px] text-slate-500">Transparent 5-pillar matching analytics</div>
                    </div>
                  </button>
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={() => {
                if (onAccessSkills) onAccessSkills();
                else onNavigate(VIEWS.SKILLMAP);
              }}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 hover:text-slate-950 hover:bg-slate-100/80 transition cursor-pointer"
            >
              Skills
            </button>

            <button
              type="button"
              onClick={() => {
                if (onAccessCareers) onAccessCareers();
                else onNavigate(VIEWS.CAREERCOMPASS);
              }}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 hover:text-slate-950 hover:bg-slate-100/80 transition cursor-pointer"
            >
              Careers
            </button>

            <button
              type="button"
              onClick={() => {
                if (onAccessOpportunities) onAccessOpportunities();
                else onNavigate(VIEWS.OPPORTUNITIES);
              }}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 hover:text-slate-950 hover:bg-slate-100/80 transition cursor-pointer"
            >
              Opportunities
            </button>

            <button
              type="button"
              onClick={() => {
                if (onAccessUniversities) onAccessUniversities();
                else onNavigate(VIEWS.UNIVERSITY_DASHBOARD);
              }}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 hover:text-slate-950 hover:bg-slate-100/80 transition cursor-pointer"
            >
              For Universities
            </button>

            <button
              type="button"
              onClick={() => {
                if (onAccessCompanies) onAccessCompanies();
                else onNavigate(VIEWS.RECRUITER_DASHBOARD);
              }}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 hover:text-slate-950 hover:bg-slate-100/80 transition cursor-pointer"
            >
              For Companies
            </button>

            <button
              type="button"
              onClick={() => onNavigate(VIEWS.HELP)}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 hover:text-slate-950 hover:bg-slate-100/80 transition cursor-pointer"
            >
              Help
            </button>
          </nav>

          {/* Right-Side Actions: Authentication-Aware */}
          <div className="flex items-center gap-2 sm:gap-3">
            {!isAuthenticated ? (
              <>
                <button
                  type="button"
                  onClick={onOpenLogin}
                  className="text-xs font-bold text-slate-700 hover:text-slate-950 px-3.5 py-2 rounded-xl transition cursor-pointer"
                >
                  Log in
                </button>
                <button
                  type="button"
                  onClick={onOpenRegister}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-4 py-2 rounded-xl transition shadow-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <span>Get Started</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </>
            ) : (
              <div className="flex items-center gap-2">
                {/* Role Dashboard Action Button */}
                <button
                  type="button"
                  onClick={() => onNavigate(roleDashboardView)}
                  className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                  title={`Go to ${roleDashboardLabel}`}
                >
                  <Compass className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Dashboard</span>
                </button>

                {/* Compact User / Profile Control */}
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                    className="flex items-center gap-1.5 pl-2 pr-2.5 py-1.5 bg-slate-100 hover:bg-slate-200/80 border border-slate-200 rounded-xl transition cursor-pointer text-left"
                    aria-label="User profile and navigation menu"
                  >
                    <div className="w-6 h-6 rounded-lg bg-indigo-600 text-white text-xs font-bold flex items-center justify-center">
                      {currentUser?.fullName ? currentUser.fullName[0] : 'U'}
                    </div>
                    <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
                  </button>

                  {profileDropdownOpen && (
                    <div 
                      className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-slate-200 p-2 z-50 animate-in fade-in zoom-in-95 duration-150"
                      onMouseLeave={() => setProfileDropdownOpen(false)}
                    >
                      <div className="p-2 border-b border-slate-100">
                        <p className="text-xs font-bold text-slate-900 truncate">
                          {currentUser?.fullName || 'User'}
                        </p>
                        <p className="text-[11px] text-slate-500 truncate">
                          {currentUser?.institution || 'SkillOrbit'}
                        </p>
                        <span className="inline-block mt-1 text-[10px] font-semibold uppercase tracking-wider bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">
                          {currentUser?.role ? currentUser.role.replace('_', ' ') : 'Student'}
                        </span>
                      </div>

                      <div className="py-1 space-y-0.5">
                        <button
                          type="button"
                          onClick={() => {
                            setProfileDropdownOpen(false);
                            onNavigate(roleDashboardView);
                          }}
                          className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-700 hover:bg-slate-50 text-left cursor-pointer"
                        >
                          <Compass className="w-3.5 h-3.5 text-indigo-600" />
                          <span>{roleDashboardLabel}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setProfileDropdownOpen(false);
                            onNavigate('verified_skills');
                          }}
                          className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-700 hover:bg-slate-50 text-left cursor-pointer"
                        >
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Verified Skills Hub</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setProfileDropdownOpen(false);
                            onNavigate('help');
                          }}
                          className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-700 hover:bg-slate-50 text-left cursor-pointer"
                        >
                          <HelpCircle className="w-3.5 h-3.5 text-slate-400" />
                          <span>Help Center</span>
                        </button>
                      </div>

                      <div className="pt-1 border-t border-slate-100">
                        <button
                          type="button"
                          onClick={() => {
                            setProfileDropdownOpen(false);
                            onLogout();
                          }}
                          className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-rose-600 hover:bg-rose-50 text-left cursor-pointer"
                        >
                          <LogOut className="w-3.5 h-3.5" />
                          <span>Log Out</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Mobile Menu Hamburger */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition cursor-pointer"
              aria-label="Toggle mobile menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white/98 backdrop-blur-xl px-4 py-4 space-y-3 shadow-xl max-h-[85vh] overflow-y-auto animate-in slide-in-from-top-2 duration-200">
          <div className="space-y-1">
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                onNavigate(HOME_VIEW);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="w-full flex items-center gap-2 px-3 py-2 text-xs font-bold text-indigo-600 bg-indigo-50 rounded-xl"
            >
              <span>Home</span>
            </button>
            <button
              type="button"
              onClick={() => scrollToSection('product-journey')}
              className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 rounded-xl"
            >
              <span>Platform &amp; Trajectory</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                if (onAccessSkills) onAccessSkills();
                else onNavigate(VIEWS.SKILLMAP);
              }}
              className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 rounded-xl"
            >
              <span>Skills</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                if (onAccessCareers) onAccessCareers();
                else onNavigate(VIEWS.CAREERCOMPASS);
              }}
              className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 rounded-xl"
            >
              <span>Careers</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                if (onAccessOpportunities) onAccessOpportunities();
                else onNavigate(VIEWS.OPPORTUNITIES);
              }}
              className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 rounded-xl"
            >
              <span>Opportunities</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                if (onAccessUniversities) onAccessUniversities();
                else onNavigate(VIEWS.UNIVERSITY_DASHBOARD);
              }}
              className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 rounded-xl"
            >
              <span>For Universities</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                if (onAccessCompanies) onAccessCompanies();
                else onNavigate(VIEWS.RECRUITER_DASHBOARD);
              }}
              className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 rounded-xl"
            >
              <span>For Companies</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                onNavigate(VIEWS.HELP);
              }}
              className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 rounded-xl"
            >
              <span>Help Center</span>
            </button>
          </div>

          <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
            {!isAuthenticated ? (
              <>
                <button
                  type="button"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenLogin();
                  }}
                  className="w-full py-2.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl text-center"
                >
                  Log in
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenRegister();
                  }}
                  className="w-full py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl text-center shadow-xs"
                >
                  Get Started
                </button>
              </>
            ) : (
              <>
                <button
                  type="button"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onNavigate(roleDashboardView);
                  }}
                  className="w-full py-2.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl text-center"
                >
                  Go to {roleDashboardLabel}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onLogout();
                  }}
                  className="w-full py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 rounded-xl text-center"
                >
                  Log Out
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
