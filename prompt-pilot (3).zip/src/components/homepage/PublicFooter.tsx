import React from 'react';
import { Logo } from './Logo';
import { ShieldCheck, ArrowUp } from 'lucide-react';
import { HOME_VIEW, VIEWS } from '../../constants/routes';

interface PublicFooterProps {
  onNavigate: (view: string) => void;
  onOpenPrivacy?: () => void;
  onOpenTerms?: () => void;
}

export const PublicFooter: React.FC<PublicFooterProps> = ({
  onNavigate,
  onOpenPrivacy,
  onOpenTerms
}) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-950 text-slate-400 border-t border-slate-900 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* 4 Columns Grid */}
        <div className="grid grid-cols-2 md:grid-cols-12 gap-8 lg:gap-12">
          
          {/* Col 1: Brand & Identity */}
          <div className="col-span-2 md:col-span-4 space-y-4">
            <button
              type="button"
              onClick={() => {
                onNavigate(HOME_VIEW);
                scrollToTop();
              }}
              className="inline-block cursor-pointer focus:outline-hidden"
              title="SkillOrbit Home"
            >
              <Logo size="md" monochrome={false} />
            </button>

            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              SkillOrbit connects your skills, career goals, learning journey, projects, and opportunities into one intelligent career ecosystem.
            </p>

            <div className="pt-2 flex items-center gap-2 text-xs text-slate-500">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>Institutional Core Operational · v2.4</span>
            </div>
          </div>

          {/* Col 2: Platform Features */}
          <div className="col-span-1 md:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Platform
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('verified_skills')}
                  className="hover:text-white transition cursor-pointer flex items-center gap-1.5"
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="font-semibold text-emerald-300">Verified Skills</span>
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('careercompass')}
                  className="hover:text-white transition cursor-pointer"
                >
                  Career Compass
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('skillmap')}
                  className="hover:text-white transition cursor-pointer"
                >
                  Skill Intelligence &amp; Gap Engine
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('opportunities')}
                  className="hover:text-white transition cursor-pointer"
                >
                  Campus Opportunities &amp; Drives
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('collaborations')}
                  className="hover:text-white transition cursor-pointer"
                >
                  Industry Capstone Projects
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: For Organizations */}
          <div className="col-span-1 md:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              For Organizations
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate(VIEWS.UNIVERSITY_DASHBOARD)}
                  className="hover:text-white transition cursor-pointer"
                >
                  University Placement Suite
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate(VIEWS.RECRUITER_DASHBOARD)}
                  className="hover:text-white transition cursor-pointer"
                >
                  Corporate Talent Portal
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate(VIEWS.COMPANIES)}
                  className="hover:text-white transition cursor-pointer"
                >
                  Employer Ecosystem Directory
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate(VIEWS.INDUSTRY_PULSE)}
                  className="hover:text-white transition cursor-pointer"
                >
                  Industry Pulse Telemetry
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Support & Governance */}
          <div className="col-span-2 md:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Support &amp; Trust
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('help')}
                  className="hover:text-white transition cursor-pointer"
                >
                  Help Center &amp; Guides
                </button>
              </li>
              <li>
                <span className="text-slate-500">Security &amp; Encryption</span>
              </li>
              <li>
                <span className="text-slate-500">Privacy Sovereignty</span>
              </li>
              <li>
                <span className="text-slate-500">System Status: Operational</span>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex flex-wrap items-center gap-4">
            <span>© 2026 SkillOrbit Inc. All rights reserved.</span>
            <span>•</span>
            <button
              type="button"
              onClick={() => onNavigate(HOME_VIEW)}
              className="hover:text-slate-400 transition cursor-pointer"
            >
              SkillOrbit Home
            </button>
            <span>•</span>
            <span>Zero Data Brokering Guaranteed</span>
          </div>

          <button
            type="button"
            onClick={scrollToTop}
            className="flex items-center gap-1 text-slate-400 hover:text-white transition cursor-pointer bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800"
          >
            <span>Back to top</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </footer>
  );
};
