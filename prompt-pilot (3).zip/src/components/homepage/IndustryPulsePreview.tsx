import React from 'react';
import { 
  TrendingUp, 
  ArrowUpRight, 
  Sparkles, 
  Layers, 
  Briefcase, 
  ArrowRight,
  Info
} from 'lucide-react';

interface IndustryPulsePreviewProps {
  onExploreIndustryPulse: () => void;
}

export const IndustryPulsePreview: React.FC<IndustryPulsePreviewProps> = ({ onExploreIndustryPulse }) => {
  const risingSkills = [
    { name: 'PyTorch / TensorRT', domain: 'AI Systems', growth: '+46%', demand: 'Critical' },
    { name: 'Distributed Systems & Go', domain: 'Cloud Core', growth: '+38%', demand: 'High' },
    { name: 'Modern C++ (20/23)', domain: 'High Perf / Quant', growth: '+32%', demand: 'High' },
    { name: 'ROS2 / Nav2', domain: 'Robotics & Automation', growth: '+29%', demand: 'Emerging' }
  ];

  const emergingCareers = [
    { title: 'AI Systems Performance Engineer', compensation: '₹28L - ₹48L', openings: 'Accelerating' },
    { title: 'Quantitative Technology Analyst', compensation: '₹35L - ₹65L', openings: 'High Demand' },
    { title: 'Autonomous Robotics Software Engineer', compensation: '₹22L - ₹40L', openings: 'Emerging' },
    { title: 'Cloud Platform Reliability Engineer', compensation: '₹20L - ₹36L', openings: 'Steady' }
  ];

  return (
    <section id="industry-pulse" className="py-20 sm:py-28 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-50 border border-indigo-200 text-indigo-700">
            <TrendingUp className="w-3.5 h-3.5 text-indigo-600" />
            <span>Market Demand &amp; Skills Intelligence</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-950 tracking-tight leading-tight">
            Understand where the industry is heading.
          </h2>

          <p className="text-sm sm:text-base text-slate-600 leading-relaxed font-normal">
            Track rising technical competencies, shifting compensation curves, and real-time enterprise hiring telemetry before you select your final semester electives.
          </p>
        </div>

        {/* Intelligence Grid Preview */}
        <div className="mt-14 max-w-5xl mx-auto space-y-6">
          
          {/* Top Telemetry Header */}
          <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-7 border border-slate-800 shadow-xl space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-xs font-mono font-bold text-emerald-400 uppercase tracking-wider">
                    DEMO TELEMETRY FEED
                  </span>
                  <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded border border-slate-700 font-mono">
                    ILLUSTRATIVE VISUALIZATION
                  </span>
                </div>
                <h3 className="text-lg font-bold text-white mt-1">
                  Technology Skill Demand &amp; Placement Trajectory Index
                </h3>
              </div>

              <div className="text-left sm:text-right text-xs text-slate-400">
                <div>Source: <strong className="text-slate-200">Campus Drives &amp; Placement Portals</strong></div>
                <div>Data Period: <strong className="text-slate-200">Q1 2026</strong> · Last Updated: <strong className="text-slate-200">March 2026</strong></div>
              </div>
            </div>

            {/* Rising Skills & Emerging Careers in Two Columns */}
            <div className="grid md:grid-cols-2 gap-6">
              
              {/* Rising Skills */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                    Fastest Rising Technical Skills
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono">YoY Growth</span>
                </div>

                <div className="space-y-2">
                  {risingSkills.map((skill) => (
                    <div 
                      key={skill.name}
                      className="bg-slate-800/80 p-3 rounded-xl border border-slate-700/80 flex items-center justify-between text-xs"
                    >
                      <div>
                        <div className="font-bold text-white">{skill.name}</div>
                        <div className="text-[11px] text-slate-400">{skill.domain}</div>
                      </div>
                      <div className="text-right">
                        <span className="inline-flex items-center gap-0.5 text-emerald-400 font-mono font-bold">
                          <ArrowUpRight className="w-3.5 h-3.5" />
                          {skill.growth}
                        </span>
                        <div className="text-[10px] text-slate-500">{skill.demand} Demand</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Emerging Careers */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Briefcase className="w-3.5 h-3.5 text-emerald-400" />
                    High-Growth Career Trajectories
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono">Benchmark Band</span>
                </div>

                <div className="space-y-2">
                  {emergingCareers.map((career) => (
                    <div 
                      key={career.title}
                      className="bg-slate-800/80 p-3 rounded-xl border border-slate-700/80 flex items-center justify-between text-xs"
                    >
                      <div>
                        <div className="font-bold text-white">{career.title}</div>
                        <div className="text-[11px] text-emerald-400 font-medium">{career.openings}</div>
                      </div>
                      <div className="text-right font-mono text-xs font-bold text-slate-200">
                        {career.compensation}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>

            {/* Bottom Insight Footer */}
            <div className="pt-2 border-t border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-slate-400">
              <div className="flex items-center gap-1.5">
                <Info className="w-4 h-4 text-slate-500 shrink-0" />
                <span>Telemetry updates dynamically as institutional recruiters post new placement drives.</span>
              </div>

              <button
                type="button"
                onClick={onExploreIndustryPulse}
                className="text-xs font-bold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 cursor-pointer"
              >
                <span>Open Full Industry Pulse Analytics →</span>
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
