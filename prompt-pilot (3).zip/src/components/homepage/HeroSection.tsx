import React, { useState, useEffect } from 'react';
import { 
  ArrowRight, 
  ChevronRight, 
  ShieldCheck, 
  CheckCircle2, 
  Sparkles, 
  Compass, 
  Layers, 
  Briefcase, 
  AlertCircle,
  TrendingUp,
  Cpu,
  FileCode2,
  Lock
} from 'lucide-react';

interface HeroSectionProps {
  onGetStarted: () => void;
  onExploreOpportunities: () => void;
  onSeeHowItWorks: () => void;
  onNavigateToVerifiedSkills: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onGetStarted,
  onExploreOpportunities,
  onSeeHowItWorks,
  onNavigateToVerifiedSkills
}) => {
  // Micro-interaction state: cycles through active trajectory stages to show functionality
  const [activeStage, setActiveStage] = useState<number>(3); // default on 'Skill Gaps' or 'Learning'
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);

  const trajectoryStages = [
    { id: 'profile', label: 'Your Profile', desc: 'BTech CSE · Manipal Univ.', status: 'Verified' },
    { id: 'skills', label: 'Skills', desc: '8 Proven Competencies', status: 'Evidence-Backed' },
    { id: 'direction', label: 'Career Direction', desc: 'AI Systems Engineer', status: 'Target Set' },
    { id: 'gaps', label: 'Skill Gaps', desc: 'CUDA & Distributed Systems', status: 'Identified' },
    { id: 'learning', label: 'Learning & Capstone', desc: 'GPU Kernel Project', status: 'In Progress' },
    { id: 'opportunities', label: 'Opportunities', desc: '88% Match: NVIDIA Drive', status: 'Qualified' },
    { id: 'readiness', label: 'Placement Ready', desc: '78% Readiness Index', status: 'Pre-Screened' }
  ];

  // Subtle auto-step cycle every 4.5 seconds to demonstrate live trajectory progression
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveStage(prev => (prev + 1) % trajectoryStages.length);
    }, 4500);
    return () => clearInterval(timer);
  }, [trajectoryStages.length]);

  return (
    <section className="relative overflow-hidden pt-28 pb-16 sm:pt-36 sm:pb-24 lg:pt-40 lg:pb-28">
      {/* Background Subtle Coordinate Grid - strictly enterprise architectural */}
      <div 
        className="absolute inset-0 -z-10 bg-[linear-gradient(to_right,#e2e8f01f_1px,transparent_1px),linear-gradient(to_bottom,#e2e8f01f_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_20%,#000_70%,transparent_100%)] pointer-events-none" 
        aria-hidden="true" 
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-14 items-center">
          
          {/* Left Column: Clear Strategic Value Proposition */}
          <div className="lg:col-span-6 space-y-6 text-left">
            {/* System Status Pill */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-50 border border-indigo-200/80 text-indigo-800">
              <span className="w-2 h-2 rounded-full bg-indigo-600 animate-pulse" />
              <span>Career Intelligence &amp; Skill Verification Engine</span>
            </div>

            {/* Main Required Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-slate-950 tracking-tight leading-[1.08] font-sans">
              Navigate your skills. <br />
              <span className="text-indigo-600">Discover your next</span> opportunity.
            </h1>

            {/* Required Supporting Text */}
            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-xl font-normal">
              SkillOrbit connects your skills, career goals, learning journey, projects, and opportunities into one intelligent career ecosystem.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-3.5 pt-2">
              <button
                type="button"
                onClick={onGetStarted}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm px-6 py-3.5 rounded-xl transition shadow-xs flex items-center gap-2 cursor-pointer focus:outline-hidden focus-visible:ring-2 focus-visible:ring-indigo-600"
              >
                <span>Get Started</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={onExploreOpportunities}
                className="bg-white hover:bg-slate-50 text-slate-800 font-bold text-sm px-6 py-3.5 rounded-xl transition border border-slate-200 shadow-2xs cursor-pointer focus:outline-hidden focus-visible:ring-2 focus-visible:ring-indigo-600"
              >
                <span>Explore Opportunities</span>
              </button>
            </div>

            {/* Tertiary Link */}
            <div className="pt-1">
              <button
                type="button"
                onClick={onSeeHowItWorks}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-indigo-600 transition cursor-pointer"
              >
                <span>See how SkillOrbit works</span>
                <span aria-hidden="true">→</span>
              </button>
            </div>

            {/* Trust Badges - institutional & transparent */}
            <div className="pt-4 border-t border-slate-200/80 flex flex-wrap items-center gap-6 text-xs text-slate-600 font-medium">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Institutional Proof of Competence</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>Transparent 5-Pillar Matching</span>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Visual — Actual SkillOrbit Product Interface */}
          <div className="lg:col-span-6 relative">
            <div className="relative bg-white rounded-3xl border border-slate-200/90 p-5 sm:p-6 shadow-xl shadow-slate-200/50 space-y-5">
              
              {/* Top Bar of Product Window */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-300" />
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-300" />
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-300" />
                  <span className="text-[11px] font-mono text-slate-600 ml-2">career_trajectory.orbit</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold text-slate-600 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded">
                    Interactive Preview
                  </span>
                </div>
              </div>

              {/* Trajectory Horizontal Step Visualizer */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                    <Compass className="w-3.5 h-3.5 text-indigo-600" />
                    Career Trajectory Path
                  </span>
                  <span className="text-[11px] font-medium text-slate-600">
                    Step {activeStage + 1} of {trajectoryStages.length}
                  </span>
                </div>

                <div className="grid grid-cols-7 gap-1 bg-slate-50 p-1.5 rounded-xl border border-slate-100">
                  {trajectoryStages.map((stage, idx) => {
                    const isActive = idx === activeStage;
                    const isPassed = idx < activeStage;
                    return (
                      <button
                        key={stage.id}
                        type="button"
                        onClick={() => setActiveStage(idx)}
                        className={`py-1.5 px-1 rounded-lg text-center transition-all cursor-pointer ${
                          isActive 
                            ? 'bg-indigo-600 text-white shadow-xs font-bold' 
                            : isPassed
                              ? 'bg-indigo-50 text-indigo-900 font-semibold'
                              : 'text-slate-600 hover:bg-slate-200/60'
                        }`}
                        title={`${stage.label}: ${stage.desc}`}
                      >
                        <div className="text-[9px] truncate">{idx + 1}</div>
                        <div className="text-[8px] truncate hidden sm:block">{stage.label.split(' ')[0]}</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Trajectory Active Stage Card */}
              <div className="p-4 rounded-2xl bg-indigo-50/50 border border-indigo-100 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-indigo-950 uppercase tracking-wider">
                    Current Focus: {trajectoryStages[activeStage].label}
                  </span>
                  <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100/80 px-2 py-0.5 rounded-full">
                    {trajectoryStages[activeStage].status}
                  </span>
                </div>
                <p className="text-xs text-slate-700 font-medium">
                  {trajectoryStages[activeStage].desc}
                </p>
              </div>

              {/* Skill Constellation Interactive Mini-Canvas */}
              <div className="bg-slate-950 text-white rounded-2xl p-4 relative overflow-hidden border border-slate-900">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 text-[11px]">
                  <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    Skill Constellation &amp; Matching Radar
                  </span>
                  <span className="text-slate-600 font-mono">live telemetry</span>
                </div>

                <div className="py-3 grid grid-cols-3 gap-2 text-center text-xs">
                  {/* Node 1 */}
                  <div 
                    onMouseEnter={() => setHoveredNode('python')}
                    onMouseLeave={() => setHoveredNode(null)}
                    className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                      hoveredNode === 'python' || activeStage === 1
                        ? 'bg-indigo-900/60 border-indigo-400 text-white'
                        : 'bg-slate-900/80 border-slate-800 text-slate-300'
                    }`}
                  >
                    <div className="text-[10px] font-mono text-indigo-400">CORE · 92%</div>
                    <div className="font-bold text-xs mt-0.5">Python / PyTorch</div>
                    <div className="text-[10px] text-slate-600 mt-0.5">Verified Project</div>
                  </div>

                  {/* Node 2 */}
                  <div 
                    onMouseEnter={() => setHoveredNode('cuda')}
                    onMouseLeave={() => setHoveredNode(null)}
                    className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                      hoveredNode === 'cuda' || activeStage === 3
                        ? 'bg-amber-950/60 border-amber-400 text-amber-200'
                        : 'bg-slate-900/80 border-slate-800 text-slate-300'
                    }`}
                  >
                    <div className="text-[10px] font-mono text-amber-400">GAP · REQUIRED</div>
                    <div className="font-bold text-xs mt-0.5">CUDA Kernels</div>
                    <div className="text-[10px] text-slate-600 mt-0.5">In Sprint 2</div>
                  </div>

                  {/* Node 3 */}
                  <div 
                    onMouseEnter={() => setHoveredNode('nvidia')}
                    onMouseLeave={() => setHoveredNode(null)}
                    className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                      hoveredNode === 'nvidia' || activeStage === 5
                        ? 'bg-emerald-950/60 border-emerald-400 text-emerald-200'
                        : 'bg-slate-900/80 border-slate-800 text-slate-300'
                    }`}
                  >
                    <div className="text-[10px] font-mono text-emerald-400">OPPORTUNITY</div>
                    <div className="font-bold text-xs mt-0.5">NVIDIA AI Intern</div>
                    <div className="text-[10px] text-slate-600 mt-0.5">88% Fit Score</div>
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between text-[11px] text-slate-600">
                  <span>Candidate: Aarav Sharma</span>
                  <span className="text-emerald-400 font-mono">Trajectory: Active</span>
                </div>
              </div>

              {/* Bottom Insight Footer */}
              <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                <span>Placement Readiness: <strong className="text-slate-900 font-mono">78%</strong></span>
                <button
                  type="button"
                  onClick={onNavigateToVerifiedSkills}
                  className="font-semibold text-indigo-600 hover:text-indigo-800 hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Explore Verified Skills Flagship →</span>
                </button>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
