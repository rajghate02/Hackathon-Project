import React from 'react';
import { PublicNavbar } from './PublicNavbar';
import { HeroSection } from './HeroSection';
import { ProductJourney } from './ProductJourney';
import { SkillIntelligence } from './SkillIntelligence';
import { CareerDiscovery } from './CareerDiscovery';
import { OpportunityMatching } from './OpportunityMatching';
import { CareerReadiness } from './CareerReadiness';
import { EcosystemSection } from './EcosystemSection';
import { UniversityIndustrySection } from './UniversityIndustrySection';
import { IndustryPulsePreview } from './IndustryPulsePreview';
import { SecuritySection } from './SecuritySection';
import { FAQSection } from './FAQSection';
import { FinalCTA } from './FinalCTA';
import { PublicFooter } from './PublicFooter';
import { UserRole, Company } from '../../types';
import { VIEWS } from '../../constants/routes';

interface HomePageProps {
  currentView: string;
  onNavigate: (view: string) => void;
  isAuthenticated: boolean;
  currentUser?: {
    fullName: string;
    institution: string;
    role: UserRole;
  };
  onOpenLogin: () => void;
  onOpenRegister: () => void;
  onLogout: () => void;
  companies: Company[];
  onAccessSkills?: () => void;
  onAccessCareers?: () => void;
  onAccessOpportunities?: () => void;
  onAccessUniversities?: () => void;
  onAccessCompanies?: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  currentView,
  onNavigate,
  isAuthenticated,
  currentUser,
  onOpenLogin,
  onOpenRegister,
  onLogout,
  companies,
  onAccessSkills,
  onAccessCareers,
  onAccessOpportunities,
  onAccessUniversities,
  onAccessCompanies
}) => {
  return (
    <div className="min-h-screen bg-white text-slate-900 selection:bg-indigo-600 selection:text-white flex flex-col font-sans">
      {/* Global Public Sticky Navbar with Return to Home & Auth Awareness */}
      <PublicNavbar
        currentView={currentView}
        onNavigate={onNavigate}
        isAuthenticated={isAuthenticated}
        currentUser={currentUser}
        onOpenLogin={onOpenLogin}
        onOpenRegister={onOpenRegister}
        onLogout={onLogout}
        onAccessSkills={onAccessSkills}
        onAccessCareers={onAccessCareers}
        onAccessOpportunities={onAccessOpportunities}
        onAccessUniversities={onAccessUniversities}
        onAccessCompanies={onAccessCompanies}
      />

      <main className="flex-1">
        {/* 1. Startup-Grade Hero Section with Live Career Trajectory Simulation */}
        <HeroSection
          onGetStarted={isAuthenticated ? () => onNavigate(VIEWS.DASHBOARD) : onOpenRegister}
          onExploreOpportunities={onAccessOpportunities || (() => onNavigate(VIEWS.OPPORTUNITIES))}
          onSeeHowItWorks={() => {
            const el = document.getElementById('product-journey');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          onNavigateToVerifiedSkills={() => onNavigate(VIEWS.VERIFIED_SKILLS)}
        />

        {/* 2. 6-Stage Product Journey: Understand -> Map -> Identify -> Build -> Discover -> Prepare */}
        <ProductJourney onNavigateToView={onNavigate} />

        {/* 3. Skill Intelligence & Evidence-Based Profile Showcase */}
        <SkillIntelligence
          onExploreSkillMapping={onAccessSkills || (() => onNavigate(VIEWS.SKILLMAP))}
          onExploreVerifiedSkills={() => onNavigate(VIEWS.VERIFIED_SKILLS)}
        />

        {/* 4. Career Discovery & Degree Starting Point Demo */}
        <CareerDiscovery onExploreCareers={onAccessCareers || (() => onNavigate(VIEWS.CAREERCOMPASS))} />

        {/* 5. Opportunity Matching 5-Pillar Engine */}
        <OpportunityMatching onExploreOpportunities={onAccessOpportunities || (() => onNavigate(VIEWS.OPPORTUNITIES))} />

        {/* 6. Career Readiness Command Center (72% Index) */}
        <CareerReadiness onGoToDashboard={() => onNavigate(VIEWS.DASHBOARD)} />

        {/* 7. Ecosystem Network (Students -> Skills -> Projects -> Universities -> Companies -> Opportunities) */}
        <EcosystemSection
          companies={companies}
          onNavigateToCompanies={() => onNavigate(VIEWS.COMPANIES)}
          onNavigateToOpportunities={onAccessOpportunities || (() => onNavigate(VIEWS.OPPORTUNITIES))}
        />

        {/* 8. Tri-Party University-Industry Ecosystem */}
        <UniversityIndustrySection
          onNavigateToCollaborations={() => onNavigate(VIEWS.COLLABORATIONS)}
          onNavigateToUniversity={onAccessUniversities || (() => onNavigate(VIEWS.UNIVERSITY_DASHBOARD))}
          onNavigateToRecruiter={onAccessCompanies || (() => onNavigate(VIEWS.RECRUITER_DASHBOARD))}
        />

        {/* 9. Industry Pulse Market Telemetry Preview */}
        <IndustryPulsePreview onExploreIndustryPulse={() => onNavigate(VIEWS.INDUSTRY_PULSE)} />

        {/* 10. Privacy, Governance & Security */}
        <SecuritySection />

        {/* 11. FAQ Accordion (10 required items) */}
        <FAQSection />

        {/* 12. High-Conversion Final Call-to-Action */}
        <FinalCTA
          onGetStarted={isAuthenticated ? () => onNavigate(VIEWS.DASHBOARD) : onOpenRegister}
          onExploreOpportunities={onAccessOpportunities || (() => onNavigate(VIEWS.OPPORTUNITIES))}
        />
      </main>

      {/* 13. Comprehensive Enterprise Public Footer with Return to Top */}
      <PublicFooter onNavigate={onNavigate} />
    </div>
  );
};
