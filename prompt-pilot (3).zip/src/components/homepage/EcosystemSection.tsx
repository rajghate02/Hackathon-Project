import React from 'react';
import { 
  ArrowRight, 
  Users, 
  Layers, 
  FileCode2, 
  GraduationCap, 
  Building2, 
  Briefcase, 
  Info,
  ShieldCheck
} from 'lucide-react';
import { Company } from '../../types';

interface EcosystemSectionProps {
  companies: Company[];
  onNavigateToCompanies: () => void;
  onNavigateToOpportunities: () => void;
}

export const EcosystemSection: React.FC<EcosystemSectionProps> = ({
  companies,
  onNavigateToCompanies,
  onNavigateToOpportunities
}) => {
  const pipelineNodes = [
    { label: 'Students', icon: Users, desc: 'Verified identity & transcripts' },
    { label: 'Skills', icon: Layers, desc: 'Evidence-backed competencies' },
    { label: 'Projects', icon: FileCode2, desc: 'Auditable code repositories' },
    { label: 'Universities', icon: GraduationCap, desc: 'Deans & Placement Cells' },
    { label: 'Companies', icon: Building2, desc: 'Talent Acquisition Teams' },
    { label: 'Opportunities', icon: Briefcase, desc: 'Direct Campus Drives' }
  ];

  return (
    <section id="company-ecosystem" className="py-20 sm:py-28 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-50 border border-indigo-200 text-indigo-700">
            <Building2 className="w-3.5 h-3.5 text-indigo-600" />
            <span>End-to-End Enterprise Talent Network</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-950 tracking-tight leading-tight">
            From skills to real opportunities.
          </h2>

          <p className="text-sm sm:text-base text-slate-600 leading-relaxed font-normal">
            SkillOrbit connects students, skills, projects, universities, companies, and opportunities into one continuous, tamper-evident loop.
          </p>
        </div>

        {/* 6-Stage Ecosystem Pipeline Flow */}
        <div className="mt-14 max-w-5xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
            {pipelineNodes.map((node, idx) => {
              const Icon = node.icon;
              return (
                <div 
                  key={node.label}
                  className="bg-slate-50 border border-slate-200 p-4 rounded-2xl text-center space-y-2 relative group hover:bg-white hover:border-indigo-300 hover:shadow-sm transition-all"
                >
                  <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center mx-auto group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="text-xs font-bold text-slate-900">{node.label}</div>
                  <div className="text-[10px] text-slate-500 leading-tight">{node.desc}</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Real Product Company Directory Preview with Explicit Disclaimers */}
        <div className="mt-12 max-w-5xl mx-auto bg-slate-50 rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-slate-950">
                  Target Company Profiles &amp; Placement Drives
                </h3>
                <span className="text-[10px] font-mono bg-slate-200 text-slate-700 px-2 py-0.5 rounded font-bold">
                  CATALOGUE PREVIEW
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Explore tech requirements, campus drive formats, and open opportunity pipelines.
              </p>
            </div>

            <button
              type="button"
              onClick={onNavigateToCompanies}
              className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
            >
              <span>View Full Company Directory →</span>
            </button>
          </div>

          {/* Company Cards Grid (from real platform data) */}
          <div className="grid sm:grid-cols-3 gap-4">
            {companies.slice(0, 3).map((company) => (
              <div 
                key={company.id} 
                className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3 flex flex-col justify-between"
              >
                <div className="space-y-2.5">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl ${company.logoBg} text-white font-black text-xs flex items-center justify-center shrink-0`}>
                      {company.logoText}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900">{company.name}</h4>
                      <p className="text-[11px] text-slate-500">{company.industry} · {company.headquarters}</p>
                    </div>
                  </div>
                  <p className="text-xs text-slate-600 line-clamp-2">
                    {company.description}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-slate-500 text-[11px]">
                    {company.activeOpportunitiesCount} active drives
                  </span>
                  <span className="text-[10px] text-indigo-600 font-semibold bg-indigo-50 px-2 py-0.5 rounded">
                    Verified Profile
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Explicit Trust Disclaimer Requirement */}
          <div className="p-3.5 bg-white rounded-xl border border-slate-200 flex items-start gap-2.5 text-xs text-slate-500 leading-relaxed">
            <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
            <div>
              <strong>Transparent Integration Notice:</strong> Listings reflect campus recruitment drives, verified institutional pipelines, and publicly documented technology openings. Company names, trademarks, and logos belong to their respective holders and are presented for career discovery and curriculum mapping purposes.
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
