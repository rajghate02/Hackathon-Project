import { UserRole } from '../types';

export const HOME_VIEW = 'landing';
export const HOME_PATH = '/';

export const VIEWS = {
  HOME: 'landing',
  DASHBOARD: 'dashboard',
  VERIFIED_SKILLS: 'verified_skills',
  SKILLMAP: 'skillmap',
  CAREERCOMPASS: 'careercompass',
  OPPORTUNITIES: 'opportunities',
  COMPANIES: 'companies',
  COLLABORATIONS: 'collaborations',
  APPLICATIONS: 'applications',
  UNIVERSITY_DASHBOARD: 'university_dashboard',
  RECRUITER_DASHBOARD: 'recruiter_dashboard',
  INDUSTRY_PULSE: 'industrypulse',
  HELP: 'help',
  ADMIN_PANEL: 'admin_panel',
  ERROR: 'error'
} as const;

export type AppView = typeof VIEWS[keyof typeof VIEWS];

export const VIEW_PATHS: Record<string, string> = {
  [VIEWS.HOME]: '/',
  [VIEWS.DASHBOARD]: '/dashboard',
  [VIEWS.VERIFIED_SKILLS]: '/verified-skills',
  [VIEWS.SKILLMAP]: '/skills',
  [VIEWS.CAREERCOMPASS]: '/careers',
  [VIEWS.OPPORTUNITIES]: '/opportunities',
  [VIEWS.COMPANIES]: '/companies',
  [VIEWS.COLLABORATIONS]: '/collaborations',
  [VIEWS.APPLICATIONS]: '/applications',
  [VIEWS.UNIVERSITY_DASHBOARD]: '/for-universities',
  [VIEWS.RECRUITER_DASHBOARD]: '/for-companies',
  [VIEWS.INDUSTRY_PULSE]: '/industry-pulse',
  [VIEWS.HELP]: '/help',
  [VIEWS.ADMIN_PANEL]: '/admin',
  [VIEWS.ERROR]: '/error'
};

export const PATH_TO_VIEW: Record<string, string> = {
  '/': VIEWS.HOME,
  '/landing': VIEWS.HOME,
  '/home': VIEWS.HOME,
  '/dashboard': VIEWS.DASHBOARD,
  '/verified-skills': VIEWS.VERIFIED_SKILLS,
  '/verified_skills': VIEWS.VERIFIED_SKILLS,
  '/skills': VIEWS.SKILLMAP,
  '/skillmap': VIEWS.SKILLMAP,
  '/careers': VIEWS.CAREERCOMPASS,
  '/careercompass': VIEWS.CAREERCOMPASS,
  '/career-compass': VIEWS.CAREERCOMPASS,
  '/opportunities': VIEWS.OPPORTUNITIES,
  '/companies': VIEWS.COMPANIES,
  '/collaborations': VIEWS.COLLABORATIONS,
  '/applications': VIEWS.APPLICATIONS,
  '/for-universities': VIEWS.UNIVERSITY_DASHBOARD,
  '/universities': VIEWS.UNIVERSITY_DASHBOARD,
  '/university': VIEWS.UNIVERSITY_DASHBOARD,
  '/university_dashboard': VIEWS.UNIVERSITY_DASHBOARD,
  '/for-companies': VIEWS.RECRUITER_DASHBOARD,
  '/companies-portal': VIEWS.RECRUITER_DASHBOARD,
  '/recruiter': VIEWS.RECRUITER_DASHBOARD,
  '/recruiter_dashboard': VIEWS.RECRUITER_DASHBOARD,
  '/industry-pulse': VIEWS.INDUSTRY_PULSE,
  '/industry_pulse': VIEWS.INDUSTRY_PULSE,
  '/industrypulse': VIEWS.INDUSTRY_PULSE,
  '/help': VIEWS.HELP,
  '/admin': VIEWS.ADMIN_PANEL,
  '/admin_panel': VIEWS.ADMIN_PANEL,
  '/error': VIEWS.ERROR
};

export function normalizeView(rawView: string): string {
  if (!rawView) return VIEWS.HOME;
  const clean = rawView.trim().toLowerCase();

  if (PATH_TO_VIEW[clean]) return PATH_TO_VIEW[clean];
  if (PATH_TO_VIEW[`/${clean}`]) return PATH_TO_VIEW[`/${clean}`];

  switch (clean) {
    case 'skills':
    case 'skill_map':
    case 'skillmap':
      return VIEWS.SKILLMAP;
    case 'careers':
    case 'career':
    case 'career_compass':
    case 'careercompass':
      return VIEWS.CAREERCOMPASS;
    case 'opportunities':
    case 'opportunity':
    case 'jobs':
    case 'internships':
      return VIEWS.OPPORTUNITIES;
    case 'universities':
    case 'university':
    case 'for_universities':
    case 'for-universities':
    case 'university_dashboard':
      return VIEWS.UNIVERSITY_DASHBOARD;
    case 'companies_portal':
    case 'recruiter':
    case 'for_companies':
    case 'for-companies':
    case 'recruiter_dashboard':
      return VIEWS.RECRUITER_DASHBOARD;
    case 'industry_pulse':
    case 'industry-pulse':
    case 'industrypulse':
      return VIEWS.INDUSTRY_PULSE;
    case 'home':
    case 'landing':
    case '/':
      return VIEWS.HOME;
    default: {
      const values = Object.values(VIEWS) as string[];
      if (values.includes(rawView)) return rawView;
      return rawView;
    }
  }
}

export function getPathForView(view: string): string {
  const norm = normalizeView(view);
  return VIEW_PATHS[norm] || '/';
}

export interface NavItemConfig {
  id: string;
  label: string;
  targetView: string;
  requiresAuth?: boolean;
  requiredRole?: UserRole;
  description?: string;
}

export const MAIN_NAV_CONFIG: Record<string, NavItemConfig> = {
  HOME: {
    id: 'home',
    label: 'Home',
    targetView: VIEWS.HOME,
    requiresAuth: false
  },
  SKILLS: {
    id: 'skills',
    label: 'Skills',
    targetView: VIEWS.SKILLMAP,
    requiresAuth: true,
    description: 'Skill map, proficiency graph, and evidence portfolio'
  },
  CAREERS: {
    id: 'careers',
    label: 'Careers',
    targetView: VIEWS.CAREERCOMPASS,
    requiresAuth: true,
    description: 'Career discovery, trajectory pathways, and fit analytics'
  },
  OPPORTUNITIES: {
    id: 'opportunities',
    label: 'Opportunities',
    targetView: VIEWS.OPPORTUNITIES,
    requiresAuth: true,
    description: 'Campus placement drives, internships, and job postings'
  },
  UNIVERSITIES: {
    id: 'universities',
    label: 'For Universities',
    targetView: VIEWS.UNIVERSITY_DASHBOARD,
    requiresAuth: true,
    requiredRole: 'university_admin',
    description: 'Institutional placement command center and cohort analytics'
  },
  COMPANIES: {
    id: 'companies',
    label: 'For Companies',
    targetView: VIEWS.RECRUITER_DASHBOARD,
    requiresAuth: true,
    requiredRole: 'recruiter',
    description: 'Recruiter talent discovery and campus hiring portal'
  },
  HELP: {
    id: 'help',
    label: 'Help',
    targetView: VIEWS.HELP,
    requiresAuth: false,
    description: 'Documentation, FAQs, and support ticket system'
  }
};

export interface BreadcrumbItem {
  label: string;
  view?: string;
  href?: string;
  isCurrent?: boolean;
}

export function getRoleDashboardView(role: UserRole): string {
  switch (role) {
    case 'university_admin':
      return VIEWS.UNIVERSITY_DASHBOARD;
    case 'recruiter':
      return VIEWS.RECRUITER_DASHBOARD;
    case 'platform_admin':
      return VIEWS.ADMIN_PANEL;
    case 'student':
    default:
      return VIEWS.DASHBOARD;
  }
}

export function getRoleDashboardName(role: UserRole): string {
  switch (role) {
    case 'university_admin':
      return 'University Dashboard';
    case 'recruiter':
      return 'Recruiter Dashboard';
    case 'platform_admin':
      return 'Admin Dashboard';
    case 'student':
    default:
      return 'Student Dashboard';
  }
}

export function getViewBreadcrumbs(view: string, detailTitle?: string): BreadcrumbItem[] {
  const base: BreadcrumbItem[] = [{ label: 'Home', view: VIEWS.HOME }];

  switch (view) {
    case VIEWS.DASHBOARD:
      return [...base, { label: 'Command Center', view: VIEWS.DASHBOARD }, { label: 'Student Dashboard', isCurrent: true }];
    case VIEWS.VERIFIED_SKILLS:
      return [...base, { label: 'Skills', view: VIEWS.SKILLMAP }, { label: '🛡️ Verified Skills', isCurrent: true }];
    case VIEWS.SKILLMAP:
      return [...base, { label: 'Skills', view: VIEWS.SKILLMAP }, { label: detailTitle || 'Skill Map & Constellation', isCurrent: true }];
    case VIEWS.CAREERCOMPASS:
      return [...base, { label: 'Careers', view: VIEWS.CAREERCOMPASS }, { label: detailTitle || 'Career Compass', isCurrent: true }];
    case VIEWS.OPPORTUNITIES:
      return [...base, { label: 'Opportunities', view: VIEWS.OPPORTUNITIES }, { label: detailTitle || 'Opportunity Discovery', isCurrent: true }];
    case VIEWS.COMPANIES:
      return [...base, { label: 'Organizations', view: VIEWS.COMPANIES }, { label: detailTitle || 'Company Directory', isCurrent: true }];
    case VIEWS.COLLABORATIONS:
      return [...base, { label: 'Organizations', view: VIEWS.COLLABORATIONS }, { label: 'University–Industry Capstones', isCurrent: true }];
    case VIEWS.APPLICATIONS:
      return [...base, { label: 'Career Command', view: VIEWS.DASHBOARD }, { label: 'Application Pipeline', isCurrent: true }];
    case VIEWS.UNIVERSITY_DASHBOARD:
      return [...base, { label: 'Organizations', view: VIEWS.UNIVERSITY_DASHBOARD }, { label: 'University Analytics & Placement', isCurrent: true }];
    case VIEWS.RECRUITER_DASHBOARD:
      return [...base, { label: 'Organizations', view: VIEWS.RECRUITER_DASHBOARD }, { label: 'Recruiter Talent Discovery', isCurrent: true }];
    case VIEWS.INDUSTRY_PULSE:
      return [...base, { label: 'Intelligence', view: VIEWS.INDUSTRY_PULSE }, { label: 'Industry Pulse & Demand Index', isCurrent: true }];
    case VIEWS.HELP:
      return [...base, { label: 'Support', view: VIEWS.HELP }, { label: detailTitle || 'Help Center & Documentation', isCurrent: true }];
    case VIEWS.ADMIN_PANEL:
      return [...base, { label: 'System', view: VIEWS.ADMIN_PANEL }, { label: 'Platform Administration', isCurrent: true }];
    case VIEWS.ERROR:
      return [...base, { label: 'System Status', isCurrent: true }];
    default:
      return base;
  }
}
