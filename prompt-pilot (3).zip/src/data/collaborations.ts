import { UniversityIndustryProject } from '../types';

export const COLLABORATION_PROJECTS: UniversityIndustryProject[] = [
  {
    id: 'collab-muj-nvidia',
    title: 'Autonomous Drone Navigation & Real-Time Obstacle Avoidance',
    companyId: 'comp-nvidia',
    companyName: 'NVIDIA',
    universityId: 'inst-muj',
    universityName: 'Manipal University Jaipur (MUJ)',
    type: 'Industry Research',
    durationWeeks: 16,
    openSlots: 4,
    enrolledStudentsCount: 3,
    requiredSkills: ['C++', 'CUDA', 'Computer Vision', 'PyTorch & Deep Learning'],
    mentorName: 'Dr. Anand Ramanathan',
    mentorTitle: 'Principal Research Scientist, NVIDIA Robotics Lab',
    stipend: '₹35,000 / month / student + Jetson Orin Hardware Kit',
    status: 'In Progress',
    description: 'Joint research initiative between NVIDIA Robotics and Manipal University Jaipur School of Computing to optimize edge SLAM algorithms on NVIDIA Jetson embedded architecture.',
    deliverables: [
      'Edge benchmark report evaluating FPS and power consumption across sensor inputs',
      'Open-source PyTorch ROS2 node implementation',
      'Joint co-authored conference paper draft submitted to IROS/ICRA'
    ],
    deadline: '2026-11-15'
  },
  {
    id: 'collab-mahe-jpmc',
    title: 'High-Throughput Liquidity Settlement Ledger Prototype',
    companyId: 'comp-jpmorgan',
    companyName: 'JPMorgan Chase',
    universityId: 'inst-mahe',
    universityName: 'Manipal Academy of Higher Education (MAHE)',
    type: 'Capstone Project',
    durationWeeks: 20,
    openSlots: 5,
    enrolledStudentsCount: 4,
    requiredSkills: ['Distributed Systems', 'Java', 'SQL & Relational Databases', 'CI/CD & Git'],
    mentorName: 'Vikramaditya Sengupta',
    mentorTitle: 'Managing Director, Onyx by J.P. Morgan',
    stipend: '₹40,000 / month / student',
    status: 'Open for Applications',
    description: 'Enterprise capstone exploring consensus latency tradeoffs in multi-node payment ledgers under network partition scenarios.',
    deliverables: [
      'Fault tolerance simulation under Byzantine network partitions',
      'Benchmarking suite measuring throughput (TPS) and p99 latency',
      'Executive technical presentation delivered to J.P. Morgan Global Tech Leadership'
    ],
    deadline: '2026-10-25'
  },
  {
    id: 'collab-iitb-mckinsey',
    title: 'AI Decarbonization & Green Supply Chain Optimization Engine',
    companyId: 'comp-mckinsey',
    companyName: 'McKinsey & Company',
    universityId: 'inst-iitb',
    universityName: 'Indian Institute of Technology Bombay (IIT Bombay)',
    type: 'Real-World Challenge',
    durationWeeks: 12,
    openSlots: 6,
    enrolledStudentsCount: 5,
    requiredSkills: ['Python', 'Data Analytics', 'Business Strategy & Problem Solving', 'Linear Algebra'],
    mentorName: 'Siddharth Mehra',
    mentorTitle: 'Partner, QuantumBlack AI by McKinsey',
    stipend: '₹45,000 / month / student',
    status: 'In Progress',
    description: 'Collaborative development of a mathematical carbon footprint optimizer simulating freight multimodal shifts and renewable energy grid integration.',
    deliverables: [
      'Mathematical mixed-integer linear programming (MILP) model',
      'Interactive executive decision cockpit built in React',
      'Whitepaper on Scope-3 emission reductions in heavy manufacturing'
    ],
    deadline: '2026-10-30'
  },
  {
    id: 'collab-dtu-google',
    title: 'Multilingual Indic NLP & Speech Accessibility for Public Utilities',
    companyId: 'comp-google',
    companyName: 'Google / Alphabet',
    universityId: 'inst-dtu',
    universityName: 'Delhi Technological University (DTU)',
    type: 'Industry Research',
    durationWeeks: 16,
    openSlots: 4,
    enrolledStudentsCount: 2,
    requiredSkills: ['Python', 'Large Language Models & GenAI', 'PyTorch & Deep Learning'],
    mentorName: 'Pooja Kashyap',
    mentorTitle: 'Staff Research Scientist, Google Research India',
    stipend: '₹40,000 / month / student + Google Cloud TPU credits',
    status: 'Open for Applications',
    description: 'Advancing acoustic and linguistic model accuracy across low-resource Indic dialects for automated public services delivery.',
    deliverables: [
      'Curated dialect audio corpus with phonetic annotations',
      'Benchmarked transformer models evaluated against Indian public service datasets',
      'Technical artifact presentation'
    ],
    deadline: '2026-11-10'
  }
];
