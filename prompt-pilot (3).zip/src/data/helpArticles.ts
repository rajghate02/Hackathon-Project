import { HelpArticle } from '../types';

export const HELP_ARTICLES_DATA: HelpArticle[] = [
  {
    id: 'art-getting-started',
    category: 'Getting Started',
    title: 'How SkillOrbit Works: From Skills to Dream Placements',
    slug: 'how-skillorbit-works',
    summary: 'An end-to-end overview of how SkillOrbit builds your verified skill graph, matches internships, and tracks placement readiness.',
    tags: ['Onboarding', 'Students', 'Skills', 'Placement'],
    content: [
      'SkillOrbit represents your career trajectory as an interconnected orbit of verified skills, institutional benchmarks, and real-time enterprise requirements.',
      '1. Verify your university email address to connect with your institution’s career cell and peer ecosystem.',
      '2. Build your Skill Map by adding evidence (projects, certifications, courses, or academic subjects) rather than self-reported ratings.',
      '3. Discover careers and internships with mathematically transparent match scores explaining exactly why an opportunity fits you and what skills you are missing.',
      '4. Collaborate on verified university-industry capstone projects sponsored by leading technology, finance, and consulting companies.'
    ]
  },
  {
    id: 'art-verification',
    category: 'Verification',
    title: 'Institutional Email & Identity Verification Standards',
    slug: 'institutional-verification',
    summary: 'Why university domain validation is required and how our data minimization principles protect your student records.',
    tags: ['Email Verification', 'Identity', 'Privacy', 'Compliance'],
    content: [
      'SkillOrbit enforces institutional email domain verification to ensure that candidates belong to accredited colleges and universities.',
      'Supported domains (e.g., @jaipur.manipal.edu, @manipal.edu, @iitb.ac.in) are automatically matched against our global institution registry.',
      'Privacy & Data Minimization: We do not store raw government identity documents on public servers. We process identity validation using privacy-preserving zero-knowledge and certified identity partners, storing only status tokens and cryptographically signed timestamps.'
    ]
  },
  {
    id: 'art-skill-map',
    category: 'Skills',
    title: 'How to Earn Evidence-Backed Verification on the Skill Map',
    slug: 'skill-map-evidence-guide',
    summary: 'Learn how project repositories, verified credentials, and university assessments elevate your skill proficiency score.',
    tags: ['Skills', 'Evidence', 'Certifications', 'Projects'],
    content: [
      'Self-declarations are unverified on SkillOrbit. To achieve "Developing", "Intermediate", "Advanced", or "Expert" badges, you must attach verifiable evidence:',
      '• Project Evidence: Public GitHub/GitLab repository with test suites or deployed demo URL.',
      '• Certification Evidence: Credential verification ID from recognized providers (DeepLearning.AI, AWS, Azure, Google Cloud, CFA Institute).',
      '• Academic Subject Evidence: Verified course transcripts or semester grade sheets approved by your university administration.',
      '• Assessments: Proctored SkillOrbit benchmark assessments.'
    ]
  },
  {
    id: 'art-opportunity-matching',
    category: 'Internships',
    title: 'Understanding Your Opportunity Match Breakdown',
    slug: 'opportunity-match-breakdown',
    summary: 'How our algorithm computes skill match, education fit, experience relevance, and missing skill suggestions.',
    tags: ['Matching', 'Internships', 'Jobs', 'Readiness'],
    content: [
      'Every internship and full-time role displays a transparent score (e.g., 87% Match) composed of five distinct pillars:',
      '1. Skills Match (40% weight): Comparison between your verified skills and the role’s mandatory vs preferred tech stack.',
      '2. Education Match (25% weight): Degree level (BTech, MTech, MBA, PhD), major discipline, and graduation cohort alignment.',
      '3. Experience Match (15% weight): Projects and prior internships related to the domain.',
      '4. Location & Work Mode Fit (10% weight): Remote, hybrid, or on-site preferences.',
      '5. Eligibility Match (10% weight): Minimum CGPA cutoffs and prerequisite criteria.'
    ]
  },
  {
    id: 'art-privacy-security',
    category: 'Privacy',
    title: 'Data Governance, Recruiter Visibility & Security Architecture',
    slug: 'privacy-security-architecture',
    summary: 'Comprehensive details on your profile visibility settings, recruiter contact boundaries, and enterprise security.',
    tags: ['Security', 'Privacy', 'GDPR', 'RBAC'],
    content: [
      'Your privacy is respected by design. Students maintain granular control over:',
      '• Recruiter Search Visibility: Toggle whether verified corporate recruiters can discover your profile or whether your applications remain completely private.',
      '• Direct Contact Requests: Require prior notification before companies can request interviews.',
      '• Strict RBAC: University administrators can access aggregate cohort analytics but cannot export personal sensitive information without explicit user consent.',
      '• Security Controls: TLS 1.3, CSRF tokens, strict Content Security Policies, rate-limiting, and comprehensive audit logs.'
    ]
  },
  {
    id: 'art-universities-collaboration',
    category: 'Universities',
    title: 'University-Industry Collaboration: Capstones and Research Challenges',
    slug: 'university-collaboration-guide',
    summary: 'How academic departments and industry leaders co-sponsor real-world capstone challenges for students.',
    tags: ['Universities', 'Capstones', 'Industry', 'Collaboration'],
    content: [
      'SkillOrbit enables engineering departments and business schools to review and approve industry problem statements submitted by Fortune 500 companies.',
      'Student teams apply directly, receive industry mentorship from principal engineers and directors, and deliver production-grade code or research papers that earn academic credit.'
    ]
  }
];
