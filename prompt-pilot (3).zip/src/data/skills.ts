import { SkillCategory, UserSkill } from '../types';

export interface CanonicalSkill {
  id: string;
  name: string;
  category: SkillCategory;
  description: string;
  inDemand: boolean;
  relatedCareers: string[];
}

export const CANONICAL_SKILLS: CanonicalSkill[] = [
  // Programming
  { id: 'sk-dsa', name: 'Data Structures & Algorithms', category: 'Programming', description: 'Arrays, Trees, Graphs, Dynamic Programming, and Complexity Analysis', inDemand: true, relatedCareers: ['Software Engineer', 'Quant Developer'] },
  { id: 'sk-python', name: 'Python', category: 'Programming', description: 'Advanced Python, OOP, AsyncIO, and scientific libraries', inDemand: true, relatedCareers: ['AI/ML Engineer', 'Data Scientist', 'Quantitative Researcher'] },
  { id: 'sk-cpp', name: 'C++', category: 'Programming', description: 'Modern C++ (17/20), Memory Management, Templates, and Low-Latency systems', inDemand: true, relatedCareers: ['Systems Engineer', 'Quant Developer', 'Robotics Engineer'] },
  { id: 'sk-java', name: 'Java', category: 'Programming', description: 'Enterprise Java, Concurrency, JVM internals, and Spring Framework', inDemand: true, relatedCareers: ['Software Engineer', 'FinTech Engineer'] },
  { id: 'sk-ts', name: 'TypeScript', category: 'Programming', description: 'Static typing, interfaces, generic types, and modern JavaScript runtimes', inDemand: true, relatedCareers: ['Full-Stack Engineer', 'Frontend Architect'] },
  { id: 'sk-golang', name: 'Go (Golang)', category: 'Programming', description: 'Goroutines, Channels, microservices, and network programming', inDemand: true, relatedCareers: ['Cloud/DevOps Engineer', 'Distributed Systems Engineer'] },
  
  // Engineering
  { id: 'sk-dist-sys', name: 'Distributed Systems', category: 'Engineering', description: 'Consensus protocols, replication, CAP theorem, and event-driven architectures', inDemand: true, relatedCareers: ['Software Engineer', 'Cloud Architect'] },
  { id: 'sk-docker-k8s', name: 'Docker & Kubernetes', category: 'Engineering', description: 'Containerization, cluster orchestration, Helm charts, and service meshes', inDemand: true, relatedCareers: ['Cloud/DevOps Engineer'] },
  { id: 'sk-linux', name: 'Linux Systems & Shell', category: 'Engineering', description: 'Kernel basics, process IPC, memory management, and bash automation', inDemand: true, relatedCareers: ['Systems Engineer', 'Cybersecurity Analyst'] },
  { id: 'sk-cicd', name: 'CI/CD & Git', category: 'Engineering', description: 'Automated test runners, GitHub Actions, trunk-based development, and branching', inDemand: true, relatedCareers: ['Software Engineer', 'DevOps Engineer'] },
  
  // Data
  { id: 'sk-sql', name: 'SQL & Relational Databases', category: 'Data', description: 'Complex JOINs, indexing strategies, ACID transactions, and query plans', inDemand: true, relatedCareers: ['Data Engineer', 'Software Engineer', 'Business Analyst'] },
  { id: 'sk-data-pipes', name: 'ETL Pipelines & Spark', category: 'Data', description: 'Large-scale distributed batch and streaming pipelines, Apache Spark, Kafka', inDemand: true, relatedCareers: ['Data Engineer'] },
  { id: 'sk-redis', name: 'Redis & In-Memory Caching', category: 'Data', description: 'Key-value caches, pub/sub, distributed locks, and rate limiting', inDemand: true, relatedCareers: ['Software Engineer'] },
  
  // AI/ML
  { id: 'sk-pytorch', name: 'PyTorch & Deep Learning', category: 'AI/ML', description: 'Tensor operations, backprop, custom neural layers, and multi-GPU training', inDemand: true, relatedCareers: ['AI/ML Engineer'] },
  { id: 'sk-llms', name: 'Large Language Models & GenAI', category: 'AI/ML', description: 'Transformers, fine-tuning (LoRA), RAG pipelines, and prompt engineering', inDemand: true, relatedCareers: ['AI Engineer', 'AI Research Fellow'] },
  { id: 'sk-cv', name: 'Computer Vision', category: 'AI/ML', description: 'Object detection (YOLO), segmentation, OpenCV, and 3D point clouds', inDemand: true, relatedCareers: ['Robotics Engineer', 'Autonomous Vehicles'] },
  
  // Design
  { id: 'sk-figma', name: 'Figma & Design Systems', category: 'Design', description: 'Auto-layout, tokens, variant components, and interactive prototypes', inDemand: false, relatedCareers: ['Product Designer', 'Product Manager'] },
  { id: 'sk-ux-research', name: 'User Research & WCAG', category: 'Design', description: 'Usability testing, heuristic evaluations, and accessibility compliance', inDemand: false, relatedCareers: ['Product Designer'] },
  
  // Business
  { id: 'sk-fin-model', name: 'Financial Modeling & Valuation', category: 'Business', description: 'DCF, LBO modeling, comparable company analysis, and unit economics', inDemand: true, relatedCareers: ['Investment Banker', 'Management Consultant'] },
  { id: 'sk-biz-strat', name: 'Business Strategy & Problem Solving', category: 'Business', description: 'Hypothesis-driven problem solving, MECE structuring, and market sizing', inDemand: true, relatedCareers: ['Management Consultant', 'Product Manager'] },
  { id: 'sk-pm', name: 'Product Management', category: 'Business', description: 'Roadmapping, PRDs, backlog grooming, metric definitions, and OKRs', inDemand: true, relatedCareers: ['Product Manager'] },
  
  // Communication & Leadership
  { id: 'sk-comm', name: 'Executive Presentation & Storytelling', category: 'Communication', description: 'Structuring arguments for CXOs, clear slide design, and persuasive speech', inDemand: true, relatedCareers: ['Management Consultant', 'Executive Leadership'] },
  { id: 'sk-tech-writing', name: 'Technical Writing & Architecture Docs', category: 'Communication', description: 'RFCs, system design proposals, API documentation, and changelogs', inDemand: true, relatedCareers: ['Software Engineer', 'Cloud Architect'] },
  { id: 'sk-agile', name: 'Agile & Cross-Functional Leadership', category: 'Leadership', description: 'Sprint retrospectives, cross-team alignment, and delivery orchestration', inDemand: true, relatedCareers: ['Engineering Manager', 'Scrum Master'] },
  
  // Domain-specific
  { id: 'sk-quant', name: 'Quantitative Finance & Derivatives', category: 'Domain-specific', description: 'Options pricing (Black-Scholes), Greeks, volatility surfaces, and risk', inDemand: true, relatedCareers: ['Quantitative Researcher', 'Risk Analyst'] },
  { id: 'sk-cyber', name: 'Cybersecurity & Zero Trust', category: 'Domain-specific', description: 'Penetration testing, cryptographic primitives, OWASP Top 10, and SIEM', inDemand: true, relatedCareers: ['Cybersecurity Analyst', 'Security Engineer'] }
];

// Initial seeded student skills for authentic demonstration
export const INITIAL_STUDENT_SKILLS: UserSkill[] = [
  {
    id: 'us-1',
    skillId: 'sk-dsa',
    name: 'Data Structures & Algorithms',
    category: 'Programming',
    level: 'Advanced',
    proficiencyScore: 88,
    verified: true,
    evidence: [
      {
        id: 'ev-1',
        type: 'Assessment',
        title: 'SkillOrbit DSA Benchmark Assessment — Tier 1 (96th percentile)',
        organizationOrPlatform: 'SkillOrbit Assessment Center',
        dateCompleted: '2026-06-12',
        verified: true,
        gradeOrScore: '96/100'
      },
      {
        id: 'ev-2',
        type: 'Academic Subject',
        title: 'CS201: Advanced Data Structures & Algorithm Design',
        organizationOrPlatform: 'Manipal University Jaipur',
        dateCompleted: '2026-05-20',
        verified: true,
        gradeOrScore: 'Grade: A+'
      }
    ]
  },
  {
    id: 'us-2',
    skillId: 'sk-python',
    name: 'Python',
    category: 'Programming',
    level: 'Advanced',
    proficiencyScore: 90,
    verified: true,
    evidence: [
      {
        id: 'ev-3',
        type: 'Project',
        title: 'Distributed Asynchronous Task Queue in Python',
        organizationOrPlatform: 'GitHub open-source repository',
        urlOrCredentialId: 'https://github.com/student/async-task-queue',
        dateCompleted: '2026-07-04',
        verified: true,
        gradeOrScore: '140 GitHub Stars'
      }
    ]
  },
  {
    id: 'us-3',
    skillId: 'sk-cpp',
    name: 'C++',
    category: 'Programming',
    level: 'Intermediate',
    proficiencyScore: 72,
    verified: true,
    evidence: [
      {
        id: 'ev-4',
        type: 'Academic Subject',
        title: 'CS102: Object-Oriented Programming with C++',
        organizationOrPlatform: 'Manipal University Jaipur',
        dateCompleted: '2025-12-10',
        verified: true,
        gradeOrScore: 'Grade: A'
      }
    ]
  },
  {
    id: 'us-4',
    skillId: 'sk-sql',
    name: 'SQL & Relational Databases',
    category: 'Data',
    level: 'Intermediate',
    proficiencyScore: 76,
    verified: true,
    evidence: [
      {
        id: 'ev-5',
        type: 'Course',
        title: 'Relational Database Architecture and PostgreSQL Optimization',
        organizationOrPlatform: 'Coursera / Stanford Online',
        dateCompleted: '2026-02-18',
        verified: true,
        gradeOrScore: 'Completed with Honors'
      }
    ]
  },
  {
    id: 'us-5',
    skillId: 'sk-dist-sys',
    name: 'Distributed Systems',
    category: 'Engineering',
    level: 'Developing',
    proficiencyScore: 54,
    verified: false,
    evidence: [
      {
        id: 'ev-6',
        type: 'Project',
        title: 'Raft Consensus Protocol Prototype in Go/Python',
        organizationOrPlatform: 'Personal Capstone',
        dateCompleted: '2026-08-01',
        verified: false
      }
    ]
  },
  {
    id: 'us-6',
    skillId: 'sk-pytorch',
    name: 'PyTorch & Deep Learning',
    category: 'AI/ML',
    level: 'Intermediate',
    proficiencyScore: 68,
    verified: true,
    evidence: [
      {
        id: 'ev-7',
        type: 'Certification',
        title: 'Deep Learning Specialization',
        organizationOrPlatform: 'DeepLearning.AI',
        urlOrCredentialId: 'DL-AI-CERT-98231',
        dateCompleted: '2026-03-15',
        verified: true
      }
    ]
  },
  {
    id: 'us-7',
    skillId: 'sk-comm',
    name: 'Executive Presentation & Storytelling',
    category: 'Communication',
    level: 'Intermediate',
    proficiencyScore: 74,
    verified: true,
    evidence: [
      {
        id: 'ev-8',
        type: 'Internship',
        title: 'Technical Presentations during Summer Research Fellowship',
        organizationOrPlatform: 'National Research Lab',
        dateCompleted: '2026-07-28',
        verified: true
      }
    ]
  }
];
